# creates

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -SIAURL
The URL of the CyberArk SIA service. Can also be specified using the alias 'url'.

### -LogonToken
The authentication token used for API requests. Can also be specified using the alias 'header'.

## Examples

### Example 1
```powershell
New-Connector -SIAURL "https://sia.example.com" -LogonToken $token

Creates a new Windows on-premise connector with default settings.
```

### Example 2
```powershell
New-Connector -SIAURL "https://sia.example.com" -LogonToken $token -WhatIf

Shows what would happen when creating the connector without actually creating it.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\SIA\New-Connector.ps1*
