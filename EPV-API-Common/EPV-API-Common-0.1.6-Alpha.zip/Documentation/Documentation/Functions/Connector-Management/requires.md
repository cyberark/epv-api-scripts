# requires

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -CMURL
The URL of the CyberArk Connector Management service in the format https://<subdomain>.connectormanagement.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -Order
Order by parameter. ASC/DESC.

### -PageSize
Page size for pagination.

### -Sort
Sort by parameter.

### -ContinuationToken
Continuation token for pagination.

## Examples

### Example 1
```powershell
Get-ConnectorIdentifierType -CMURL "https://subdomain.connectormanagement.cyberark.cloud/api/pool-service" -LogonToken $token
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\ConnectorManagement\Get-ConnectorIdentifierType.ps1*
