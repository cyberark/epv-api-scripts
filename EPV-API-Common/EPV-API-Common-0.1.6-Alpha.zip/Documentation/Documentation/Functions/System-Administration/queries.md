# queries

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance. Can also be specified using the aliases 'url' or 'PCloudURL'.

### -LogonToken
The authentication token used for API requests. Can also be specified using the alias 'header'.

### -Summary
Switch to retrieve a summary of all system health components. This is the default parameter set.

### -CPM
Switch to retrieve detailed health information for the Central Policy Manager (CPM) component.

### -PVWA
Switch to retrieve detailed health information for the Password Vault Web Access (PVWA) component.

### -PSM
Switch to retrieve detailed health information for the Privileged Session Manager (PSM) component.

### -PSMP
Switch to retrieve detailed health information for the Privileged Session Manager for SSH (PSMP) component.

### -PTA
Switch to retrieve detailed health information for the Privileged Threat Analytics (PTA) component.

### -AIM
Switch to retrieve detailed health information for the Application Identity Manager (AIM) component.

## Examples

### Example 1
```powershell
Get-SystemHealth -PVWAURL "https://pvwa.example.com" -LogonToken $token

Retrieves a summary of all system health components.
```

### Example 2
```powershell
Get-SystemHealth -PVWAURL "https://pvwa.example.com" -LogonToken $token -CPM

Retrieves detailed health information for the CPM component only.
```

### Example 3
```powershell
Get-SystemHealth -PVWAURL "https://pvwa.example.com" -LogonToken $token -PSM

Retrieves detailed health information for the PSM component only.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\SystemHealth\Get-SystemHealth.ps1*
