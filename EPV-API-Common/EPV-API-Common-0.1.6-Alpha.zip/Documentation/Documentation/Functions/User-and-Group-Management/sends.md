# sends

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -IdentityURL
The base URL of the identity service.

### -LogonToken
The authentication token required to access the identity service.

### -UUID
The unique identifier of the role whose members are to be retrieved.

## Examples

### Example 1
```powershell
PS> Get-IdentityRoleMember -IdentityURL "https://identity.example.com" -LogonToken $token -UUID "12345"
```

## Notes
The function removes any additional parameters passed to it using the CatchAll parameter.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Identity\Role\Get-IdentityRoleMember.ps1*
