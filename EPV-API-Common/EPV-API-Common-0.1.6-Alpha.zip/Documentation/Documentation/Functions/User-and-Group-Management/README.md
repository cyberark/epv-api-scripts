# User and Group Management Functions

This section contains 16 functions related to User and Group Management.

## Functions in this Category
- [adds](./adds.md) - No synopsis available
- [assigns](./assigns.md) - No synopsis available
- [assigns](./assigns.md) - No synopsis available
- [creates](./creates.md) - No synopsis available
- [creates](./creates.md) - No synopsis available
- [Invoke-RefreshIdentityUser](./Invoke-RefreshIdentityUser.md) - No documentation available
- [removes](./removes.md) - No synopsis available
- [removes](./removes.md) - No synopsis available
- [removes](./removes.md) - No synopsis available
- [removes](./removes.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [sends](./sends.md) - No synopsis available
- [sends](./sends.md) - No synopsis available

## Quick Reference

| Function | Synopsis |
|----------|----------|| [adds](./adds.md) | No synopsis available |
| [assigns](./assigns.md) | No synopsis available |
| [assigns](./assigns.md) | No synopsis available |
| [creates](./creates.md) | No synopsis available |
| [creates](./creates.md) | No synopsis available |
| [Invoke-RefreshIdentityUser](./Invoke-RefreshIdentityUser.md) | No documentation available |
| [removes](./removes.md) | No synopsis available |
| [removes](./removes.md) | No synopsis available |
| [removes](./removes.md) | No synopsis available |
| [removes](./removes.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [sends](./sends.md) | No synopsis available |
| [sends](./sends.md) | No synopsis available |

