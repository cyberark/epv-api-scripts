# adds

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance. Can also be specified using the alias 'url' or 'PCloudURL'.

### -LogonToken
The authentication token used for API requests. Can also be specified using the alias 'header'.

### -User
The username of the user to add to the vault. This parameter is mandatory and can be provided via pipeline.
Can also be specified using the alias 'Member'.

### -Force
When specified, suppresses confirmation prompts and proceeds with the operation automatically.

## Examples

### Example 1
```powershell
Add-VaultUser -PVWAURL "https://pvwa.example.com" -LogonToken $token -User "john.doe"

Adds the user "john.doe" to the vault with confirmation prompt.
```

### Example 2
```powershell
Add-VaultUser -PVWAURL "https://pvwa.example.com" -LogonToken $token -User "jane.smith" -Force

Adds the user "jane.smith" to the vault without confirmation prompt.
```

### Example 3
```powershell
"john.doe", "jane.smith" | Add-VaultUser -PVWAURL "https://pvwa.example.com" -LogonToken $token

Adds multiple users to the vault via pipeline input.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\User\Core\Add-VaultUser.ps1*
