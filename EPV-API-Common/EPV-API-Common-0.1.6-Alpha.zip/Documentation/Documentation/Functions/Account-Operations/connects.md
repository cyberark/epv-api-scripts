# connects

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The logon token used for authentication with the PVWA API.

### -AccountID
The account ID of the master account.

### -Search
List of keywords separated with space to search in dependent accounts.

### -Filter
Filter to apply when searching dependent accounts.

### -FailedOnly
Get only failed dependent accounts.

## Examples

### Example 1
```powershell
Get-DependentAccount -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34"

Retrieves all dependent accounts for the master account with ID "12_34".
```

### Example 2
```powershell
Get-DependentAccount -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34" -FailedOnly $true

Retrieves only failed dependent accounts for the master account with ID "12_34".
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Account\Linking\Get-DependentAccount.ps1*
