# establishes

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -Username
Specifies the username to connect with as a string. This parameter is used in the 'PVWAURL', 'PCloudSubdomain', and 'PCloudURL' parameter sets.

### -Password
Specifies the password to connect with, stored as a SecureString. This parameter is used in the 'PVWAURL', 'PCloudSubdomain', and 'PCloudURL' parameter sets.

### -Creds
Specifies the credentials stored as PSCredentials. This parameter is used in the 'PVWAURL', 'PCloudSubdomain', and 'PCloudURL' parameter sets.

### -PVWAURL
Specifies the URL to the PVWA. This parameter is mandatory in the 'PVWAURL' parameter set.

### -PCloudURL
Specifies the URL to the Privileged Cloud. This parameter is mandatory in the 'PCloudURL' parameter set.

### -PCloudSubdomain
Specifies the subdomain for the Privileged Cloud. This parameter is mandatory in the 'PCloudSubdomain' parameter set.

### -IdentityURL
Specifies the URL for CyberArk Identity. This parameter is used in the 'PCloudURL' and 'PCloudSubdomain' parameter sets.

### -OAuthCreds
Specifies the OAuth credentials stored as PSCredentials. This parameter is used in the 'PCloudURL' and 'PCloudSubdomain' parameter sets.

### -LogFile
Specifies the log file name. The default value is ".\Log.Log".

### -OutputResults
Switch parameter that enables success output logging. When specified, successful operations will be logged to the console and/or success file.

### -UseResultFile
Switch parameter that enables logging of successful operations to a separate success file. Works in conjunction with OutputResults to provide detailed success tracking.

### -UseErrorFile
Switch parameter that enables logging of error operations to a separate success file.

## Examples

### Example 1
```powershell
New-Session -Username "admin" -Password (ConvertTo-SecureString "password" -AsPlainText -Force) -PVWAURL "https://pvwa.example.com"
```

### Example 2
```powershell
New-Session -Creds (Get-Credential) -PCloudURL "https://cloud.example.com" -IdentityURL "https://identity.example.com"
```

### Example 3
```powershell
New-Session -Username "admin" -Password (ConvertTo-SecureString "password" -AsPlainText -Force) -PVWAURL "https://pvwa.example.com" -OutputResults -UseResultFile

Creates a new session with success logging enabled, which will output successful operations to both console and a success file.
```

## Notes
This function sets default parameter values for subsequent commands in the session, including logon tokens and URLs.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Shared\New-Session.ps1*
