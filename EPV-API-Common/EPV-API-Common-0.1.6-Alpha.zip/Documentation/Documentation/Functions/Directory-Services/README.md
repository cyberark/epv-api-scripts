# Directory Services Functions

This section contains 1 functions related to Directory Services.

## Functions in this Category
- [Get-DirectoryService](./Get-DirectoryService.md) - Get Identity Directories

## Quick Reference

| Function | Synopsis |
|----------|----------|| [Get-DirectoryService](./Get-DirectoryService.md) | Get Identity Directories |

