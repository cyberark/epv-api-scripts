# updates

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -DiscoveryURL
The URL of the CyberArk Discovery Management service in the format https://<subdomain>.discoverymgmt.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -ScanDefinitionID
The unique identifier of the scan definition to update (mandatory).

### -Name
The name of the scan definition (mandatory). Must be up to 100 alphanumeric characters including spaces and underscore, dash, period, and at signs (_ - . @). Must begin and end with a valid character and not a space.

### -Type
The scan type to use for this scan definition (mandatory). Valid values: WIN_NIX_LIST, WIN_NIX_DOMAIN.

### -Domain
The domain name for the scan (mandatory for domain scans, optional for list scans). Example: "company.com"

### -OU
Organizational Unit for domain scans (optional). Discovery scans the entire AD domain for machines and users defined at the AD level, directly in the OU, and in all the AD groups within the OU. Example: "dc=domain,dc=com" or "cn=Marketing,cn=Users,dc=mydomain,dc=com"

### -ResourceId
The unique ID for a machine list file that is used for file-based discovery scans (mandatory for WIN_NIX_LIST scans).

### -DomainControllerTarget
Include domain controllers in the scan targets (default: true for domain scans).

### -NonPrivilegedTarget
Include non-privileged machines in the scan targets (default: true for domain scans).

### -GroupsTarget
Include AD groups in the scan (default: true for domain scans).

### -Properties
A hashtable of additional properties that define the scan (optional). Use this for properties not covered by individual parameters.

### -Credentials
The credentials used to run the scan and access the targets. Array of credential objects with name, type, and properties.

### -NetworkId
The network ID selected by the customer. The network must be defined in Connector Management and assigned to a connector pool with at least one connector. Mandatory for list scans, optional for domain scans.

### -NetworkName
The network name selected by the customer. Alternative to NetworkId - the function will resolve the name to an ID using Get-ConnectorNetwork. The network must be defined in Connector Management and assigned to a connector pool with at least one connector.

### -CMURL
The URL of the CyberArk Connector Management service. Required when using NetworkName to resolve network names to IDs. Can be automatically derived from PCloudURL using Get-CMURL helper function.

### -RecurrenceType
Determines the recurrence policy of the scan (mandatory). Valid values: IMMEDIATE, SCHEDULED, RECURRING.

### -Tags
User-defined tags that are added to accounts discovered in this scan. Up to 20 tags for domain scan, up to 10 tags for list scan. Alphanumeric strings (no spaces, can include underscore _).

### -AdditionalProperties
Additional properties to include in the scan definition request body (optional).

## Examples

### Example 1
```powershell
# Update a Windows/nix domain scan
Set-ScanDefinition -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -ScanDefinitionID "9d963737-b704-4c63-bba9-17d8236691f6" -Name "Updated-Windows-nix-scan" -Type "WIN_NIX_DOMAIN" -Domain "updated-company.com" -OU "cn=updated-group" -DomainControllerTarget $true -NonPrivilegedTarget $false -GroupsTarget $true -RecurrenceType "SCHEDULED"
```

### Example 2
```powershell
# Update a list scan with network name
Set-ScanDefinition -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -ScanDefinitionID "9d963737-b704-4c63-bba9-17d8236691f6" -Name "Updated-List-Scan" -Type "WIN_NIX_LIST" -ResourceId "c2601488-7e2c-4d82-a5b8-9c59cfa869cd" -NetworkName "Production Network" -CMURL "https://subdomain.connectormanagement.cyberark.cloud/api/pool-service" -RecurrenceType "SCHEDULED"
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\DiscoveryManagement\Set-ScanDefinition.ps1*
