# adds

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -DiscoveryURL
The URL of the CyberArk Discovery Management service in the format https://<subdomain>.discoverymgmt.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -ApplyOn
Parameter to specify what the rule set applies to.

### -InputObject
The discovery rule set data to add. This should be a hashtable or PSCustomObject containing the rule set information.

## Examples

### Example 1
```powershell
$ruleSetData = @{
    name = "Windows Discovery Rules"
    status = "ACTIVE"
    rules = @(
        @{
            name = "Onboard Admin Accounts"
            action = @{
                type = "ONBOARD"
                parameters = @{
                    safeName = "DiscoveredAccounts"
                    platformId = "WinDomain"
                }
            }
        }
    )
}
New-DiscoveryRuleSet -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -ApplyOn "discovered_accounts" -InputObject $ruleSetData
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Discovery\New-DiscoveryRuleSet.ps1*
