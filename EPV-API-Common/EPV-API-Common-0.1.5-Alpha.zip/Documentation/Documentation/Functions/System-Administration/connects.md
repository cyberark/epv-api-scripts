# connects

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The logon token used for authentication with the PVWA API.

### -AccountID
The unique ID of the account to retrieve and use to connect to the target system through PSM.

### -Reason
The reason for connecting to the account.

### -TicketID
The ticket ID for connecting to the account.

### -ConnectionComponent
The name of the connection component to use.

### -AllowMappingLocalDrives
Whether to allow mapping of local drives.

### -AllowConnectToConsole
Whether to allow connection to console.

### -RedirectSmartCards
Whether to redirect smart cards.

### -PSMRemoteApp
The PSM remote application to use.

### -LogonDomain
The logon domain for the connection.

### -AllowSelectHTML5
Whether to allow HTML5 selection.

## Examples

### Example 1
```powershell
Connect-AccountPSM -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34" -Reason "Maintenance"

Connects to account with ID "12_34" through PSM with the reason "Maintenance".
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\PSM\Connect-AccountPSM.ps1*
