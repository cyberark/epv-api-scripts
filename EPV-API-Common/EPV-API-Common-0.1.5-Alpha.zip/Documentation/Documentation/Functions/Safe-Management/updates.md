# updates

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The authentication token required to log on to the PVWA.

### -safeName
The name of the safe to be updated.

### -description
The new description for the safe.

### -location
The new location for the safe.

### -olacEnabled
A switch parameter to enable or disable OLAC for the safe.

### -managingCPM
The name of the CPM (Central Policy Manager) managing the safe.

### -numberOfVersionsRetention
The number of versions to retain for the safe.

### -numberOfDaysRetention
The number of days to retain the safe.

## Examples

### Example 1
```powershell
Set-Safe -PVWAURL "https://pvwa.example.com" -LogonToken $token -safeName "FinanceSafe" -description "Updated description" -location "New York" -olacEnabled -managingCPM "CPM1" -numberOfVersionsRetention "5" -numberOfDaysRetention "30"

This example updates the safe named "FinanceSafe" with a new description, location, and other properties.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Safe\Core\Set-Safe.ps1*
