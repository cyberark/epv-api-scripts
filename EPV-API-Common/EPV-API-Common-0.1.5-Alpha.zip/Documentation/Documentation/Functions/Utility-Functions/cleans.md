# cleans

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -message
The string message from which to remove or mask sensitive data. This parameter is mandatory.
Can also be specified using the aliases 'MSG', 'value', or 'string'.

## Examples

### Example 1
```powershell
Remove-SensitiveData -message "User logged in with password: secret123"

Returns a cleaned version of the message with the password value masked or removed.
```

### Example 2
```powershell
$logMessage = "API call with Authorization: Bearer token123"
Remove-SensitiveData -message $logMessage

Masks the authorization token in the log message.
```

### Example 3
```powershell
"password=mypassword&username=john" | Remove-SensitiveData

Processes the string via pipeline input to mask sensitive parameters.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Shared\Remove-SensitiveData.ps1*
