# EPV-API-Common Troubleshooting Guide

This guide covers common issues, solutions, and best practices for troubleshooting problems with the EPV-API-Common PowerShell module.

## Table of Contents

- [Installation Issues](#installation-issues)
- [Authentication Problems](#authentication-problems)
- [Connection and Network Issues](#connection-and-network-issues)
- [Permission and Authorization Errors](#permission-and-authorization-errors)
- [Performance Issues](#performance-issues)
- [Logging and Debugging](#logging-and-debugging)
- [Common Error Messages](#common-error-messages)
- [Best Practices](#best-practices)

## Installation Issues

### Module Not Found After Installation

**Problem**: PowerShell cannot find the EPV-API-Common module after installation.

**Solutions**:

1. **Check Module Path**:
   ```powershell
   $env:PSModulePath -split ';'
   Get-Module -ListAvailable -Name EPV-API-Common
   ```

2. **Verify Installation Location**:
   ```powershell
   # Check user module path
   Test-Path "$env:USERPROFILE\Documents\PowerShell\Modules\EPV-API-Common"
   
   # Check system module path
   Test-Path "$env:ProgramFiles\PowerShell\Modules\EPV-API-Common"
   ```

3. **Force Module Refresh**:
   ```powershell
   Remove-Module EPV-API-Common -Force -ErrorAction SilentlyContinue
   Import-Module EPV-API-Common -Force
   ```

### Permission Denied During Installation

**Problem**: Access denied errors when installing to system paths.

**Solutions**:

1. **Use User Installation**:
   ```powershell
   .\Install-Module.ps1 -UserScope
   ```

2. **Run as Administrator** (for system installation):
   ```powershell
   # Right-click PowerShell and "Run as Administrator"
   .\Install-Module.ps1
   ```

3. **Check Installation Path Permissions**:
   ```powershell
   Test-Path "$env:ProgramFiles\PowerShell\Modules" -IsValid
   ```

### PowerShell Version Compatibility

**Problem**: Module requires PowerShell 7.4+ but older version is installed.

**Solutions**:

1. **Check PowerShell Version**:
   ```powershell
   $PSVersionTable.PSVersion
   ```

2. **Install PowerShell 7.4+**:
   - Download from: https://github.com/PowerShell/PowerShell/releases
   - Use winget: `winget install Microsoft.PowerShell`

## Authentication Problems

### Session Creation Failures

**Problem**: New-Session fails with authentication errors.

**Diagnostic Steps**:

1. **Test Connectivity**:
   ```powershell
   Test-NetConnection -ComputerName "pvwa.company.com" -Port 443
   ```

2. **Verify Credentials**:
   ```powershell
   # Test with verbose output
   $session = New-Session -PVWAURL "https://pvwa.company.com" -Username "admin" -Password $securePassword -Verbose
   ```

3. **Check URL Format**:
   ```powershell
   # Correct formats
   $pvwaURL = "https://pvwa.company.com"  # On-premises
   $pcloudURL = "https://company.privilegecloud.cyberark.com"  # Privileged Cloud
   ```

### Token Expiration

**Problem**: Functions fail with "Unauthorized" after working initially.

**Solutions**:

1. **Check Token Validity**:
   ```powershell
   # Test with a simple API call
   Get-SystemHealth -PVWAURL $session.PVWAURL -LogonToken $session.LogonToken -Summary
   ```

2. **Recreate Session**:
   ```powershell
   $session = New-Session -PVWAURL $pvwaURL -Username $username -Password $password
   ```

3. **Implement Token Refresh Logic**:
   ```powershell
   function Invoke-WithRetry {
       param($ScriptBlock, $Session)
       try {
           & $ScriptBlock
       }
       catch {
           if ($_.Exception.Message -match "Unauthorized|401") {
               Write-LogMessage -MSG "Token expired, refreshing session" -type Warning
               $Session = New-Session -PVWAURL $Session.PVWAURL -Username $username -Password $password
               & $ScriptBlock
           }
           else { throw }
       }
   }
   ```

### Multi-Factor Authentication (MFA)

**Problem**: Authentication fails when MFA is required.

**Solutions**:

1. **Use Service Account** (recommended for automation):
   ```powershell
   # Create a service account without MFA requirement
   $session = New-Session -PVWAURL $pvwaURL -Username "svc_api" -Password $servicePassword
   ```

2. **Check MFA Bypass Settings** in CyberArk for API access.

3. **Use Certificate Authentication** where supported:
   ```powershell
   # For certificate-based authentication
   $session = New-Session -PVWAURL $pvwaURL -Certificate $clientCert
   ```

## Connection and Network Issues

### SSL/TLS Certificate Errors

**Problem**: Certificate validation failures.

**Diagnostic Steps**:

1. **Test Certificate**:
   ```powershell
   $uri = "https://pvwa.company.com"
   $request = [System.Net.WebRequest]::Create($uri)
   try { $request.GetResponse() } catch { $_.Exception.Message }
   ```

2. **Temporary Certificate Bypass** (development only):
   ```powershell
   # WARNING: Only for development/testing
   [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
   ```

3. **Install Proper Certificates**:
   ```powershell
   # Import certificate to trusted root store
   Import-Certificate -FilePath "C:\path\to\certificate.crt" -CertStoreLocation Cert:\LocalMachine\Root
   ```

### Proxy Configuration

**Problem**: Requests fail due to corporate proxy.

**Solutions**:

1. **Configure PowerShell Proxy**:
   ```powershell
   $proxy = New-Object System.Net.WebProxy("http://proxy.company.com:8080")
   $proxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials
   [System.Net.WebRequest]::DefaultWebProxy = $proxy
   ```

2. **Use System Proxy Settings**:
   ```powershell
   [System.Net.WebRequest]::DefaultWebProxy = [System.Net.WebRequest]::GetSystemWebProxy()
   ```

### Timeout Issues

**Problem**: Operations timeout on slow networks.

**Solutions**:

1. **Increase Timeout Values**:
   ```powershell
   # Configure longer timeouts in session
   $session = New-Session -PVWAURL $pvwaURL -Username $username -Password $password -TimeoutSec 300
   ```

2. **Implement Retry Logic**:
   ```powershell
   function Invoke-WithRetry {
       param($ScriptBlock, $MaxRetries = 3, $DelaySeconds = 5)
       for ($i = 1; $i -le $MaxRetries; $i++) {
           try {
               return & $ScriptBlock
           }
           catch {
               if ($i -eq $MaxRetries) { throw }
               Write-LogMessage -MSG "Attempt $i failed, retrying in $DelaySeconds seconds" -type Warning
               Start-Sleep -Seconds $DelaySeconds
           }
       }
   }
   ```

## Permission and Authorization Errors

### Insufficient Permissions

**Problem**: "Access denied" or "Forbidden" errors.

**Diagnostic Steps**:

1. **Check User Permissions**:
   ```powershell
   Get-VaultUser -PVWAURL $session.PVWAURL -LogonToken $session.LogonToken -UserName $session.Username
   ```

2. **Verify Safe Access**:
   ```powershell
   Get-Safe -PVWAURL $session.PVWAURL -LogonToken $session.LogonToken -SafeName "TestSafe"
   ```

3. **Check Required Permissions** for specific operations:
   - **Account Management**: UseAccounts, RetrieveAccounts, ListAccounts
   - **Safe Management**: ManageSafe, ManageSafeMembers
   - **User Management**: AddUpdateUsers, ResetUsersPasswords

### Safe Member Permission Issues

**Problem**: Cannot perform operations on accounts in specific safes.

**Solutions**:

1. **Check Safe Membership**:
   ```powershell
   $members = Get-SafeMember -PVWAURL $session.PVWAURL -LogonToken $session.LogonToken -SafeName "YourSafe"
   $members | Where-Object { $_.memberName -eq $session.Username }
   ```

2. **Verify Required Permissions**:
   ```powershell
   # Example: Check if user can retrieve accounts
   $member = Get-SafeMember -SafeName "YourSafe" -memberName $session.Username
   if (-not $member.permissions.retrieveAccounts) {
       Write-LogMessage -MSG "User lacks retrieveAccounts permission" -type Error
   }
   ```

## Performance Issues

### Slow API Responses

**Problem**: Functions take too long to complete.

**Solutions**:

1. **Use Filtering and Pagination**:
   ```powershell
   # Instead of getting all accounts
   $accounts = Get-Account -PVWAURL $session.PVWAURL -LogonToken $session.LogonToken -Filter "safeName eq 'SpecificSafe'" -Limit 100
   ```

2. **Parallel Processing** for bulk operations:
   ```powershell
   $accounts | ForEach-Object -Parallel {
       Get-AccountPassword -PVWAURL $using:session.PVWAURL -LogonToken $using:session.LogonToken -AccountID $_.id
   } -ThrottleLimit 5
   ```

3. **Cache Frequently Used Data**:
   ```powershell
   # Cache platform information
   if (-not $global:PlatformCache) {
       $global:PlatformCache = Get-Platform -PVWAURL $session.PVWAURL -LogonToken $session.LogonToken
   }
   ```

### Memory Usage Issues

**Problem**: High memory consumption with large datasets.

**Solutions**:

1. **Use Pipeline Processing**:
   ```powershell
   # Process items one at a time instead of loading all into memory
   Get-Account -PVWAURL $session.PVWAURL -LogonToken $session.LogonToken | 
       ForEach-Object { Process-Account $_ }
   ```

2. **Dispose of Large Objects**:
   ```powershell
   $largeResult = Get-LargeDataset
   # Process data
   $largeResult = $null
   [System.GC]::Collect()
   ```

## Logging and Debugging

### Enable Comprehensive Logging

```powershell
# Set log file location
$logFile = "C:\Logs\EPV-API-Common-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"

# Enable verbose logging
$VerbosePreference = 'Continue'

# Enable sensitive data logging (debugging only - security risk)
$global:LogSensitiveData = $true

# Use detailed logging in functions
Write-LogMessage -MSG "Starting operation" -type Info -LogFile $logFile -Verbose
```

### Debug API Calls

```powershell
# Enable web request tracing
$DebugPreference = 'Continue'

# Monitor HTTP traffic (use Fiddler or similar tools)

# Add custom debugging to API calls
function Debug-APICall {
    param($Uri, $Method, $Headers, $Body)
    Write-LogMessage -MSG "API Call: $Method $Uri" -type Debug
    Write-LogMessage -MSG "Headers: $($Headers | ConvertTo-Json)" -type Debug
    if ($Body) { Write-LogMessage -MSG "Body: $Body" -type Debug }
}
```

### Trace Function Execution

```powershell
# Enable PowerShell execution tracing
Set-PSDebug -Trace 1

# Or use more targeted tracing
$executionContext.SessionState.PSVariable.Set('DebugPreference', 'Continue')
```

## Common Error Messages

### "The remote server returned an error: (401) Unauthorized"

**Causes and Solutions**:
- **Expired session**: Recreate session with `New-Session`
- **Invalid credentials**: Verify username/password
- **Account locked**: Check account status in CyberArk
- **Wrong URL**: Verify PVWA URL format

### "The remote server returned an error: (403) Forbidden"

**Causes and Solutions**:
- **Insufficient permissions**: Check user/safe permissions
- **IP restrictions**: Verify allowed IP ranges
- **Time restrictions**: Check if access is time-limited

### "Unable to connect to the remote server"

**Causes and Solutions**:
- **Network connectivity**: Test with `Test-NetConnection`
- **Firewall blocking**: Check firewall rules
- **Service down**: Verify CyberArk services are running
- **DNS resolution**: Test hostname resolution

### "Object reference not set to an instance of an object"

**Causes and Solutions**:
- **Null session**: Ensure session is properly created
- **Empty response**: Check if API returned data
- **Pipeline issues**: Verify pipeline input is not null

## Best Practices

### Error Handling

```powershell
function Invoke-SafeAPICall {
    param($ScriptBlock, $ErrorMessage)
    try {
        return & $ScriptBlock
    }
    catch {
        $errorDetails = @{
            Function = $MyInvocation.MyCommand.Name
            Error = $_.Exception.Message
            Line = $_.InvocationInfo.ScriptLineNumber
            Time = Get-Date
        }
        Write-LogMessage -MSG "$ErrorMessage : $($errorDetails | ConvertTo-Json)" -type Error
        throw
    }
}
```

### Session Management

```powershell
# Always test session before use
function Test-Session {
    param($Session)
    try {
        Get-SystemHealth -PVWAURL $Session.PVWAURL -LogonToken $Session.LogonToken -Summary | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

# Use session validation
if (-not (Test-Session $session)) {
    Write-LogMessage -MSG "Session invalid, recreating" -type Warning
    $session = New-Session -PVWAURL $pvwaURL -Username $username -Password $password
}
```

### Resource Cleanup

```powershell
# Always clean up resources
try {
    # Your operations here
}
finally {
    # Clean up
    if ($session) {
        # Log out if session supports it
        Remove-Variable session -ErrorAction SilentlyContinue
    }
    
    # Clean up temporary files
    Remove-Item -Path $tempFiles -ErrorAction SilentlyContinue
}
```

### Security

```powershell
# Never log sensitive data in production
$global:LogSensitiveData = $false

# Use secure strings for passwords
$securePassword = Read-Host -AsSecureString "Enter password"

# Validate SSL certificates in production
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
```

## Getting Help

### Module Help

```powershell
# Get help for specific functions
Get-Help Get-Account -Detailed
Get-Help New-Session -Full
Get-Help Set-SafeMember -Examples

# List all module functions
Get-Command -Module EPV-API-Common

# Get module information
Get-Module EPV-API-Common
```

### Enable Detailed Logging

```powershell
# For detailed troubleshooting
$VerbosePreference = 'Continue'
$DebugPreference = 'Continue'
$ErrorActionPreference = 'Stop'

# Set comprehensive log file
$Script:LogFile = "C:\Logs\EPV-Detailed-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
```

## Additional Resources

- **Function Reference**: See `Documentation/Functions/` directory
- **Examples**: See `Documentation/Examples/` directory
- **CyberArk Documentation**: Official CyberArk API documentation
- **PowerShell Help**: Use `Get-Help` for detailed function information

Remember to always follow your organization's security policies and never expose sensitive information in logs or error messages in production environments.