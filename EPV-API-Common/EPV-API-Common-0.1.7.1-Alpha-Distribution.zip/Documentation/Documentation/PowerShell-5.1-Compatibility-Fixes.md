# PowerShell 5.1 Compatibility Fixes for Install-Module.ps1

## Issue
Users reported errors when running `Install-Module.ps1` from the distribution package in **PowerShell 5.1** (Windows PowerShell).

## Root Causes Identified

### 1. **Incorrect Module Paths**
- **Problem**: The script used `PowerShell\Modules` for all PowerShell versions
- **Impact**: PowerShell 5.1 uses `WindowsPowerShell\Modules`, not `PowerShell\Modules`
- **Fix**: Added version detection to use correct path:
  - PowerShell 5.1: `WindowsPowerShell\Modules`
  - PowerShell 7+: `PowerShell\Modules`

### 2. **Unix Shebang Line**
- **Problem**: Script started with `#!/usr/bin/env pwsh`
- **Impact**: Not needed for Windows and can cause issues in some environments
- **Fix**: Removed the shebang line

### 3. **Unguarded $IsWindows Variable**
- **Problem**: Direct use of `$IsWindows` variable
- **Impact**: This variable doesn't exist in PowerShell 5.1
- **Fix**: Added proper guard with fallback:
  ```powershell
  $isWindowsOS = if (Get-Variable -Name 'IsWindows' -ErrorAction SilentlyContinue) {
      $IsWindows
  } else {
      $true  # Assume Windows if variable doesn't exist
  }
  ```

### 4. **Unicode Emojis**
- **Problem**: Used Unicode emojis (✅, ❌, ⚠️, 💡, 📦, 🎉)
- **Impact**: May not render correctly in older console windows
- **Fix**: Replaced with ASCII text markers:
  - `✅` → `[SUCCESS]`
  - `❌` → `[ERROR]`
  - `⚠️` → `[WARNING]`
  - `💡` → Plain text
  - `📦` → Plain text
  - `🎉` → Plain text

## Files Updated

1. **G:\EPV-API-Common-5.1\Distribution\Install-Module.ps1** [UPDATED]
2. **G:\EPV-API-Common-5.1\Scripts\Install-Module.ps1** [UPDATED]

## Verification

A comprehensive test script was created: `G:\EPV-API-Common-5.1\Tests\Test-InstallScript.ps1`

### Test Results
```
[PASS] TEST 1: Script file exists
[PASS] TEST 2: Syntax validation in PowerShell 7.5.4
[PASS] TEST 3: No unguarded PowerShell Core syntax
[PASS] TEST 4: Module path detection is correct
[PASS] TEST 5: No Unicode emojis found
[PASS] TEST 6: Script loads in PowerShell 5.1
[PASS] TEST 7: Module manifest is valid
```

## Compatibility Matrix

| Feature | PowerShell 5.1 | PowerShell 7+ |
|---------|----------------|---------------|
| System Install | Supported | Supported |
| User Install | Supported | Supported |
| Version Detection | Supported | Supported |
| Admin Check | Supported | Supported |
| Force Overwrite | Supported | Supported |
| Verbose Output | Supported | Supported |

## Usage Examples

### PowerShell 5.1 (Windows PowerShell)
```powershell
# User installation (no admin required)
cd Distribution
.\Install-Module.ps1 -UserScope

# System installation (requires admin)
.\Install-Module.ps1

# Force reinstall
.\Install-Module.ps1 -UserScope -Force
```

### PowerShell 7+
```powershell
# Same commands work identically
.\Install-Module.ps1 -UserScope
```

## Installation Paths

### PowerShell 5.1
- **User**: `%USERPROFILE%\Documents\WindowsPowerShell\Modules\EPV-API-Common`
- **System**: `C:\Program Files\WindowsPowerShell\Modules\EPV-API-Common`

### PowerShell 7+
- **User**: `%USERPROFILE%\Documents\PowerShell\Modules\EPV-API-Common`
- **System**: `C:\Program Files\PowerShell\Modules\EPV-API-Common`

## Testing Instructions

To test the install script before distribution:

```powershell
# Run compatibility tests
.\Tests\Test-InstallScript.ps1

# Test in PowerShell 5.1
powershell.exe -Version 5.1 -File .\Distribution\Install-Module.ps1 -UserScope

# Test in PowerShell 7+
pwsh -File .\Distribution\Install-Module.ps1 -UserScope
```

## Distribution Rebuild

The distribution has been rebuilt with the fixes included:
```powershell
# Build distribution with documentation
.\Scripts\Build-Distribution.ps1 -IncludeDocumentation
```

## Next Steps

1. **Package the distribution** - The fixed `Install-Module.ps1` is now included
2. **Test installation** - Verify on clean systems with both PS 5.1 and PS 7+
3. **Update documentation** - Ensure installation docs reflect PowerShell 5.1 support
4. **Release notes** - Document the compatibility improvements

## Support

If users still encounter issues:

1. **Check PowerShell version**: `$PSVersionTable.PSVersion`
2. **Verify paths**: Ensure the correct module path is used
3. **Check permissions**: Use `-UserScope` if not admin
4. **Enable verbose output**: Use `-Verbose` flag for detailed logs

---

**Last Updated**: November 21, 2025
**Module Version**: 0.1.7.0-Alpha
**Tested On**: Windows PowerShell 5.1, PowerShell 7.5.4
