# adds

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -LogonToken
The logon token for authentication.

### -SafeName
The name of the safe to which the member will be added.

### -memberName
The name of the member to be added to the safe.

### -searchIn
The search scope for the member.

### -MemberType
The type of the member (User, Group, Role).

### -membershipExpirationDate
The expiration date of the membership.

### -useAccounts
Permission to use accounts.

### -retrieveAccounts
Permission to retrieve accounts.

### -listAccounts
Permission to list accounts.

### -addAccounts
Permission to add accounts.

### -updateAccountContent
Permission to update account content.

### -updateAccountProperties
Permission to update account properties.

### -initiateCPMAccountManagementOperations
Permission to initiate CPM account management operations.

### -specifyNextAccountContent
Permission to specify next account content.

### -renameAccounts
Permission to rename accounts.

### -deleteAccounts
Permission to delete accounts.

### -unlockAccounts
Permission to unlock accounts.

### -manageSafe
Permission to manage the safe.

### -manageSafeMembers
Permission to manage safe members.

### -backupSafe
Permission to backup the safe.

### -viewAuditLog
Permission to view the audit log.

### -viewSafeMembers
Permission to view safe members.

### -accessWithoutConfirmation
Permission to access without confirmation.

### -createFolders
Permission to create folders.

### -deleteFolders
Permission to delete folders.

### -moveAccountsAndFolders
Permission to move accounts and folders.

### -requestsAuthorizationLevel1
Permission for requests authorization level 1.

### -requestsAuthorizationLevel2
Permission for requests authorization level 2.

## Examples

### Example 1
```powershell
Add-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "Finance" -memberName "JohnDoe" -MemberType "User" -useAccounts $true
```

## Notes
This function requires the PVWA URL and a valid logon token for authentication.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\SafeMember\Core\Add-SafeMember.ps1*
