# modifies

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance. Can also be specified using the aliases 'url' or 'PCloudURL'.

### -LogonToken
The authentication token used for API requests. Can also be specified using the alias 'header'.

### -SafeName
The name of the safe containing the member to update. This parameter is mandatory.
Can also be specified using the alias 'Safe'.

### -memberObject
A member object containing all the properties to update. Used in the 'memberObject' parameter set.
Can also be specified using the alias 'SafeMember'.

### -memberName
The name of the member to update. Used in the 'memberName' parameter set.
Can also be specified using the alias 'User'.

### -searchIn
The search location for the member (e.g., domain name).

### -MemberType
The type of member being updated. Valid values are 'User', 'Group', or 'Role'.

### -membershipExpirationDate
The expiration date for the member's access to the safe, specified as an integer (Unix timestamp).

### -useAccounts
Boolean value indicating whether the member can use accounts in the safe.

### -retrieveAccounts
Boolean value indicating whether the member can retrieve account passwords.

## Examples

### Example 1
```powershell
Set-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "IT-Safe" -memberName "john.doe" -useAccounts $true -retrieveAccounts $false

Updates permissions for user "john.doe" in the "IT-Safe", allowing account usage but not password retrieval.
```

### Example 2
```powershell
Set-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "Admin-Safe" -memberName "AdminGroup" -MemberType "Group" -listAccounts $true -addAccounts $true

Updates permissions for the "AdminGroup" in the "Admin-Safe", allowing them to list and add accounts.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\SafeMember\Core\Set-SafeMember.ps1*
