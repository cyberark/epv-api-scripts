# queries

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -UPN
The User Principal Name to look up in Active Directory. This parameter accepts pipeline input.

### -NoErrorOnNull
When specified, suppresses errors if the user is not found in Active Directory.

## Examples

### Example 1
```powershell
Get-SamAccountName -UPN "jdoe@domain.com"

Returns the SAM Account Name for the user with UPN "jdoe@domain.com", such as "jdoe".
```

### Example 2
```powershell
"jdoe@domain.com", "jsmith@domain.com" | Get-SamAccountName

Retrieves SAM Account Names for multiple users via pipeline input.
```

### Example 3
```powershell
Get-SamAccountName -UPN "nonexistent@domain.com" -NoErrorOnNull

Attempts to find the SAM Account Name for a UPN, but won't generate an error if the user doesn't exist.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Shared\Get-SamAccountName.ps1*
