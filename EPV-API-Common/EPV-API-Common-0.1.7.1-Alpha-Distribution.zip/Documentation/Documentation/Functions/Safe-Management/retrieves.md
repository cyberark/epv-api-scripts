# retrieves

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The logon token for authentication.

### -SafeUrlId
The ID of the safe to retrieve.

### -SafeName
The name of the safe to retrieve.

### -PlatformID
The ID of the platform to retrieve safes for.

### -AllSafes
Switch to retrieve all safes.

### -ExtendedDetails
Switch to include extended details in the results.

### -includeAccounts
Switch to include accounts in the results.

### -useCache
Switch to use cached results.

### -Search
A search string to filter the results.

### -offset
The offset for pagination.

### -limit
The limit for pagination.

### -DoNotPage
Switch to disable pagination.

### -sort
The sort order for the results. Valid values are "asc" and "desc".

## Examples

### Example 1
```powershell
Get-Safe -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeUrlId "12345"
    Retrieves the safe with ID 12345.
```

### Example 2
```powershell
Get-Safe -PVWAURL "https://pvwa.example.com" -LogonToken $token -AllSafes
    Retrieves all safes.
```

### Example 3
```powershell
Get-Safe -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "MySafe" -PlatformID "Platform1"
    Retrieves the safe named "MySafe" for platform "Platform1".
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Safe\Core\Get-Safe.ps1*
