# removes

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -roleName
The name of the role to be removed from the users.

### -IdentityURL
The URL of the identity management system.

### -LogonToken
The authentication token required to log on to the identity management system.

### -User
An array of users from whom the role will be removed.

### -Force
A switch to bypass confirmation prompts.

## Examples

### Example 1
```powershell
PS> Remove-IdentityRoleFromUser -roleName "Admin" -IdentityURL "https://identity.example.com" -LogonToken $token -User "user1"

Removes the "Admin" role from "user1".
```

### Example 2
```powershell
PS> "user1", "user2" | Remove-IdentityRoleFromUser -roleName "Admin" -IdentityURL "https://identity.example.com" -LogonToken $token

Removes the "Admin" role from "user1" and "user2".
```

## Notes
This function requires the Write-LogMessage and Get-IdentityRole functions to be defined in the session.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Identity\Role\Remove-IdentityRoleFromUser.ps1*
