# retrieves

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The base URL of the PVWA API. This parameter is mandatory.

### -LogonToken
The authentication token required to access the PVWA API. This parameter is mandatory.

### -AccountID
The ID of the account for which linked accounts are to be retrieved. This parameter is mandatory when using the 'AccountID' parameter set.

### -accountObject
A switch parameter that, when specified, retrieves the linked accounts as account objects.

## Examples

### Example 1
```powershell
PS> Get-AccountLink -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_45"

Retrieves the linked accounts for the account with ID "12_45".
```

### Example 2
```powershell
PS> Get-AccountLink -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12345" -accountObject

Retrieves the linked accounts for the account with ID "12345" and returns them as account objects.
```

## Notes
This function requires the Write-LogMessage and Invoke-Rest functions to be defined in the session.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Account\Linking\Get-AccountLink.ps1*
