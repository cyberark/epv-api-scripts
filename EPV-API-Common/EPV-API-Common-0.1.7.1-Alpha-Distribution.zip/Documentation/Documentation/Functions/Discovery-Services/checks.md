# checks

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -DiscoveryURL
The URL of the CyberArk Discovery Management service in the format https://<subdomain>.discoverymgmt.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -InputObject
The account existence check data. This should be a hashtable or PSCustomObject containing the account identifiers to check.

## Examples

### Example 1
```powershell
$checkData = @{
    accounts = @(
        @{
            type = "Windows"
            identifiers = @{
                username = "admin"
                address = "server01.domain.com"
            }
        }
    )
}
Test-AccountExistence -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -InputObject $checkData
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Discovery\Test-AccountExistence.ps1*
