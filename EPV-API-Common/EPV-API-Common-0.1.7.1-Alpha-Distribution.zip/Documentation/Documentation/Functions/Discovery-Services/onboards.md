# onboards

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -DiscoveryURL
The URL of the CyberArk Discovery Management service in the format https://<subdomain>.discoverymgmt.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -AccountID
The discovered account ID to onboard.

### -SafeName
The name of the safe where the account will be stored (mandatory).

### -PlatformId
The platform ID that defines the account type and policies (mandatory).

### -AdditionalProperties
Additional properties to be set on the account that are not taken from the identifiers or customProperties of the discovered account (optional).

### -Secret
The initial secret value for the account (optional, defaults to empty string).

### -ResetSecret
An indication whether the account should be immediately rotated (reconcile or change depending on the type) (optional, defaults to true).

## Examples

### Example 1
```powershell
Start-DiscoveredAccountOnboard -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -AccountID "12345" -SafeName "DiscoveredAccounts" -PlatformId "WinDomain"
```

### Example 2
```powershell
$additionalProps = @{
    address = "server01.domain.com"
    userName = "admin"
}
Start-DiscoveredAccountOnboard -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -AccountID "12345" -SafeName "DiscoveredAccounts" -PlatformId "WinDomain" -AdditionalProperties $additionalProps -Secret "initialPassword" -ResetSecret $false
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Discovery\Start-DiscoveredAccountOnboardBulk.ps1*
