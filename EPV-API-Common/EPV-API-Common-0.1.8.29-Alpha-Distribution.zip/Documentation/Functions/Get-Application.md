---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-Application

## SYNOPSIS
Retrieves applications from the Vault.

## SYNTAX

```
Get-Application [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [[-AppID] <String>]
 [[-Location] <String>] [[-IncludeSublocations] <Boolean>] [-ProgressAction <ActionPreference>]
 [<CommonParameters>]
```

## DESCRIPTION
The Get-Application function retrieves a list of all applications or a filtered list based on the provided parameters.
The user running this command requires Audit Users permissions in the Vault.

## EXAMPLES

### EXAMPLE 1
```
Get-Application -PVWAURL "https://pvwa.example.com" -LogonToken $token
```

Retrieves all applications from the Vault.

### EXAMPLE 2
```
Get-Application -PVWAURL "https://pvwa.example.com" -LogonToken $token -AppID "MyApp" -Location "\Applications"
```

Retrieves the specific application "MyApp" from the "\Applications" location.

## PARAMETERS

### -AppID
The application name to filter by.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IncludeSublocations
Whether or not the search will be performed in sublocations of the specified location.
Default value: $true

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: True
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Location
The location of the application in the Vault hierarchy.
Default value: \

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA (Password Vault Web Access) API endpoint.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function uses the Invoke-Rest function to send a GET request to the PVWA API endpoint.
Requires Audit Users permissions in the Vault.

## RELATED LINKS
