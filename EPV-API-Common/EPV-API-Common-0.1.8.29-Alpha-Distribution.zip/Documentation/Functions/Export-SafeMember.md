---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Export-SafeMember

## SYNOPSIS
Exports safe member information to a CSV file.

## SYNTAX

```
Export-SafeMember [[-CSVPath] <String>] [-Force] [-Append] [-SafeMember] <SafeMember> [-includeSystemSafes]
 [[-CPMUser] <String[]>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Export-SafeMember function exports information about safe members to a specified CSV file.
It allows filtering out system safes and includes options to force overwrite the CSV file if it already exists.

## EXAMPLES

### EXAMPLE 1
```
Export-SafeMember -CSVPath "C:\Exports\SafeMembers.csv" -SafeMember $safeMember
```

This example exports the safe member information to "C:\Exports\SafeMembers.csv".

### EXAMPLE 2
```
$safeMembers | Export-SafeMember -CSVPath "C:\Exports\SafeMembers.csv" -Force
```

This example exports the safe member information from the pipeline to "C:\Exports\SafeMembers.csv",
forcing the overwrite of the file if it already exists.

## PARAMETERS

### -Append
{{ Fill Append Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -CPMUser
Specifies an array of CPM user names.
This parameter is hidden from the help documentation.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -CSVPath
Specifies the path to the CSV file where the safe member information will be exported.
Defaults to ".\SafeMemberExport.csv".

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: .\SafeMemberExport.csv
Accept pipeline input: False
Accept wildcard characters: False
```

### -Force
If specified, forces the overwrite of the CSV file if it already exists.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -includeSystemSafes
If specified, includes system safes in the export.
This parameter is hidden from the help documentation.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SafeMember
Specifies the safe member object to be exported.
This parameter is mandatory and accepts input from the pipeline.

```yaml
Type: SafeMember
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function logs verbose messages about its operations and handles errors gracefully.

## RELATED LINKS
