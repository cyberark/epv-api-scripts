---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# New-IdentityRole

## SYNOPSIS
Creates a new identity role.

## SYNTAX

```
New-IdentityRole [[-CatchAll] <Object>] [[-IdentityURL] <String>] [[-LogonToken] <Object>]
 [[-roleName] <String>] [[-Description] <String>] [[-RoleType] <String>] [[-Users] <String[]>]
 [[-Roles] <String[]>] [[-Groups] <String[]>] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
The \`New-IdentityRole\` function creates a new identity role with specified parameters such as role name, role type, users, roles, and groups.
It sends a POST request to the specified Identity URL to store the role.

## EXAMPLES

### EXAMPLE 1
```
New-IdentityRole -IdentityURL "https://identity.example.com" -LogonToken $token -roleName "Admin" -Description "Administrator role" -RoleType "PrincipalList" -Users "user1", "user2"
```

Creates a new role named "Admin" with the specified users.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Description
A description of the role.

```yaml
Type: String
Parameter Sets: (All)
Aliases: desc

Required: False
Position: 5
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Groups
An array of groups to be added to the role.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: Group

Required: False
Position: 9
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service where the role will be created.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -roleName
The name of the role to be created.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Roles
An array of roles to be added to the role.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: Role

Required: False
Position: 8
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -RoleType
The type of the role.
Valid values are 'PrincipalList', 'Script', and 'Everybody'.
Default is 'PrincipalList'.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: PrincipalList
Accept pipeline input: False
Accept wildcard characters: False
```

### -Users
An array of users to be added to the role.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: User

Required: False
Position: 7
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function supports ShouldProcess for safety and confirmation prompts.

## RELATED LINKS
