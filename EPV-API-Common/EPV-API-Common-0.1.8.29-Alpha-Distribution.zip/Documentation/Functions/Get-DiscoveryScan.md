---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-DiscoveryScan

## SYNOPSIS
Retrieves discovery scans.

## SYNTAX

```
Get-DiscoveryScan [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [[-TaskID] <String>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-DiscoveryScan function retrieves discovery scans from the CyberArk PVWA
via the PAM REST API.
Optionally retrieves a specific scan by its task ID.

## EXAMPLES

### EXAMPLE 1
```
Get-DiscoveryScan -PVWAURL "https://pvwa.example.com" -LogonToken $token
```

Returns all discovery scans.

### EXAMPLE 2
```
Get-DiscoveryScan -PVWAURL "https://pvwa.example.com" -LogonToken $token -TaskID "task_abc123"
```

Returns the specific discovery scan.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The base URL of the PVWA instance (e.g.
https://pvwa.example.com).

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -TaskID
The ID of a specific discovery scan task.
When specified, returns a single scan.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### Returns discovery scan object(s).
## NOTES

## RELATED LINKS
