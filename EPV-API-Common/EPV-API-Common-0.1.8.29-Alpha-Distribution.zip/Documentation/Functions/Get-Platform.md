---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-Platform

## SYNOPSIS
Retrieves platform information from the Vault.

## SYNTAX

### List (Default)
```
Get-Platform [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-Search <String>]
 [-PlatformType <String>] [-Active <Boolean>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-Platform [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -PlatformID <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-Platform function retrieves platform information from the PVWA API.
When called without a PlatformID it returns a list of all platforms (optionally
filtered by search text and/or platform type).
When called with a PlatformID it
returns the detailed information for that specific platform.

The user who runs this must be a member of the Vault Admins group.

## EXAMPLES

### EXAMPLE 1
```
Get-Platform -PVWAURL "https://pvwa.example.com" -LogonToken $token
```

Returns all platforms.

### EXAMPLE 2
```
Get-Platform -PVWAURL "https://pvwa.example.com" -LogonToken $token -Search "Windows"
```

Returns all platforms whose name contains "Windows".

### EXAMPLE 3
```
Get-Platform -PVWAURL "https://pvwa.example.com" -LogonToken $token -PlatformID "WinServerLocal"
```

Returns details for the WinServerLocal platform.

## PARAMETERS

### -Active
When specified, filters the list to return only active ($true) or inactive
($false) platforms.
Applies only when PlatformID is not specified.

```yaml
Type: Boolean
Parameter Sets: List
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformID
The unique string ID of the platform to retrieve.
When omitted, all platforms
are listed.

```yaml
Type: String
Parameter Sets: Specific
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -PlatformType
Filters the list by platform type.
Valid values: Regular, Group, RotationalGroup.
Applies only when PlatformID is not specified.

```yaml
Type: String
Parameter Sets: List
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Search
Search text to filter the platform list.
Applies only when PlatformID is not
specified.

```yaml
Type: String
Parameter Sets: List
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires membership in the Vault Admins group.

## RELATED LINKS
