---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-Safe

## SYNOPSIS
Retrieves information about safes from the PVWA API.

## SYNTAX

### PVWAURL (Default)
```
Get-Safe [-CatchAll <Object>] [-includeAccounts] [-Search <String>] [-PVWAURL <String>] [-LogonToken <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### SafeUrlId
```
Get-Safe [-CatchAll <Object>] [-SafeUrlId <String>] [-ExtendedDetails] [-includeAccounts] [-useCache]
 [-offset <Int32>] [-sort <AllowEmptyStringAttribute>] [-PVWAURL <String>] [-LogonToken <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### SafeName
```
Get-Safe [-CatchAll <Object>] [-SafeName <String>] [-ExtendedDetails] [-includeAccounts] [-useCache]
 [-Search <String>] [-offset <Int32>] [-limit <Int32>] [-DoNotPage] [-sort <AllowEmptyStringAttribute>]
 [-PVWAURL <String>] [-LogonToken <Object>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### PlatformID
```
Get-Safe [-CatchAll <Object>] [-PlatformID <String>] [-includeAccounts] [-PVWAURL <String>]
 [-LogonToken <Object>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### AllSafes
```
Get-Safe [-CatchAll <Object>] [-AllSafes] [-ExtendedDetails] [-includeAccounts] [-useCache] [-offset <Int32>]
 [-limit <Int32>] [-DoNotPage] [-sort <AllowEmptyStringAttribute>] [-PVWAURL <String>] [-LogonToken <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Search
```
Get-Safe [-CatchAll <Object>] [-includeAccounts] [-Search <String>] [-offset <Int32>] [-limit <Int32>]
 [-DoNotPage] [-sort <AllowEmptyStringAttribute>] [-PVWAURL <String>] [-LogonToken <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### SafeID
```
Get-Safe [-CatchAll <Object>] [-DoNotPage] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-Safe function retrieves information about safes from the PVWA API.
It supports multiple parameter sets to allow retrieval by Safe ID, Platform ID, or general queries.
The function can also return all safes if no specific parameters are provided.

## EXAMPLES

### EXAMPLE 1
```
Get-Safe -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeUrlId "12345"
Retrieves the safe with ID 12345.
```

### EXAMPLE 2
```
Get-Safe -PVWAURL "https://pvwa.example.com" -LogonToken $token -AllSafes
Retrieves all safes.
```

### EXAMPLE 3
```
Get-Safe -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "MySafe" -PlatformID "Platform1"
Retrieves the safe named "MySafe" for platform "Platform1".
```

## PARAMETERS

### -AllSafes
Switch to retrieve all safes.

```yaml
Type: SwitchParameter
Parameter Sets: AllSafes
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DoNotPage
Switch to disable pagination.

```yaml
Type: SwitchParameter
Parameter Sets: SafeName, SafeID
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

```yaml
Type: SwitchParameter
Parameter Sets: AllSafes, Search
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ExtendedDetails
Switch to include extended details in the results.

```yaml
Type: SwitchParameter
Parameter Sets: SafeUrlId, SafeName, AllSafes
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -includeAccounts
Switch to include accounts in the results.

```yaml
Type: SwitchParameter
Parameter Sets: PVWAURL, SafeUrlId, SafeName, PlatformID, AllSafes, Search
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -limit
The limit for pagination.

```yaml
Type: Int32
Parameter Sets: SafeName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

```yaml
Type: Int32
Parameter Sets: AllSafes, Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: PVWAURL, SafeUrlId, SafeName, PlatformID, AllSafes, Search
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -offset
The offset for pagination.

```yaml
Type: Int32
Parameter Sets: SafeUrlId, SafeName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

```yaml
Type: Int32
Parameter Sets: AllSafes, Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformID
The ID of the platform to retrieve safes for.

```yaml
Type: String
Parameter Sets: PlatformID
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: PVWAURL, SafeUrlId, SafeName, PlatformID, AllSafes, Search
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SafeName
The name of the safe to retrieve.

```yaml
Type: String
Parameter Sets: SafeName
Aliases: Safe

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SafeUrlId
The ID of the safe to retrieve.

```yaml
Type: String
Parameter Sets: SafeUrlId
Aliases: SafeID

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Search
A search string to filter the results.

```yaml
Type: String
Parameter Sets: PVWAURL, SafeName, Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -sort
The sort order for the results.
Valid values are "asc" and "desc".

```yaml
Type: AllowEmptyStringAttribute
Parameter Sets: SafeUrlId, SafeName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

```yaml
Type: AllowEmptyStringAttribute
Parameter Sets: AllSafes, Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -useCache
Switch to use cached results.

```yaml
Type: SwitchParameter
Parameter Sets: SafeUrlId, SafeName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

```yaml
Type: SwitchParameter
Parameter Sets: AllSafes
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Author: Your Name
Date: YYYY-MM-DD

## RELATED LINKS
