---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Connect-PASUser

## SYNOPSIS
Logs on to the Vault using CyberArk, LDAP, RADIUS, or Windows authentication.

## SYNTAX

```
Connect-PASUser [[-CatchAll] <Object>] [-PVWAURL] <String> [[-AuthType] <String>] [-Credential] <PSCredential>
 [-ConcurrentSession] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Connect-PASUser function authenticates to the CyberArk PAM REST API using
CyberArk, LDAP, RADIUS, or Windows authentication and returns a logon token that
can be passed to other functions as the LogonToken parameter.

## EXAMPLES

### EXAMPLE 1
```
$token = Connect-PASUser -PVWAURL "https://pvwa.example.com" -Credential (Get-Credential)
```

Logs on using CyberArk authentication and stores the token.

### EXAMPLE 2
```
$token = Connect-PASUser -PVWAURL "https://pvwa.example.com" -AuthType LDAP -Credential $cred
```

Logs on using LDAP authentication.

## PARAMETERS

### -AuthType
The authentication type.
Valid values: CyberArk, LDAP, RADIUS, Windows.
Defaults to CyberArk.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: CyberArk
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ConcurrentSession
When specified, allows multiple concurrent sessions for the same user.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Credential
A PSCredential containing the username and password.

```yaml
Type: PSCredential
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The base URL of the PVWA instance (e.g.
https://pvwa.example.com).

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: True
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### System.String
### Returns the logon token string.
## NOTES
The returned token must be passed as LogonToken to subsequent API calls.

## RELATED LINKS
