---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Remove-IdentityUser

## SYNOPSIS
Removes identity users from the system.

## SYNTAX

### ByID
```
Remove-IdentityUser [-Force] [-IdentityURL <String>] [-LogonToken <Object>] [-ID <String>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### ByName
```
Remove-IdentityUser [-Force] [-IdentityURL <String>] [-LogonToken <Object>] [-name <String>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### ByMail
```
Remove-IdentityUser [-Force] [-IdentityURL <String>] [-LogonToken <Object>] [-mail <String>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Remove-IdentityUser function removes identity users from the system based on the provided parameters.
It supports confirmation prompts and can process input from the pipeline.

## EXAMPLES

### EXAMPLE 1
```
Remove-IdentityUser -IdentityURL "https://identity.example.com" -LogonToken $token -name "jdoe"
```

### EXAMPLE 2
```
Remove-IdentityUser -IdentityURL "https://identity.example.com" -LogonToken $token -ID "abc123"
```

### EXAMPLE 3
```
Remove-IdentityUser -IdentityURL "https://identity.example.com" -LogonToken $token -mail "jdoe@example.com"
```

## PARAMETERS

### -Force
A switch to force the removal without confirmation.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -ID
The unique identifier (UUID) of the user to remove.

```yaml
Type: String
Parameter Sets: ByID
Aliases: UUID, InternalName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -mail
The email of the identity user to be removed.
This parameter can be provided from the pipeline by property name.

```yaml
Type: String
Parameter Sets: ByMail
Aliases: email

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -name
The username of the identity user to be removed.
This parameter can be provided from the pipeline by property name.

```yaml
Type: String
Parameter Sets: ByName
Aliases: user, username, member, UserPrincipalName, SamAccountName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function requires the Write-LogMessage and Invoke-Rest functions to be defined elsewhere in the script or module.

## RELATED LINKS
