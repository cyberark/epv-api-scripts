---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-PlatformSafes

## SYNOPSIS
Retrieves the safes associated with a platform.

## SYNTAX

```
Get-PlatformSafes [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [-PlatformID] <String>
 [[-Safe] <String>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-PlatformSafes function retrieves the list of safe names that are
associated with a specific platform in the Vault.

The user who runs this must be a member of the Vault Admins group.

## EXAMPLES

### EXAMPLE 1
```
Get-PlatformSafes -PVWAURL "https://pvwa.example.com" -LogonToken $token -PlatformID "WinServerLocal"
```

Returns all safe names associated with the WinServerLocal platform.

### EXAMPLE 2
```
Get-PlatformSafes -PlatformID "WinServerLocal" -Safe "IT-Servers"
```

Returns the safe named "IT-Servers" if it is associated with the WinServerLocal platform.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformID
The unique string ID of the platform.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Safe
Optional safe name filter.
When specified, returns only the matching safe.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires membership in the Vault Admins group.

## RELATED LINKS
