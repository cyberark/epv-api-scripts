---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Set-Account

## SYNOPSIS
Updates an existing account's properties in the PVWA system.

## SYNTAX

```
Set-Account [[-PVWAURL] <String>] [[-LogonToken] <Object>] [-AccountID] <String> [[-Name] <String>]
 [[-Address] <String>] [[-UserName] <String>] [[-PlatformId] <String>] [[-PlatformAccountProperties] <Object>]
 [[-AutomaticManagementEnabled] <Boolean>] [[-ManualManagementReason] <String>] [[-RemoteMachines] <String>]
 [[-AccessRestrictedToRemoteMachines] <Boolean>] [[-ExtraParameters] <Object[]>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Set-Account function updates an existing account's properties in the PVWA (Password Vault Web Access).
It allows you to modify various account properties including name, address, username, platform,
platform-specific properties, secret management settings, and remote machine access settings.
Any extra parameters not explicitly defined will be automatically added to platformAccountProperties.

## EXAMPLES

### EXAMPLE 1
```
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_345" -Name "srv01-admin-updated" -Address "srv01-new.domain.com"
```

Updates an account's name and address.

### EXAMPLE 2
```
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_345" -AutomaticManagementEnabled $false -ManualManagementReason "Service account requires manual password changes"
```

Updates an account's management settings.

### EXAMPLE 3
```
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_345" -Port 1521 -SID "ORCL" -ServiceName "MYSERVICE"
```

Updates an Oracle database account with platform-specific properties (Port, SID, ServiceName) automatically added to platformAccountProperties.

### EXAMPLE 4
```
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_345" -RemoteMachines "srv01.domain.com;srv02.domain.com" -AccessRestrictedToRemoteMachines $true
```

Updates an account's remote machine access settings.

## PARAMETERS

### -AccessRestrictedToRemoteMachines
Whether access is restricted to the specified remote machines.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 12
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AccountID
The unique ID of the account to update.

```yaml
Type: String
Parameter Sets: (All)
Aliases: id

Required: True
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Address
The new address/hostname of the target system.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AutomaticManagementEnabled
Whether automatic management is enabled for the account.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 9
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ExtraParameters
Additional parameters that will be automatically added to platformAccountProperties.
This parameter captures any undefined parameters passed to the function using ValueFromRemainingArguments.

```yaml
Type: Object[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 13
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ManualManagementReason
The reason for manual management if automatic management is disabled.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 10
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Name
The new name for the account.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformAccountProperties
Additional platform-specific properties for the account.
Note: Any extra parameters not explicitly defined in this function will automatically be added to platformAccountProperties.

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 8
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformId
The new platform ID that defines the account's platform settings.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 7
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 1
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -RemoteMachines
Semicolon-separated list of remote machines that can access this account.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 11
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -UserName
The new username for the account.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The user who runs this function requires appropriate permissions to update accounts.
This function is part of the EPV-API-Common module and is used to manage accounts
in the CyberArk Privileged Access Security Web Application.
This function can be used from PAM v9.7 and above.

IMPORTANT: When using extra parameters (platform-specific properties), ensure that the
properties exist on the target platform.
If a property does not exist on the platform,
the API will return an error.
Verify platform properties before using extra parameters.

## RELATED LINKS
