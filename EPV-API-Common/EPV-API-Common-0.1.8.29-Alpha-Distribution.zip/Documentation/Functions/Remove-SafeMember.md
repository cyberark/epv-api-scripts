---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Remove-SafeMember

## SYNOPSIS
Removes a member from a specified safe in the PVW        if ($PSCmdlet.ShouldProcess($memberName, 'Remove-SafeMember')) {
            Write-LogMessage -type Verbose -MSG "Removing member \`$memberName\` from safe \`$SafeName\`"
            $RestParms = @{
                Uri    = $SafeMemberURL
                Method = 'DELETE'
            }
            if ($null -ne $LogonToken -and $LogonToken -ne "") {
                $RestParms.LogonToken = $LogonToken
            }
            Invoke-Rest @RestParms

## SYNTAX

```
Remove-SafeMember [[-PVWAURL] <String>] [[-LogonToken] <Object>] [-SafeName] <String> [[-memberName] <String>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Remove-SafeMember function removes a specified member from a safe in the PVWA (Privileged Vault Web Access).
It supports confirmation prompts and logging of actions.

## EXAMPLES

### EXAMPLE 1
```
Remove-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "FinanceSafe" -memberName "JohnDoe"
```

This command removes the member "JohnDoe" from the safe "FinanceSafe" in the specified PVWA instance.

## PARAMETERS

### -LogonToken
The logon token used for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -memberName
The name of the member to be removed from the safe.

```yaml
Type: String
Parameter Sets: (All)
Aliases: User

Required: False
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SafeName
The name of the safe from which the member will be removed.

```yaml
Type: String
Parameter Sets: (All)
Aliases: Safe

Required: True
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
- This function supports ShouldProcess for safety.
- The ConfirmImpact is set to High, so confirmation is required by default.
- The function logs actions and warnings using Write-LogMessage.

## RELATED LINKS
