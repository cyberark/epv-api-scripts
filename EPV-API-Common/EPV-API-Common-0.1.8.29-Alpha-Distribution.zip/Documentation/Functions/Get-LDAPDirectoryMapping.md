---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-LDAPDirectoryMapping

## SYNOPSIS
Retrieves LDAP directory mapping configurations.

## SYNTAX

### List (Default)
```
Get-LDAPDirectoryMapping [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>]
 -DirectoryName <String> [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-LDAPDirectoryMapping [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>]
 -DirectoryName <String> [-MappingID <String>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-LDAPDirectoryMapping function retrieves the mappings configured for
an LDAP directory.
When called without a MappingID it returns all mappings
for the directory.
When called with a MappingID it returns that specific mapping.

## EXAMPLES

### EXAMPLE 1
```
Get-LDAPDirectoryMapping -DirectoryName "corp.example.com"
```

Returns all mappings for the corp.example.com directory.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DirectoryName
The name of the LDAP directory.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -MappingID
The ID of a specific mapping to retrieve.

```yaml
Type: String
Parameter Sets: Specific
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires Vault Admins group membership.

## RELATED LINKS
