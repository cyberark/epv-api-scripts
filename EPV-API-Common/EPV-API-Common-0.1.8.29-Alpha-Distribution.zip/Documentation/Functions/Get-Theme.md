---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-Theme

## SYNOPSIS
Retrieves themes from the Vault.

## SYNTAX

### List (Default)
```
Get-Theme [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-ProgressAction <ActionPreference>]
 [<CommonParameters>]
```

### Specific
```
Get-Theme [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -ThemeName <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-Theme function retrieves theme configurations from the Vault.
When
called without a ThemeName it returns all themes.
When called with a
ThemeName it returns that specific theme's configuration.

## EXAMPLES

### EXAMPLE 1
```
Get-Theme
```

Returns all themes.

### EXAMPLE 2
```
Get-Theme -ThemeName "DarkTheme"
```

Returns the DarkTheme configuration.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ThemeName
The name of the theme to retrieve.

```yaml
Type: String
Parameter Sets: Specific
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires Vault Admins group membership.

## RELATED LINKS
