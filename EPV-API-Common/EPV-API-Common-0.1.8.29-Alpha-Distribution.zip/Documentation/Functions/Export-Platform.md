---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Export-Platform

## SYNOPSIS
Exports a platform to a ZIP file.

## SYNTAX

```
Export-Platform [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [-PlatformID] <String>
 [[-OutputPath] <String>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Export-Platform function exports a target platform to a ZIP file.
This enables
you to import the platform to a different Vault environment.

Note: The ZIP file contains only the CPM Policy files and PVWA Settings.
If there
are additional CPM plug-in files, they must be added manually before importing.

The user who runs this must be a member of the Vault Admins group.

## EXAMPLES

### EXAMPLE 1
```
Export-Platform -PlatformID "WinServerLocal"
```

Exports the WinServerLocal platform to "WinServerLocal.zip" in the current directory.

### EXAMPLE 2
```
Export-Platform -PlatformID "WinServerLocal" -OutputPath "C:\Exports\WinServerLocal.zip"
```

Exports the platform to the specified path.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -OutputPath
The path where the exported ZIP file will be saved.
If not specified, saves to
the current directory as "{PlatformID}.zip".

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformID
The ID of the target platform to export.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The exported ZIP contains CPM Policy files and PVWA Settings only.
Additional CPM plug-in files must be added manually if needed.
Uses endpoint: POST /api/Platforms/{PlatformID}/Export

## RELATED LINKS
