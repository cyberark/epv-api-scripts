---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-BulkAction

## SYNOPSIS
Retrieves the status of a bulk action.

## SYNTAX

### All (Default)
```
Get-BulkAction [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-BulkAction [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -BulkID <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-BulkAction function retrieves the status and results of a previously
submitted bulk action.
Can query all bulk actions or a specific one by ID.

## EXAMPLES

### EXAMPLE 1
```
Get-BulkAction
```

Returns all bulk actions.

### EXAMPLE 2
```
Get-BulkAction -BulkID "bulk_abc"
```

Returns the status of bulk action bulk_abc.

## PARAMETERS

### -BulkID
The unique ID of the bulk action to check.

```yaml
Type: String
Parameter Sets: Specific
Aliases: BulkActionID

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Use the BulkActionID returned by bulk operation functions to track progress.

## RELATED LINKS
