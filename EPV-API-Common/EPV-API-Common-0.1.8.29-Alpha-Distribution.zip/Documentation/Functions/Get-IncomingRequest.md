---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-IncomingRequest

## SYNOPSIS
Retrieves incoming access requests.

## SYNTAX

### List (Default)
```
Get-IncomingRequest [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-IncomingRequest [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -RequestID <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-IncomingRequest function retrieves incoming access requests.
When
called without a RequestID it returns all pending incoming requests.
When
called with a RequestID it returns that specific request.

## EXAMPLES

### EXAMPLE 1
```
Get-IncomingRequest
```

Returns all pending incoming requests.

### EXAMPLE 2
```
Get-IncomingRequest -RequestID "req_123"
```

Returns details for request req_123.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -RequestID
The unique ID of the incoming request to retrieve.

```yaml
Type: String
Parameter Sets: Specific
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires the appropriate request confirmation permissions.

## RELATED LINKS
