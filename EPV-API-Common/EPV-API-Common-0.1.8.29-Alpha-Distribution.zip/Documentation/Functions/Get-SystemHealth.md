---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-SystemHealth

## SYNOPSIS
{{ Fill in the Synopsis }}

## SYNTAX

### Summary (Default)
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-Summary] [-Disconnected]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### CPM
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-CPM] [-Disconnected]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### PVWA
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-PVWA] [-Disconnected]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### PSM
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-PSM] [-Disconnected]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### PSMP
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-PSMP] [-Disconnected]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### PTA
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-PTA] [-Disconnected]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### AIM
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-AIM] [-Disconnected]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### ALL
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-ALL] [-Disconnected]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### ComponentID
```
Get-SystemHealth [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-ComponentID <Object>]
 [-Disconnected] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
{{ Fill in the Description }}

## EXAMPLES

### Example 1
```powershell
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -AIM
{{ Fill AIM Description }}

```yaml
Type: SwitchParameter
Parameter Sets: AIM
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -ALL
{{ Fill ALL Description }}

```yaml
Type: SwitchParameter
Parameter Sets: ALL
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ComponentID
{{ Fill ComponentID Description }}

```yaml
Type: Object
Parameter Sets: ComponentID
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -CPM
{{ Fill CPM Description }}

```yaml
Type: SwitchParameter
Parameter Sets: CPM
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -Disconnected
{{ Fill Disconnected Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
{{ Fill LogonToken Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PSM
{{ Fill PSM Description }}

```yaml
Type: SwitchParameter
Parameter Sets: PSM
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -PSMP
{{ Fill PSMP Description }}

```yaml
Type: SwitchParameter
Parameter Sets: PSMP
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -PTA
{{ Fill PTA Description }}

```yaml
Type: SwitchParameter
Parameter Sets: PTA
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -PVWA
{{ Fill PVWA Description }}

```yaml
Type: SwitchParameter
Parameter Sets: PVWA
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -PVWAURL
{{ Fill PVWAURL Description }}

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Summary
{{ Fill Summary Description }}

```yaml
Type: SwitchParameter
Parameter Sets: Summary
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### System.Management.Automation.SwitchParameter

### System.Object

## OUTPUTS

### System.Object
## NOTES

## RELATED LINKS
