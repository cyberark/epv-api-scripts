---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# New-Account

## SYNOPSIS
Creates a new account in the PVWA system.

## SYNTAX

```
New-Account [[-PVWAURL] <String>] [[-LogonToken] <Object>] [[-Name] <String>] [-Address] <String>
 [-UserName] <String> [-PlatformId] <String> [-SafeName] <String> [[-Secret] <SecureString>]
 [[-SecretType] <String>] [[-PlatformAccountProperties] <Object>] [[-AutomaticManagementEnabled] <Boolean>]
 [[-ManualManagementReason] <String>] [[-RemoteMachines] <String>]
 [[-AccessRestrictedToRemoteMachines] <Boolean>] [[-ExtraParameters] <Object[]>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The New-Account function connects to the PVWA API to create a new privileged account.
It requires the PVWA URL and a logon token for authentication.
The function
supports ShouldProcess for confirmation prompts.

## EXAMPLES

### EXAMPLE 1
```
$securePassword = ConvertTo-SecureString "P@ssw0rd123" -AsPlainText -Force
New-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -Name "srv01-admin" -Address "srv01.domain.com" -UserName "administrator" -PlatformId "WindowsServerLocal" -SafeName "IT-Servers" -Secret $securePassword -AutomaticManagementEnabled $true
```

Creates a new Windows server account in the IT-Servers safe with automatic management enabled.

### EXAMPLE 2
```
New-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -Name "db01-sa" -Address "db01.domain.com" -UserName "sa" -PlatformId "SQLServerDatabase" -SafeName "Database-Accounts" -SecretType "password" -RemoteMachines "srv01.domain.com;srv02.domain.com" -AccessRestrictedToRemoteMachines $true
```

Creates a new SQL Server account with access restricted to specific remote machines.

### EXAMPLE 3
```
New-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -Name "app-service" -Address "app01.domain.com" -UserName "svc_app" -PlatformId "WindowsServerLocal" -SafeName "Service-Accounts" -AutomaticManagementEnabled $false -ManualManagementReason "Service account requires manual password changes"
```

Creates a new service account with manual management and a specified reason.

### EXAMPLE 4
```
New-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -Name "oracle-db" -Address "ora01.domain.com" -UserName "sys" -PlatformId "Oracle" -SafeName "Database-Accounts" -Port 1521 -SID "ORCL" -ServiceName "MYSERVICE"
```

Creates a new Oracle database account with platform-specific properties (Port, SID, ServiceName) automatically added to platformAccountProperties.

## PARAMETERS

### -AccessRestrictedToRemoteMachines
Whether access is restricted to the specified remote machines.
Default is $false.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 14
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Address
The address/hostname of the target system.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AutomaticManagementEnabled
Whether automatic management is enabled for the account.
Default is $true.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 11
Default value: True
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ExtraParameters
Additional parameters that will be automatically added to platformAccountProperties.
This parameter captures any undefined parameters passed to the function using ValueFromRemainingArguments.

```yaml
Type: Object[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 15
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ManualManagementReason
The reason for manual management if automatic management is disabled.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 12
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Name
The name of the account to create.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformAccountProperties
Additional platform-specific properties for the account.
Note: Any extra parameters not explicitly defined in this function will automatically be added to platformAccountProperties.

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 10
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformId
The platform ID that defines the account's platform settings.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 6
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 1
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -RemoteMachines
Semicolon-separated list of remote machines that can access this account.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 13
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SafeName
The name of the safe where the account will be stored.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 7
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Secret
The secret/password for the account (SecureString).

```yaml
Type: SecureString
Parameter Sets: (All)
Aliases:

Required: False
Position: 8
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SecretType
The type of secret (password or key).
Default is "password".

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 9
Default value: Password
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -UserName
The username of the account.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The user who runs this function requires 'Add account' permission in the target Safe.
This function is part of the EPV-API-Common module and is used to manage accounts
in the CyberArk Privileged Access Security Web Application.
This function can be used from PAM v9.7 and above.

IMPORTANT: When using extra parameters (platform-specific properties), ensure that the
properties exist on the target platform.
If a property does not exist on the platform,
the API will return an error.
Verify platform properties before using extra parameters.

## RELATED LINKS
