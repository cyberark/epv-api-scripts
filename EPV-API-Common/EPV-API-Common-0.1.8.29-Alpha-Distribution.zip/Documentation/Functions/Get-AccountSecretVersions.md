---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-AccountSecretVersions

## SYNOPSIS
Retrieves all secret versions for an account in the PVWA system.

## SYNTAX

```
Get-AccountSecretVersions [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>]
 [-AccountID] <String> [[-ShowTemporary] <Boolean>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-AccountSecretVersions function connects to the PVWA API to return all
secret versions for a specific account.
This allows you to see the history
of password changes for the account.

## EXAMPLES

### EXAMPLE 1
```
Get-AccountSecretVersions -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34"
```

Retrieves all real secret versions for account with ID "12_34".

### EXAMPLE 2
```
Get-AccountSecretVersions -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34" -ShowTemporary $true
```

Retrieves all secret versions (including temporary) for account with ID "12_34".

## PARAMETERS

### -AccountID
The unique ID of the account to retrieve secret versions for.

```yaml
Type: String
Parameter Sets: (All)
Aliases: id

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ShowTemporary
Whether to return both real and temporary password versions or only real versions.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### System.String
## NOTES
The user who runs this function requires 'List Accounts' and 'View Safe Members'
permissions in the Safe where the privileged account is stored.
This function is part of the EPV-API-Common module and is used to manage accounts
in the CyberArk Privileged Access Security Web Application.

## RELATED LINKS
