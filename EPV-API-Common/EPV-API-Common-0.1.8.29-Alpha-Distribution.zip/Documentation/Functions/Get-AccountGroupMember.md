---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-AccountGroupMember

## SYNOPSIS
Retrieves members of an account group.

## SYNTAX

### All (Default)
```
Get-AccountGroupMember [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -GroupID <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-AccountGroupMember [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -GroupID <String>
 [-AccountID <String>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-AccountGroupMember function retrieves the accounts that belong to a
specified account group.
Optionally retrieves a single member by AccountID.

## EXAMPLES

### EXAMPLE 1
```
Get-AccountGroupMember -GroupID "grp_123"
```

Returns all members of the group.

### EXAMPLE 2
```
Get-AccountGroupMember -GroupID "grp_123" -AccountID "45_6"
```

Returns the specific member account in the group.

## PARAMETERS

### -AccountID
The ID of a specific account member to retrieve.
When omitted, all members
are returned.

```yaml
Type: String
Parameter Sets: Specific
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -GroupID
The unique ID of the account group.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires the Vault Admins group membership or appropriate permissions.

## RELATED LINKS
