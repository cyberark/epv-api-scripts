---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-IdentityRoleInDir

## SYNOPSIS
Retrieves identity roles and rights from a specified directory.

## SYNTAX

```
Get-IdentityRoleInDir [[-CatchAll] <Object>] [[-IdentityURL] <String>] [[-LogonToken] <Object>]
 [-Directory] <String> [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-IdentityRoleInDir function sends a POST request to the specified IdentityURL to retrieve roles and rights for a given directory.
The function requires an identity URL, a logon token, and a directory identifier.

## EXAMPLES

### EXAMPLE 1
```
Get-IdentityRoleInDir -IdentityURL "https://example.com" -LogonToken $token -Directory "12345"
This example retrieves the roles and rights for the directory with the identifier "12345" from the specified identity service URL.
```

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Directory
The unique identifier of the directory service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: DirectoryServiceUuid, _ID

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service endpoint.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function removes the CatchAll parameter from the bound parameters before processing the request.

## RELATED LINKS
