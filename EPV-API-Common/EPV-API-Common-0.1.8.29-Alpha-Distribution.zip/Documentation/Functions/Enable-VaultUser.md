---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Enable-VaultUser

## SYNOPSIS
Enables a vault user account.

## SYNTAX

```
Enable-VaultUser [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [-UserID] <Int32>
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Enable-VaultUser function enables a previously disabled vault user
account, restoring their ability to log in.

## EXAMPLES

### EXAMPLE 1
```
Enable-VaultUser -UserID 42
```

Enables vault user with ID 42.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -UserID
The unique ID of the vault user to enable.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases: id

Required: True
Position: 4
Default value: 0
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires Manage Users permission.

## RELATED LINKS
