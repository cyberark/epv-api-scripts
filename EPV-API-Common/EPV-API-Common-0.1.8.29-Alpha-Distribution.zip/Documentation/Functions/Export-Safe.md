---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Export-Safe

## SYNOPSIS
Exports information about safes to a CSV file.

## SYNTAX

```
Export-Safe [[-CSVPath] <String>] [-Force] [-Safe] <Safe> [-IncludeAccounts] [-IncludeDetails]
 [-includeSystemSafes] [[-CPMUser] <String[]>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Export-Safe function exports details about safes to a specified CSV file.
It includes options to force overwrite the file, include account details, and include additional safe details.
The function can also exclude system safes from the export.

## EXAMPLES

### EXAMPLE 1
```
Export-Safe -CSVPath "C:\Exports\SafeExport.csv" -Force -Safe $safe -IncludeAccounts -IncludeDetails
```

This example exports the details of the specified safe to "C:\Exports\SafeExport.csv", including account details and additional safe details, and forces the overwrite of the existing file.

## PARAMETERS

### -CPMUser
An array of CPM user names.
This parameter is hidden from the user.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -CSVPath
The path to the CSV file where the safe information will be exported.
Default is ".\SafeExport.csv".

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: .\SafeExport.csv
Accept pipeline input: False
Accept wildcard characters: False
```

### -Force
If specified, forces the overwrite of the existing CSV file.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -IncludeAccounts
If specified, includes account details in the export.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -IncludeDetails
If specified, includes additional details about the safe in the export.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -includeSystemSafes
If specified, includes system safes in the export.
This parameter is hidden from the user.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Safe
The safe object to be exported.
This parameter is mandatory and accepts input from the pipeline.

```yaml
Type: Safe
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function logs messages at various stages of execution and handles errors gracefully.
It exits with code 80 if the CSV file already exists and the Force switch is not specified.

## RELATED LINKS
