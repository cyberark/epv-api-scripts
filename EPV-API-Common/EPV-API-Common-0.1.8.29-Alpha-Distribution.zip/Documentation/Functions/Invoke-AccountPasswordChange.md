---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Invoke-AccountPasswordChange

## SYNOPSIS
Marks an account for immediate credentials change by the CPM in the PVWA system.

## SYNTAX

```
Invoke-AccountPasswordChange [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>]
 [-AccountID] <String> [[-ChangeImmediately] <Boolean>] [[-NewCredentials] <SecureString>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Invoke-AccountPasswordChange function connects to the PVWA API to mark an account
for an immediate credentials change by the CPM (Central Policy Manager) to a new
random password.
This operation triggers an immediate password change on the target system.

## EXAMPLES

### EXAMPLE 1
```
Invoke-AccountPasswordChange -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34"
```

Marks the account with ID "12_34" for immediate password change by the CPM.

### EXAMPLE 2
```
Invoke-AccountPasswordChange -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34" -ChangeImmediately $true
```

Marks the account with ID "12_34" for immediate password change with the ChangeImmediately flag set.

## PARAMETERS

### -AccountID
The unique ID of the account for which to change the password.

```yaml
Type: String
Parameter Sets: (All)
Aliases: id

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ChangeImmediately
Indicates whether the password should be changed immediately.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -NewCredentials
The new credentials to set (if not specified, a random password will be generated).

```yaml
Type: SecureString
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The user who runs this function requires 'Initiate CPM password management operations'
permission in the Safe where the privileged account is stored.
This function is part of the EPV-API-Common module and is used to manage accounts
in the CyberArk Privileged Access Security Web Application.

## RELATED LINKS
