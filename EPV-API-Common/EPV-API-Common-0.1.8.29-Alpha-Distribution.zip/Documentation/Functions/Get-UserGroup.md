---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-UserGroup

## SYNOPSIS
Retrieves PAS-level user groups from the Vault.

## SYNTAX

### List (Default)
```
Get-UserGroup [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-Search <String>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-UserGroup [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -GroupID <Int32>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-UserGroup function retrieves PAS-level user groups.
When called
without a GroupID it returns all groups, optionally filtered by search text.
When called with a GroupID it returns that specific group's details.

Note: This manages PAS-level groups, which are distinct from Identity Service
groups managed by Identity Service APIs.

## EXAMPLES

### EXAMPLE 1
```
Get-UserGroup
```

Returns all PAS-level user groups.

### EXAMPLE 2
```
Get-UserGroup -GroupID 7
```

Returns details for group 7.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -GroupID
The unique ID of the group to retrieve.

```yaml
Type: Int32
Parameter Sets: Specific
Aliases:

Required: True
Position: Named
Default value: 0
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Search
Search text to filter the group list.

```yaml
Type: String
Parameter Sets: List
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires Manage Users permission or audit access.

## RELATED LINKS
