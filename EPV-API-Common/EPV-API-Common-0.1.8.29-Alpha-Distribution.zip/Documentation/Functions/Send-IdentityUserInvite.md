---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Send-IdentityUserInvite

## SYNOPSIS
Sends a login invitation email to specified Identity users.

## SYNTAX

```
Send-IdentityUserInvite [-IdentityURL] <String> [[-LogonToken] <Object>] [-Users] <String[]>
 [[-CustomMessage] <String>] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Send-IdentityUserInvite function sends email invitations to one or more users to login to the CyberArk Identity portal.
Only system administrators or users with user management rights can invoke this function.

## EXAMPLES

### EXAMPLE 1
```
Send-IdentityUserInvite -IdentityURL "https://identity.example.com" -LogonToken $token -Users @("abc123", "def456")
```

### EXAMPLE 2
```
Send-IdentityUserInvite -IdentityURL "https://identity.example.com" -LogonToken $token -Users @("jdoe", "jsmith") -CustomMessage "Welcome to CyberArk!"
```

## PARAMETERS

### -CustomMessage
Custom message to include in the invitation email.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Users
Array of user UUIDs or usernames to send invitations to.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: UserIDs, IDs, user, username, member, UserPrincipalName, SamAccountName, name

Required: True
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Only system administrator or users with user management rights can invoke this function.

## RELATED LINKS
