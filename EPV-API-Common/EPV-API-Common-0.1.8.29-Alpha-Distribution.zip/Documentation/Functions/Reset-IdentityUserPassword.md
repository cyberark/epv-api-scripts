---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Reset-IdentityUserPassword

## SYNOPSIS
Resets the password for a specified Identity user.

## SYNTAX

### ByID
```
Reset-IdentityUserPassword -IdentityURL <String> [-LogonToken <Object>] [-ID <String>] [-NewPassword <String>]
 [-NotifyUser <Boolean>] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### ByName
```
Reset-IdentityUserPassword -IdentityURL <String> [-LogonToken <Object>] [-name <String>]
 [-NewPassword <String>] [-NotifyUser <Boolean>] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
The Reset-IdentityUserPassword function resets the password for a specified user in the CyberArk Identity Cloud Directory Service.
Only system administrators or users with user management rights can invoke this function.

## EXAMPLES

### EXAMPLE 1
```
Reset-IdentityUserPassword -IdentityURL "https://identity.example.com" -LogonToken $token -ID "abc123" -NewPassword "NewP@ssw0rd!"
```

### EXAMPLE 2
```
Reset-IdentityUserPassword -IdentityURL "https://identity.example.com" -LogonToken $token -ID "abc123" -NotifyUser
```

## PARAMETERS

### -ID
The unique identifier (UUID) of the user.

```yaml
Type: String
Parameter Sets: ByID
Aliases: UUID, InternalName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -name
{{ Fill name Description }}

```yaml
Type: String
Parameter Sets: ByName
Aliases: user, username, member, UserPrincipalName, SamAccountName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -NewPassword
The new password for the user.
If not provided, a randomly generated strong password will be used.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -NotifyUser
Whether to notify the user via email with the new password.
Default is false.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Only system administrator or users with user management rights can invoke this function.
Password must be at least 8 characters long, not be longer than 64 characters, contain at least one digit,
contain at least one upper and one lower case letter.

## RELATED LINKS
