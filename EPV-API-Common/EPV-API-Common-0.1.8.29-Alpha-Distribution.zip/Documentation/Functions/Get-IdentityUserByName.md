---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-IdentityUserByName

## SYNOPSIS
Retrieves an identity user by username.

## SYNTAX

```
Get-IdentityUserByName [[-CatchAll] <Object>] [[-IdentityURL] <String>] [[-LogonToken] <Object>]
 [-UserName] <String> [-IDOnly] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-IdentityUserByName function retrieves user information from the CyberArk Identity service by username.
This is a simplified method that uses the username directly instead of requiring a UUID.
Only system administrators, users with user management rights, or the user itself can invoke this function.

## EXAMPLES

### EXAMPLE 1
```
Get-IdentityUserByName -IdentityURL "https://identity.example.com" -LogonToken $token -UserName "jdoe"
```

### EXAMPLE 2
```
"user@example.com" | Get-IdentityUserByName -IDOnly
```

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service to query.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IDOnly
A switch to return only the user ID.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the identity service.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -UserName
The username of the user to retrieve.

```yaml
Type: String
Parameter Sets: (All)
Aliases: user, member, UserPrincipalName, SamAccountName, name

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function is a convenience wrapper for getting users by their username.

## RELATED LINKS
