---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-DependentAccount

## SYNOPSIS
Retrieves dependent accounts associated with a specific account in the PVWA system.

## SYNTAX

```
Get-DependentAccount [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>]
 [-AccountID] <String> [[-Search] <String>] [[-Filter] <String>] [[-FailedOnly] <Boolean>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-DependentAccount function connects to the PVWA API to get all dependent
accounts associated to a specific master account.
Dependent accounts are accounts
that depend on a master account for their credentials.

## EXAMPLES

### EXAMPLE 1
```
Get-DependentAccount -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34"
```

Retrieves all dependent accounts for the master account with ID "12_34".

### EXAMPLE 2
```
Get-DependentAccount -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34" -FailedOnly $true
```

Retrieves only failed dependent accounts for the master account with ID "12_34".

## PARAMETERS

### -AccountID
The account ID of the master account.

```yaml
Type: String
Parameter Sets: (All)
Aliases: id

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -FailedOnly
Get only failed dependent accounts.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 7
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Filter
Filter to apply when searching dependent accounts.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Search
List of keywords separated with space to search in dependent accounts.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The user who runs this function requires appropriate permissions in the Safe
where the privileged account is stored.
This function is part of the EPV-API-Common module and is used to manage accounts
in the CyberArk Privileged Access Security Web Application.

## RELATED LINKS
