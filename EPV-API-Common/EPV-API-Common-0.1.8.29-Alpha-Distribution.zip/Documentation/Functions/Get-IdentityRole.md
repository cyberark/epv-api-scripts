---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-IdentityRole

## SYNOPSIS
Retrieves identity roles from the specified identity URL.

## SYNTAX

### RoleName (Default)
```
Get-IdentityRole [-CatchAll <Object>] [-IdentityURL <String>] [-LogonToken <Object>] [-IDOnly]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### roleName
```
Get-IdentityRole [-CatchAll <Object>] [-IdentityURL <String>] [-LogonToken <Object>] -roleName <String>
 [-IDOnly] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### AllRoles
```
Get-IdentityRole [-CatchAll <Object>] [-IdentityURL <String>] [-LogonToken <Object>] [-IDOnly] [-AllRoles]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-IdentityRole function retrieves identity roles from a specified identity URL.
It supports retrieving a specific role by name or all roles.
The function can return either the full role information or just the role ID.

## EXAMPLES

### EXAMPLE 1
```
Get-IdentityRole -IdentityURL "https://identity.example.com" -LogonToken $token -roleName "Admin"
Retrieves the role information for the role named "Admin".
```

### EXAMPLE 2
```
Get-IdentityRole -IdentityURL "https://identity.example.com" -LogonToken $token -AllRoles
Retrieves all roles from the identity service.
```

## PARAMETERS

### -AllRoles
A switch to indicate if all roles should be retrieved.
This parameter is mandatory when using the "AllRoles" parameter set.

```yaml
Type: SwitchParameter
Parameter Sets: AllRoles
Aliases:

Required: True
Position: Named
Default value: False
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IDOnly
A switch to indicate if only the role ID should be returned.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -roleName
The name of the role to retrieve.
This parameter is mandatory when using the "RoleName" parameter set.

```yaml
Type: String
Parameter Sets: roleName
Aliases: role

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function uses REST API calls to interact with the identity service.

## RELATED LINKS
