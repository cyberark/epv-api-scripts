---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-TargetPlatform

## SYNOPSIS
Retrieves target platform information from the Vault.

## SYNTAX

### List (Default)
```
Get-TargetPlatform [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-Search <String>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-TargetPlatform [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -PlatformID <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-TargetPlatform function retrieves target platform information.
When called without a PlatformID it returns a list of all target platforms,
optionally filtered by search text.
When called with a PlatformID it returns
detailed information for that specific target platform.

The user who runs this must be a member of the Vault Admins group.

## EXAMPLES

### EXAMPLE 1
```
Get-TargetPlatform -PVWAURL "https://pvwa.example.com" -LogonToken $token
```

Returns all target platforms.

### EXAMPLE 2
```
Get-TargetPlatform -PVWAURL "https://pvwa.example.com" -LogonToken $token -PlatformID "WinServerLocal"
```

Returns details for the WinServerLocal target platform.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PlatformID
The unique string ID of the target platform to retrieve.
When omitted, all
target platforms are listed.

```yaml
Type: String
Parameter Sets: Specific
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Search
Search text to filter the platform list.
Applies only when PlatformID is not
specified.

```yaml
Type: String
Parameter Sets: List
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires membership in the Vault Admins group.

## RELATED LINKS
