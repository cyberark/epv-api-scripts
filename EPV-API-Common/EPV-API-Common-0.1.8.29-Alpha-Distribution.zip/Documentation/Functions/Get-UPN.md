---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-UPN

## SYNOPSIS
Retrieves the User Principal Name (UPN) for a given SAMAccountName from Active Directory.

## SYNTAX

```
Get-UPN [[-SAMAccountName] <String>] [-NoErrorOnNull] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
Queries Active Directory for a user matching the provided SAMAccountName and returns
their UserPrincipalName.
Requires the ActiveDirectory module.
Accepts pipeline input.

## EXAMPLES

### EXAMPLE 1
```
Get-UPN -SAMAccountName 'jsmith'
```

### EXAMPLE 2
```
'jsmith','bdoe' | Get-UPN -NoErrorOnNull
```

## PARAMETERS

### -NoErrorOnNull
When specified, returns an empty string instead of writing an error if the user is not found.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: False
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SAMAccountName
The SAMAccountName (pre-Windows 2000 login name) to look up.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### String - The User Principal Name of the matching user.
## NOTES
Requires the ActiveDirectory PowerShell module.

## RELATED LINKS
