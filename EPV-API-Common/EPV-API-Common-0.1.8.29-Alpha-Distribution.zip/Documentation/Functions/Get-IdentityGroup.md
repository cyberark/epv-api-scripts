---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-IdentityGroup

## SYNOPSIS
Retrieves identity group information from a specified identity URL.

## SYNTAX

### GroupName (Default)
```
Get-IdentityGroup [-CatchAll <Object>] [-IdentityURL <String>] [-LogonToken <Object>] [-GroupName <String>]
 [-IDOnly] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### AllGroups
```
Get-IdentityGroup [-CatchAll <Object>] [-IdentityURL <String>] [-LogonToken <Object>] [-IDOnly] [-AllGroups]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-IdentityGroup function retrieves information about identity groups from a specified identity URL.
It supports retrieving all groups or a specific group by name.
The function can also return only the ID of the group if specified.

## EXAMPLES

### EXAMPLE 1
```
Get-IdentityGroup -IdentityURL "https://identity.example.com" -LogonToken $token -GroupName "Admins"
```

This example retrieves information about the "Admins" group from the specified identity URL.

### EXAMPLE 2
```
Get-IdentityGroup -IdentityURL "https://identity.example.com" -LogonToken $token -AllGroups
```

This example retrieves information about all groups from the specified identity URL.

## PARAMETERS

### -AllGroups
A switch to specify if all groups should be retrieved.
This parameter is mandatory when using the "AllGroups" parameter set.

```yaml
Type: SwitchParameter
Parameter Sets: AllGroups
Aliases:

Required: True
Position: Named
Default value: False
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -GroupName
The name of the group to retrieve information for.
This parameter is mandatory when using the "GroupName" parameter set.

```yaml
Type: String
Parameter Sets: GroupName
Aliases: Group

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service to query.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IDOnly
A switch to specify if only the ID of the group should be returned.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the identity service.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function uses Invoke-Rest to query the identity service and requires appropriate permissions to access the service.

## RELATED LINKS
