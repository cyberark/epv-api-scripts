---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Set-AccountPassword

## SYNOPSIS
Updates an account's credentials in the Vault without affecting the target device.

## SYNTAX

```
Set-AccountPassword [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [-AccountID] <String>
 [-NewPassword] <Object> [[-ChangeEntireGroup] <Boolean>] [-ProgressAction <ActionPreference>] [-WhatIf]
 [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Set-AccountPassword function connects to the PVWA API to set the account's
credentials and change it in the Vault only.
This will not affect the credentials
on the target device.
This is useful when the password was changed externally
and needs to be updated in the Vault.

## EXAMPLES

### EXAMPLE 1
```
Set-AccountPassword -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34" -NewPassword (ConvertTo-SecureString "NewP@ssw0rd" -AsPlainText -Force)
```

Updates the password for account with ID "12_34" in the Vault.

## PARAMETERS

### -AccountID
The unique ID of the account to update the password for.

```yaml
Type: String
Parameter Sets: (All)
Aliases: id

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ChangeEntireGroup
This parameter is defined for compatibility with older versions but is not currently
implemented in the API endpoint.
Individual account password updates only.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -NewPassword
The new password to set in the Vault.
Accepts either a SecureString or plain text string.

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: True
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The user who runs this function requires 'Update password value' permission in the Safe
where the privileged account is stored.
This function is part of the EPV-API-Common module and is used to manage accounts
in the CyberArk Privileged Access Security Web Application.

## RELATED LINKS
