---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Connect-AccountPSM

## SYNOPSIS
Connects to an account through PSM (Privileged Session Manager) in the PVWA system.

## SYNTAX

```
Connect-AccountPSM [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [-AccountID] <String>
 [[-Reason] <String>] [[-TicketID] <String>] [[-ConnectionComponent] <String>]
 [[-AllowMappingLocalDrives] <Boolean>] [[-AllowConnectToConsole] <Boolean>] [[-RedirectSmartCards] <Boolean>]
 [[-PSMRemoteApp] <String>] [[-LogonDomain] <String>] [[-AllowSelectHTML5] <Boolean>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Connect-AccountPSM function connects to the PVWA API to connect with an account
through PSM using an RDP file or to the PSMGW.
It returns RDP settings that can be
used with an RDP client application or settings for the PSMGW.

## EXAMPLES

### EXAMPLE 1
```
Connect-AccountPSM -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34" -Reason "Maintenance"
```

Connects to account with ID "12_34" through PSM with the reason "Maintenance".

## PARAMETERS

### -AccountID
The unique ID of the account to retrieve and use to connect to the target system through PSM.

```yaml
Type: String
Parameter Sets: (All)
Aliases: id

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AllowConnectToConsole
Whether to allow connection to console.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 9
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AllowMappingLocalDrives
Whether to allow mapping of local drives.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 8
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AllowSelectHTML5
Whether to allow HTML5 selection.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 13
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ConnectionComponent
The name of the connection component to use.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 7
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonDomain
The logon domain for the connection.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 12
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PSMRemoteApp
The PSM remote application to use.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 11
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Reason
The reason for connecting to the account.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -RedirectSmartCards
Whether to redirect smart cards.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 10
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -TicketID
The ticket ID for connecting to the account.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The user who runs this function requires appropriate permissions in the Safe
where the account is stored.
The PVWA and PSM must be configured for transparent connections through PSM with RDP files or PSMGW.
This function is part of the EPV-API-Common module and is used to manage accounts
in the CyberArk Privileged Access Security Web Application.

## RELATED LINKS
