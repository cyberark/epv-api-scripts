---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-LDAPDirectory

## SYNOPSIS
Retrieves LDAP directory configurations.

## SYNTAX

### List (Default)
```
Get-LDAPDirectory [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-LDAPDirectory [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -DirectoryName <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-LDAPDirectory function retrieves LDAP directory configurations from
the Vault.
When called without a DirectoryName it returns all configured
directories.
When called with a DirectoryName it returns that specific
directory's configuration.

## EXAMPLES

### EXAMPLE 1
```
Get-LDAPDirectory
```

Returns all configured LDAP directories.

### EXAMPLE 2
```
Get-LDAPDirectory -DirectoryName "corp.example.com"
```

Returns configuration for the corp.example.com LDAP directory.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DirectoryName
The name of the LDAP directory to retrieve.

```yaml
Type: String
Parameter Sets: Specific
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires Vault Admins group membership.

## RELATED LINKS
