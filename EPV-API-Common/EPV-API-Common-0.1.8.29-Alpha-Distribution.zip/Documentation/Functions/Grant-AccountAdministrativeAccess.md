---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Grant-AccountAdministrativeAccess

## SYNOPSIS
Grants administrative access to a target Windows machine using an account in the PVWA system.

## SYNTAX

```
Grant-AccountAdministrativeAccess [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>]
 [-AccountID] <String> [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Grant-AccountAdministrativeAccess function connects to the PVWA API to request
and receive access to a target Windows machine with administrative rights.
The domain
user who runs this function will be added to the local Administrators group of the target machine.

## EXAMPLES

### EXAMPLE 1
```
Grant-AccountAdministrativeAccess -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_34"
```

Grants administrative access to the target machine using account with ID "12_34".

## PARAMETERS

### -AccountID
The local account that will be used to add the logged on user to the Administrators group on the machine.

```yaml
Type: String
Parameter Sets: (All)
Aliases: id

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The user who runs this function requires 'List accounts' and 'Use accounts' permissions
in the Safe where the account is stored.
The platform must be enabled for ad hoc access at platform level.
Supported end user machine environments: Windows Server 2012/2012R2/2016, Windows 8, Windows 10.
This function is part of the EPV-API-Common module and is used to manage accounts
in the CyberArk Privileged Access Security Web Application.

## RELATED LINKS
