---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-SafeMember

## SYNOPSIS
Retrieves safe member information from the PVWA API.

## SYNTAX

### SafeName (Default)
```
Get-SafeMember [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -SafeName <String>
 [-permissions] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### memberName
```
Get-SafeMember [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -SafeName <String>
 [-memberName <String>] [-noCache] [-permissions] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Search
```
Get-SafeMember [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -SafeName <String>
 [-Search <String>] [-memberType <String>] [-membershipExpired <String>] [-includePredefinedUsers <String>]
 [-offset <Int32>] [-limit <Int32>] [-DoNotPage] [-sort <AllowEmptyStringAttribute>] [-permissions]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-SafeMember function retrieves information about members of a specified safe from the PVWA API.
It supports various parameter sets to filter and search for specific members or member types.

## EXAMPLES

### EXAMPLE 1
```
Get-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "Finance"
```

Retrieves all members of the "Finance" safe.

### EXAMPLE 2
```
Get-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "Finance" -memberName "JohnDoe"
```

Retrieves information about the member "JohnDoe" in the "Finance" safe.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DoNotPage
A switch to disable pagination.
This parameter is only valid with the 'Search' parameter set.

```yaml
Type: SwitchParameter
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -includePredefinedUsers
A filter to include predefined users.
Valid values are "True" and "False".
This parameter is only valid with the 'Search' parameter set.

```yaml
Type: String
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -limit
The limit for pagination.
This parameter is only valid with the 'Search' parameter set.

```yaml
Type: Int32
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authenticating with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -memberName
The name of the member to retrieve information for.
This parameter is mandatory when using the 'memberName' parameter set.

```yaml
Type: String
Parameter Sets: memberName
Aliases: User

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -membershipExpired
A filter to include only members with expired memberships.
Valid values are "True" and "False".
This parameter is only valid with the 'Search' parameter set.

```yaml
Type: String
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -memberType
The type of member to filter by.
Valid values are "User" and "Group".
This parameter is only valid with the 'Search' parameter set.

```yaml
Type: String
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -noCache
{{ Fill noCache Description }}

```yaml
Type: SwitchParameter
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -offset
The offset for pagination.
This parameter is only valid with the 'Search' parameter set.

```yaml
Type: Int32
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -permissions
A switch to include permissions in the output.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SafeName
The name of the safe to retrieve members from.

```yaml
Type: String
Parameter Sets: (All)
Aliases: Safe

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Search
A search string to filter members by name.
This parameter is only valid with the 'Search' parameter set.

```yaml
Type: String
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -sort
The sort order for the results.
Valid values are "asc" and "desc".
This parameter is only valid with the 'Search' parameter set.

```yaml
Type: AllowEmptyStringAttribute
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
