---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-DirectoryService

## SYNOPSIS
Get Identity Directories

## SYNTAX

```
Get-DirectoryService [[-CatchAll] <Object>] [[-IdentityURL] <String>] [[-LogonToken] <Object>] [-IDOnly]
 [[-DirectoryServiceUuid] <String[]>] [[-directoryName] <String>] [[-directoryService] <String>] [-UuidOnly]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
Get Identity Directories

## EXAMPLES

### EXAMPLE 1
```
Example of how to use this cmdlet
```

### EXAMPLE 2
```
Another example of how to use this cmdlet
```

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -directoryName
{{ Fill directoryName Description }}

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -directoryService
{{ Fill directoryService Description }}

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -DirectoryServiceUuid
{{ Fill DirectoryServiceUuid Description }}

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: DirID, DirectoryUUID

Required: False
Position: 4
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -IdentityURL
{{ Fill IdentityURL Description }}

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IDOnly
{{ Fill IDOnly Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
{{ Fill LogonToken Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -UuidOnly
{{ Fill UuidOnly Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### Inputs to this cmdlet (if any)
## OUTPUTS

### Output from this cmdlet (if any)
## NOTES
General notes

## RELATED LINKS
