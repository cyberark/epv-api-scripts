---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Import-Safe

## SYNOPSIS
Imports Safe objects from a CSV file, mapping only allowed columns.

## SYNTAX

```
Import-Safe [[-CSVPath] <String>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
Reads each row from the specified CSV file and creates a Safe object, adding only properties that are in the list of allowed columns.
Handles alternate column names and converts boolean fields appropriately.
Logs errors for missing required columns.

## EXAMPLES

### EXAMPLE 1
```
Import-Safe -CSVPath 'C:\Exports\SafeMembers.csv'
Imports Safe objects from the specified CSV file.
```

## PARAMETERS

### -CSVPath
Path to the CSV file to import.
Defaults to '.\SafeMemberExport.csv'.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: .\SafeMemberExport.csv
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Allowed columns: Safe Name, Description, Managing CPM, Number of Versions Retained, Location, OLAC Enabled, AutoPurgeEnabled, DaysRetention.
Handles alternate column names and type conversion for boolean fields.

## RELATED LINKS
