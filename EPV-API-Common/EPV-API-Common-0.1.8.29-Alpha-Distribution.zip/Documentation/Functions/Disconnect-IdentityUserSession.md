---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Disconnect-IdentityUserSession

## SYNOPSIS
Disconnects identity user sessions.

## SYNTAX

```
Disconnect-IdentityUserSession [[-CatchAll] <Object>] [[-IdentityURL] <String>] [[-LogonToken] <Object>]
 [-User] <String> [-Everywhere] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Disconnect-IdentityUserSession function signs out user sessions in the CyberArk Identity tenant.
It can sign out the current session or all sessions for a user across all devices.

## EXAMPLES

### EXAMPLE 1
```
Disconnect-IdentityUserSession -IdentityURL "https://identity.example.com" -LogonToken $token -User "jdoe"
```

### EXAMPLE 2
```
"user@example.com" | Disconnect-IdentityUserSession -Everywhere
```

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Everywhere
Sign out the user from all devices and sessions.
If not specified, only signs out the current session.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the identity service.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -User
The user identifier (UUID or username) whose sessions to disconnect.

```yaml
Type: String
Parameter Sets: (All)
Aliases: username, member, UserPrincipalName, SamAccountName, name, UUID, ID

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function requires appropriate permissions to manage user sessions.
Using -Everywhere will sign out the user from all active sessions across all devices.

## RELATED LINKS
