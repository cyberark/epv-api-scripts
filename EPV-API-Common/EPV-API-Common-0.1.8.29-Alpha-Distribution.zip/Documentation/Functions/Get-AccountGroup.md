---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-AccountGroup

## SYNOPSIS
Retrieves account groups from the Vault.

## SYNTAX

```
Get-AccountGroup [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-SafeName <String>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-AccountGroup function retrieves account groups from the Vault.
When called without a SafeName it returns all account groups.
When called
with a SafeName it returns groups belonging to that safe.

## EXAMPLES

### EXAMPLE 1
```
Get-AccountGroup -PVWAURL "https://pvwa.example.com" -LogonToken $token
```

Returns all account groups.

### EXAMPLE 2
```
Get-AccountGroup -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "ProductionSafe"
```

Returns account groups belonging to ProductionSafe.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SafeName
The name of the safe to filter account groups by.

```yaml
Type: String
Parameter Sets: (All)
Aliases: Safe

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires the Vault Admins group membership or appropriate permissions.

## RELATED LINKS
