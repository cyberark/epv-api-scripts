---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Set-SafeMember

## SYNOPSIS
Updates the permissions of an existing safe member.

## SYNTAX

### memberName (Default)
```
Set-SafeMember [-PVWAURL <String>] [-LogonToken <Object>] -SafeName <String> -memberName <String>
 [-searchIn <String>] [-MemberType <String>] [-membershipExpirationDate <Int32>] [-useAccounts <Boolean>]
 [-retrieveAccounts <Boolean>] [-listAccounts <Boolean>] [-addAccounts <Boolean>]
 [-updateAccountContent <Boolean>] [-updateAccountProperties <Boolean>]
 [-initiateCPMAccountManagementOperations <Boolean>] [-specifyNextAccountContent <Boolean>]
 [-renameAccounts <Boolean>] [-deleteAccounts <Boolean>] [-unlockAccounts <Boolean>] [-manageSafe <Boolean>]
 [-manageSafeMembers <Boolean>] [-backupSafe <Boolean>] [-viewAuditLog <Boolean>] [-viewSafeMembers <Boolean>]
 [-accessWithoutConfirmation <Boolean>] [-createFolders <Boolean>] [-deleteFolders <Boolean>]
 [-moveAccountsAndFolders <Boolean>] [-requestsAuthorizationLevel1 <Boolean>]
 [-requestsAuthorizationLevel2 <Boolean>] [-permissions <SafePerms>] [-CreateOnMissing]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### memberObject
```
Set-SafeMember [-PVWAURL <String>] [-LogonToken <Object>] -SafeName <String> -memberObject <String>
 [-CreateOnMissing] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Set-SafeMember function updates the permissions of an existing member on a
safe in the Vault.
Accepts individual permission flags or a SafePerms object.
When the member does not exist and -CreateOnMissing is specified, Add-SafeMember
is called instead.

## EXAMPLES

### EXAMPLE 1
```
Set-SafeMember -SafeName "Finance" -memberName "JohnDoe" -useAccounts $true -retrieveAccounts $true
```

Updates JohnDoe's permissions on the Finance safe.

## PARAMETERS

### -accessWithoutConfirmation
{{ Fill accessWithoutConfirmation Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -addAccounts
{{ Fill addAccounts Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -backupSafe
{{ Fill backupSafe Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -createFolders
{{ Fill createFolders Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CreateOnMissing
When specified, calls Add-SafeMember if the member does not already exist.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -deleteAccounts
{{ Fill deleteAccounts Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -deleteFolders
{{ Fill deleteFolders Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -initiateCPMAccountManagementOperations
{{ Fill initiateCPMAccountManagementOperations Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -listAccounts
{{ Fill listAccounts Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -manageSafe
{{ Fill manageSafe Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -manageSafeMembers
{{ Fill manageSafeMembers Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -memberName
The name of the member to update.

```yaml
Type: String
Parameter Sets: memberName
Aliases: User

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -memberObject
A SafeMember object to update from.
When used, SafeName and memberName are
derived from the object.

```yaml
Type: String
Parameter Sets: memberObject
Aliases: SafeMember

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -membershipExpirationDate
The expiration date of the membership as a Unix timestamp.

```yaml
Type: Int32
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: 0
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -MemberType
The type of the member: User, Group, or Role.

```yaml
Type: String
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -moveAccountsAndFolders
{{ Fill moveAccountsAndFolders Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -permissions
{{ Fill permissions Description }}

```yaml
Type: SafePerms
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -renameAccounts
{{ Fill renameAccounts Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -requestsAuthorizationLevel1
{{ Fill requestsAuthorizationLevel1 Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -requestsAuthorizationLevel2
{{ Fill requestsAuthorizationLevel2 Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -retrieveAccounts
{{ Fill retrieveAccounts Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SafeName
The name of the safe containing the member.

```yaml
Type: String
Parameter Sets: (All)
Aliases: Safe

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -searchIn
The directory or vault to search for the member.

```yaml
Type: String
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -specifyNextAccountContent
{{ Fill specifyNextAccountContent Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -unlockAccounts
{{ Fill unlockAccounts Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -updateAccountContent
{{ Fill updateAccountContent Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -updateAccountProperties
{{ Fill updateAccountProperties Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -useAccounts
{{ Fill useAccounts Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -viewAuditLog
{{ Fill viewAuditLog Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -viewSafeMembers
{{ Fill viewSafeMembers Description }}

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires Manage Safe Members permission on the target safe.

## RELATED LINKS
