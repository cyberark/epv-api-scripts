---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Write-LogMessage

## SYNOPSIS
Writes a log message to the console and optionally to a log file with various formatting options.

## SYNTAX

```
Write-LogMessage [-MSG] <String> [-Header] [-SubHeader] [-Footer] [[-WriteLog] <Boolean>] [[-type] <String>]
 [[-LogFile] <String>] [[-pad] <Int32>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Write-LogMessage function logs messages to the console with optional headers, subheaders, and footers.
It also supports writing messages to a log file.
The function can handle different message types such as
Info, Warning, Error, Debug, Verbose, Success, LogOnly, and ErrorThrow.
It also masks sensitive information
like passwords in the messages.

## EXAMPLES

### EXAMPLE 1
```
Write-LogMessage -MSG "This is an info message" -type Info
```

Logs an info message to the console and the default log file.

### EXAMPLE 2
```
"This is a warning message" | Write-LogMessage -type Warning
```

Logs a warning message to the console and the default log file using pipeline input.

### EXAMPLE 3
```
Write-LogMessage -MSG "This is an error message" -type Error -LogFile "C:\Logs\error.log"
```

Logs an error message to the console and to the specified log file.

### EXAMPLE 4
```
Write-LogMessage -MSG "Critical system alert" -type Important
```

Logs an important message with special formatting (highlighted background/foreground colors).

### EXAMPLE 5
```
Write-LogMessage -MSG "Operation:	Details about the operation" -type Verbose -pad 25
```

Logs a verbose message with custom padding of 25 characters for better formatting.

## PARAMETERS

### -Footer
Adds a footer line after the message.
This parameter is optional.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -Header
Adds a header line before the message.
This parameter is optional.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogFile
The log file to write to.
if not provided and WriteLog is $true, a temporary log file named 'Log.Log' will be created.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -MSG
The message to log.
This parameter is mandatory and accepts pipeline input.

```yaml
Type: String
Parameter Sets: (All)
Aliases: Message

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -pad
The padding width for verbose messages when formatting message arrays.
The default value is 20.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: 20
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SubHeader
Adds a subheader line before the message.
This parameter is optional.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -type
The type of the message to log.
Valid values are 'Info', 'Important', 'Warning', 'Error', 'Debug', 'Verbose', 'Success',
'LogOnly', and 'ErrorThrow'.
The default value is 'Info'.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: Info
Accept pipeline input: False
Accept wildcard characters: False
```

### -WriteLog
Indicates whether to write the output to a log file.
The default value is $true.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: True
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function masks sensitive information like passwords in the messages to prevent accidental exposure.

## RELATED LINKS
