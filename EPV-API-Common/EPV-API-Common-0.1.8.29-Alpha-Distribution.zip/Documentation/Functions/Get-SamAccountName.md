---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-SamAccountName

## SYNOPSIS
Retrieves the SAMAccountName for a given User Principal Name (UPN) from Active Directory.

## SYNTAX

```
Get-SamAccountName [[-UserPrincipalName] <String>] [-NoErrorOnNull] [-ProgressAction <ActionPreference>]
 [<CommonParameters>]
```

## DESCRIPTION
Queries Active Directory for a user matching the provided UserPrincipalName and returns
their SAMAccountName.
Requires the ActiveDirectory module.
Accepts pipeline input.

## EXAMPLES

### EXAMPLE 1
```
Get-SamAccountName -UserPrincipalName 'jsmith@domain.com'
```

### EXAMPLE 2
```
'jsmith@domain.com','bdoe@domain.com' | Get-SamAccountName -NoErrorOnNull
```

## PARAMETERS

### -NoErrorOnNull
When specified, returns an empty string instead of writing an error if the user is not found.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: False
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -UserPrincipalName
The User Principal Name (UPN) to look up.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### String - The SAMAccountName of the matching user.
## NOTES
Requires the ActiveDirectory PowerShell module.

## RELATED LINKS
