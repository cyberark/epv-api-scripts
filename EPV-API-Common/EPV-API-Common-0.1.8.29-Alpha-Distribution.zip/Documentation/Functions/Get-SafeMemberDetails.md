---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-SafeMemberDetails

## SYNOPSIS
Gets details of a specific Safe member.

## SYNTAX

```
Get-SafeMemberDetails [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>]
 [-SafeUrlId] <String> [-MemberName] <String> [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-SafeMemberDetails function retrieves details for a specific member
of a Safe by name via the CyberArk PAM REST API.

## EXAMPLES

### EXAMPLE 1
```
Get-SafeMemberDetails -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeUrlId "MySafe" -MemberName "john.doe"
```

Returns details for the specified Safe member.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -MemberName
The name of the Safe member to retrieve.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The base URL of the PVWA instance (e.g.
https://pvwa.example.com).

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SafeUrlId
The URL-encoded ID of the Safe.

```yaml
Type: String
Parameter Sets: (All)
Aliases: SafeName, SafeID

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### Returns a Safe member details object.
## NOTES

## RELATED LINKS
