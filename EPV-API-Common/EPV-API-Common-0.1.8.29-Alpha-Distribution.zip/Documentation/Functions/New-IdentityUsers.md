---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# New-IdentityUsers

## SYNOPSIS
Creates multiple identity users in bulk.

## SYNTAX

```
New-IdentityUsers [[-CatchAll] <Object>] [[-IdentityURL] <String>] [[-LogonToken] <Object>]
 [-Users] <PSObject[]> [-SendEmailInvite] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
The New-IdentityUsers function creates multiple new users in the CyberArk Identity cloud directory in a single operation.
Only system administrators or users with user management rights can invoke this function.
The tenant config setting "CusCreateUser.QandD" must be set to TRUE to execute this function.

## EXAMPLES

### EXAMPLE 1
```
$users = @(
    @{ Name = "user1"; Email = "user1@example.com"; DisplayName = "User One" },
    @{ Name = "user2"; Email = "user2@example.com"; DisplayName = "User Two" }
)
New-IdentityUsers -IdentityURL "https://identity.example.com" -LogonToken $token -Users $users
```

### EXAMPLE 2
```
@{ Name = "jdoe"; Email = "jdoe@example.com"; DisplayName = "John Doe" } | New-IdentityUsers -SendEmailInvite
```

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the identity service.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SendEmailInvite
Send email invitations to the newly created users.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -Users
An array of user objects containing user details.
Each object should include properties like Name, Email, DisplayName, etc.

```yaml
Type: PSObject[]
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function requires user management permissions or system administrator rights.
The tenant config setting "CusCreateUser.QandD" must be set to TRUE.

## RELATED LINKS
