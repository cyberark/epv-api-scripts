---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-ApplicationDetail

## SYNOPSIS
Retrieves details of a specific application from the Vault.

## SYNTAX

```
Get-ApplicationDetail [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [-AppID] <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-ApplicationDetail function retrieves information about a specific application from the Vault.
The user running this command requires Audit Users permissions in the Vault.

## EXAMPLES

### EXAMPLE 1
```
Get-ApplicationDetail -PVWAURL "https://pvwa.example.com" -LogonToken $token -AppID "MyApp"
```

Retrieves details for the application named "MyApp".

## PARAMETERS

### -AppID
The name of the application about which information is returned.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA (Password Vault Web Access) API endpoint.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function uses the Invoke-Rest function to send a GET request to the PVWA API endpoint.
Requires Audit Users permissions in the Vault.
You cannot search for an application whose name includes @.
To find these applications, list all applications,
then find the specific application in the returned applications list.

## RELATED LINKS
