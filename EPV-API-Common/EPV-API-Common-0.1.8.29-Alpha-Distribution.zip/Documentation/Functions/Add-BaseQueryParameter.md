---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Add-BaseQueryParameter

## SYNOPSIS
Adds base query parameters to a URL.

## SYNTAX

```
Add-BaseQueryParameter [[-URL] <PSReference>] [[-sort] <String>] [[-offset] <String>] [[-limit] <String>]
 [-DoNotPage] [-useCache]
```

## DESCRIPTION
The Add-BaseQueryParameter function appends various query parameters to a given URL.
It supports parameters such as sort, offset, limit, and useCache.
It also logs the
actions performed at each step.

## EXAMPLES

### EXAMPLE 1
```
$URL = [ref] "http://example.com/api/resource"
Add-BaseQueryParameter -URL $URL -sort "name" -offset 10 -limit 50 -useCache
```

This example adds the sort, offset, limit, and useCache parameters to the given URL.

## PARAMETERS

### -DoNotPage
(Optional) If specified, indicates that paging is disabled.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -limit
(Optional) The limit parameter to be appended to the URL.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -offset
(Optional) The offset parameter to be appended to the URL.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -sort
(Optional) The sort parameter to be appended to the URL.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -URL
\[ref\] The URL to which the query parameters will be added.

```yaml
Type: PSReference
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -useCache
(Optional) If specified, indicates that session cache should be used for results.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

## OUTPUTS

## NOTES
This function requires the Write-LogMessage function to be defined for logging purposes.

## RELATED LINKS
