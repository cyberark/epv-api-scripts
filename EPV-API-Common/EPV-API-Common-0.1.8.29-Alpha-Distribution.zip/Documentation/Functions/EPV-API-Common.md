---
Module Name: EPV-API-Common
Module Guid: 42f9f4c6-bb1a-465a-9276-214b28f0e297
Download Help Link: {{ Update Download Link }}
Help Version: {{ Please enter version of help manually (X.X.X.X) format }}
Locale: en-US
---

# EPV-API-Common Module
## Description
{{ Fill in the Description }}

## EPV-API-Common Cmdlets
### [Add-AccountGroup](Add-AccountGroup.md)
{{ Fill in the Description }}

### [Add-AccountGroupMember](Add-AccountGroupMember.md)
{{ Fill in the Description }}

### [Add-ApplicationAuthenticationMethod](Add-ApplicationAuthenticationMethod.md)
{{ Fill in the Description }}

### [Add-BaseQueryParameter](Add-BaseQueryParameter.md)
{{ Fill in the Description }}

### [Add-DependentAccount](Add-DependentAccount.md)
{{ Fill in the Description }}

### [Add-DependentAccountLink](Add-DependentAccountLink.md)
{{ Fill in the Description }}

### [Add-IdentityRoleToGroup](Add-IdentityRoleToGroup.md)
{{ Fill in the Description }}

### [Add-IdentityRoleToUser](Add-IdentityRoleToUser.md)
{{ Fill in the Description }}

### [Add-OPMAccountRule](Add-OPMAccountRule.md)
{{ Fill in the Description }}

### [Add-OPMPolicyRule](Add-OPMPolicyRule.md)
{{ Fill in the Description }}

### [Add-PVWADiscoveredAccount](Add-PVWADiscoveredAccount.md)
{{ Fill in the Description }}

### [Add-SafeMember](Add-SafeMember.md)
{{ Fill in the Description }}

### [Add-UserGroupMember](Add-UserGroupMember.md)
{{ Fill in the Description }}

### [Add-UserGroupUser](Add-UserGroupUser.md)
{{ Fill in the Description }}

### [Add-VaultUser](Add-VaultUser.md)
{{ Fill in the Description }}

### [Add-VaultUserAllowedAuthMethod](Add-VaultUserAllowedAuthMethod.md)
{{ Fill in the Description }}

### [Add-VaultUserGroup](Add-VaultUserGroup.md)
{{ Fill in the Description }}

### [Add-VaultUserSSHKey](Add-VaultUserSSHKey.md)
{{ Fill in the Description }}

### [Approve-IncomingRequest](Approve-IncomingRequest.md)
{{ Fill in the Description }}

### [Approve-IncomingRequestBulk](Approve-IncomingRequestBulk.md)
{{ Fill in the Description }}

### [Clear-AccountLink](Clear-AccountLink.md)
{{ Fill in the Description }}

### [Clear-MFACachingSSHKeys](Clear-MFACachingSSHKeys.md)
{{ Fill in the Description }}

### [Connect-AccountPSM](Connect-AccountPSM.md)
{{ Fill in the Description }}

### [Connect-AccountPSMAdHoc](Connect-AccountPSMAdHoc.md)
{{ Fill in the Description }}

### [Connect-PASUser](Connect-PASUser.md)
{{ Fill in the Description }}

### [Connect-PTAUser](Connect-PTAUser.md)
{{ Fill in the Description }}

### [Connect-SAMLUser](Connect-SAMLUser.md)
{{ Fill in the Description }}

### [Connect-SharedPASUser](Connect-SharedPASUser.md)
{{ Fill in the Description }}

### [Copy-DependentPlatform](Copy-DependentPlatform.md)
{{ Fill in the Description }}

### [Copy-GroupPlatform](Copy-GroupPlatform.md)
{{ Fill in the Description }}

### [Copy-PlatformDependent](Copy-PlatformDependent.md)
{{ Fill in the Description }}

### [Copy-RotationalGroupPlatform](Copy-RotationalGroupPlatform.md)
{{ Fill in the Description }}

### [Copy-TargetPlatform](Copy-TargetPlatform.md)
{{ Fill in the Description }}

### [Deny-IncomingRequest](Deny-IncomingRequest.md)
{{ Fill in the Description }}

### [Deny-IncomingRequestBulk](Deny-IncomingRequestBulk.md)
{{ Fill in the Description }}

### [Disable-GroupPlatform](Disable-GroupPlatform.md)
{{ Fill in the Description }}

### [Disable-RotationalGroupPlatform](Disable-RotationalGroupPlatform.md)
{{ Fill in the Description }}

### [Disable-TargetPlatform](Disable-TargetPlatform.md)
{{ Fill in the Description }}

### [Disable-VaultUser](Disable-VaultUser.md)
{{ Fill in the Description }}

### [Disconnect-IdentityUserSession](Disconnect-IdentityUserSession.md)
{{ Fill in the Description }}

### [Disconnect-PASUser](Disconnect-PASUser.md)
{{ Fill in the Description }}

### [Disconnect-SharedPASUser](Disconnect-SharedPASUser.md)
{{ Fill in the Description }}

### [Edit-LDAPDirectoryMapping](Edit-LDAPDirectoryMapping.md)
{{ Fill in the Description }}

### [Enable-GroupPlatform](Enable-GroupPlatform.md)
{{ Fill in the Description }}

### [Enable-RotationalGroupPlatform](Enable-RotationalGroupPlatform.md)
{{ Fill in the Description }}

### [Enable-TargetPlatform](Enable-TargetPlatform.md)
{{ Fill in the Description }}

### [Enable-VaultUser](Enable-VaultUser.md)
{{ Fill in the Description }}

### [Export-DependentPlatform](Export-DependentPlatform.md)
{{ Fill in the Description }}

### [Export-GroupPlatform](Export-GroupPlatform.md)
{{ Fill in the Description }}

### [Export-Platform](Export-Platform.md)
{{ Fill in the Description }}

### [Export-RotationalGroupPlatform](Export-RotationalGroupPlatform.md)
{{ Fill in the Description }}

### [Export-Safe](Export-Safe.md)
{{ Fill in the Description }}

### [Export-SafeMember](Export-SafeMember.md)
{{ Fill in the Description }}

### [Export-TargetPlatform](Export-TargetPlatform.md)
{{ Fill in the Description }}

### [Get-AccessRequest](Get-AccessRequest.md)
{{ Fill in the Description }}

### [Get-AccessRequestDetails](Get-AccessRequestDetails.md)
{{ Fill in the Description }}

### [Get-Account](Get-Account.md)
{{ Fill in the Description }}

### [Get-AccountActivity](Get-AccountActivity.md)
{{ Fill in the Description }}

### [Get-AccountAdvancedSearchProperty](Get-AccountAdvancedSearchProperty.md)
{{ Fill in the Description }}

### [Get-AccountDetails](Get-AccountDetails.md)
{{ Fill in the Description }}

### [Get-AccountGroup](Get-AccountGroup.md)
{{ Fill in the Description }}

### [Get-AccountGroupMember](Get-AccountGroupMember.md)
{{ Fill in the Description }}

### [Get-AccountGroups](Get-AccountGroups.md)
{{ Fill in the Description }}

### [Get-AccountPassword](Get-AccountPassword.md)
{{ Fill in the Description }}

### [Get-AccountPrivateSSHKey](Get-AccountPrivateSSHKey.md)
{{ Fill in the Description }}

### [Get-AccountSecretVersions](Get-AccountSecretVersions.md)
{{ Fill in the Description }}

### [Get-ActiveTheme](Get-ActiveTheme.md)
{{ Fill in the Description }}

### [Get-AllDependentAccounts](Get-AllDependentAccounts.md)
{{ Fill in the Description }}

### [Get-AllowedReferrer](Get-AllowedReferrer.md)
{{ Fill in the Description }}

### [Get-Application](Get-Application.md)
{{ Fill in the Description }}

### [Get-ApplicationAuthenticationMethod](Get-ApplicationAuthenticationMethod.md)
{{ Fill in the Description }}

### [Get-ApplicationDetail](Get-ApplicationDetail.md)
{{ Fill in the Description }}

### [Get-AuthenticationMethod](Get-AuthenticationMethod.md)
{{ Fill in the Description }}

### [Get-AuthenticationMethodDetails](Get-AuthenticationMethodDetails.md)
{{ Fill in the Description }}

### [Get-BulkAction](Get-BulkAction.md)
{{ Fill in the Description }}

### [Get-BulkActionDetails](Get-BulkActionDetails.md)
{{ Fill in the Description }}

### [Get-ClassicReport](Get-ClassicReport.md)
{{ Fill in the Description }}

### [Get-CPMUser](Get-CPMUser.md)
{{ Fill in the Description }}

### [Get-DependentAccount](Get-DependentAccount.md)
{{ Fill in the Description }}

### [Get-DependentAccountDetails](Get-DependentAccountDetails.md)
{{ Fill in the Description }}

### [Get-DependentPlatform](Get-DependentPlatform.md)
{{ Fill in the Description }}

### [Get-DirectoryService](Get-DirectoryService.md)
{{ Fill in the Description }}

### [Get-DiscoveryScan](Get-DiscoveryScan.md)
{{ Fill in the Description }}

### [Get-DiscoveryScanDetails](Get-DiscoveryScanDetails.md)
{{ Fill in the Description }}

### [Get-FIDO2RegistrationOptions](Get-FIDO2RegistrationOptions.md)
{{ Fill in the Description }}

### [Get-GroupPlatform](Get-GroupPlatform.md)
{{ Fill in the Description }}

### [Get-IdentityGroup](Get-IdentityGroup.md)
{{ Fill in the Description }}

### [Get-IdentityRole](Get-IdentityRole.md)
{{ Fill in the Description }}

### [Get-IdentityRoleInDir](Get-IdentityRoleInDir.md)
{{ Fill in the Description }}

### [Get-IdentityRoleMember](Get-IdentityRoleMember.md)
{{ Fill in the Description }}

### [Get-IdentityUser](Get-IdentityUser.md)
{{ Fill in the Description }}

### [Get-IdentityUserAttributes](Get-IdentityUserAttributes.md)
{{ Fill in the Description }}

### [Get-IdentityUserByName](Get-IdentityUserByName.md)
{{ Fill in the Description }}

### [Get-IdentityUserHierarchy](Get-IdentityUserHierarchy.md)
{{ Fill in the Description }}

### [Get-IdentityUserInfo](Get-IdentityUserInfo.md)
{{ Fill in the Description }}

### [Get-IdentityUserPicture](Get-IdentityUserPicture.md)
{{ Fill in the Description }}

### [Get-IdentityUserSecurityQuestions](Get-IdentityUserSecurityQuestions.md)
{{ Fill in the Description }}

### [Get-IncomingRequest](Get-IncomingRequest.md)
{{ Fill in the Description }}

### [Get-IncomingRequestDetails](Get-IncomingRequestDetails.md)
{{ Fill in the Description }}

### [Get-LDAPDirectory](Get-LDAPDirectory.md)
{{ Fill in the Description }}

### [Get-LDAPDirectoryDetails](Get-LDAPDirectoryDetails.md)
{{ Fill in the Description }}

### [Get-LDAPDirectoryMapping](Get-LDAPDirectoryMapping.md)
{{ Fill in the Description }}

### [Get-LDAPDirectoryMappingDetails](Get-LDAPDirectoryMappingDetails.md)
{{ Fill in the Description }}

### [Get-LicenseClient](Get-LicenseClient.md)
{{ Fill in the Description }}

### [Get-LiveSession](Get-LiveSession.md)
{{ Fill in the Description }}

### [Get-LiveSessionActivity](Get-LiveSessionActivity.md)
{{ Fill in the Description }}

### [Get-LiveSessionDetails](Get-LiveSessionDetails.md)
{{ Fill in the Description }}

### [Get-LiveSessionProperties](Get-LiveSessionProperties.md)
{{ Fill in the Description }}

### [Get-LoginsInfo](Get-LoginsInfo.md)
{{ Fill in the Description }}

### [Get-MultipleAccessRequestStatus](Get-MultipleAccessRequestStatus.md)
{{ Fill in the Description }}

### [Get-OAuthInfo](Get-OAuthInfo.md)
{{ Fill in the Description }}

### [Get-OAuthProvider](Get-OAuthProvider.md)
{{ Fill in the Description }}

### [Get-OIDCProvider](Get-OIDCProvider.md)
{{ Fill in the Description }}

### [Get-OIDCProviderDetails](Get-OIDCProviderDetails.md)
{{ Fill in the Description }}

### [Get-OnboardingRule](Get-OnboardingRule.md)
{{ Fill in the Description }}

### [Get-OPMAccountRule](Get-OPMAccountRule.md)
{{ Fill in the Description }}

### [Get-OPMPolicyRule](Get-OPMPolicyRule.md)
{{ Fill in the Description }}

### [Get-Platform](Get-Platform.md)
{{ Fill in the Description }}

### [Get-PlatformDetails](Get-PlatformDetails.md)
{{ Fill in the Description }}

### [Get-PlatformSafes](Get-PlatformSafes.md)
{{ Fill in the Description }}

### [Get-PlatformStorage](Get-PlatformStorage.md)
{{ Fill in the Description }}

### [Get-PlatformSystemType](Get-PlatformSystemType.md)
{{ Fill in the Description }}

### [Get-Policy](Get-Policy.md)
{{ Fill in the Description }}

### [Get-PPAUserGroup](Get-PPAUserGroup.md)
{{ Fill in the Description }}

### [Get-PSMConnector](Get-PSMConnector.md)
{{ Fill in the Description }}

### [Get-PSMServer](Get-PSMServer.md)
{{ Fill in the Description }}

### [Get-PSMSession](Get-PSMSession.md)
{{ Fill in the Description }}

### [Get-PVWADiscoveredAccount](Get-PVWADiscoveredAccount.md)
{{ Fill in the Description }}

### [Get-PVWADiscoveredAccountDetails](Get-PVWADiscoveredAccountDetails.md)
{{ Fill in the Description }}

### [Get-PVWADiscoveredAccountPlatform](Get-PVWADiscoveredAccountPlatform.md)
{{ Fill in the Description }}

### [Get-PVWAImage](Get-PVWAImage.md)
{{ Fill in the Description }}

### [Get-PVWAServerInfo](Get-PVWAServerInfo.md)
{{ Fill in the Description }}

### [Get-PVWAServerLogo](Get-PVWAServerLogo.md)
{{ Fill in the Description }}

### [Get-PVWAServerVerify](Get-PVWAServerVerify.md)
{{ Fill in the Description }}

### [Get-Recording](Get-Recording.md)
{{ Fill in the Description }}

### [Get-RecordingActivity](Get-RecordingActivity.md)
{{ Fill in the Description }}

### [Get-RecordingDetails](Get-RecordingDetails.md)
{{ Fill in the Description }}

### [Get-RecordingPlayback](Get-RecordingPlayback.md)
{{ Fill in the Description }}

### [Get-RecordingProperties](Get-RecordingProperties.md)
{{ Fill in the Description }}

### [Get-Report](Get-Report.md)
{{ Fill in the Description }}

### [Get-ReportActivities](Get-ReportActivities.md)
{{ Fill in the Description }}

### [Get-ReportContent](Get-ReportContent.md)
{{ Fill in the Description }}

### [Get-ReportSettings](Get-ReportSettings.md)
{{ Fill in the Description }}

### [Get-RotationalGroupPlatform](Get-RotationalGroupPlatform.md)
{{ Fill in the Description }}

### [Get-Safe](Get-Safe.md)
{{ Fill in the Description }}

### [Get-SafeDetails](Get-SafeDetails.md)
{{ Fill in the Description }}

### [Get-SafeMember](Get-SafeMember.md)
{{ Fill in the Description }}

### [Get-SafeMemberDetails](Get-SafeMemberDetails.md)
{{ Fill in the Description }}

### [Get-SamAccountName](Get-SamAccountName.md)
{{ Fill in the Description }}

### [Get-SystemHealth](Get-SystemHealth.md)
{{ Fill in the Description }}

### [Get-SystemHealthDetails](Get-SystemHealthDetails.md)
{{ Fill in the Description }}

### [Get-TargetPlatform](Get-TargetPlatform.md)
{{ Fill in the Description }}

### [Get-TargetPlatformPSM](Get-TargetPlatformPSM.md)
{{ Fill in the Description }}

### [Get-Task](Get-Task.md)
{{ Fill in the Description }}

### [Get-Theme](Get-Theme.md)
{{ Fill in the Description }}

### [Get-ThemeDetails](Get-ThemeDetails.md)
{{ Fill in the Description }}

### [Get-UPN](Get-UPN.md)
{{ Fill in the Description }}

### [Get-UserGroup](Get-UserGroup.md)
{{ Fill in the Description }}

### [Get-UserGroupDetails](Get-UserGroupDetails.md)
{{ Fill in the Description }}

### [Get-VaultDRSystemHealth](Get-VaultDRSystemHealth.md)
{{ Fill in the Description }}

### [Get-VaultLoggedOnUser](Get-VaultLoggedOnUser.md)
{{ Fill in the Description }}

### [Get-VaultServiceConfig](Get-VaultServiceConfig.md)
{{ Fill in the Description }}

### [Get-VaultServiceConfigParam](Get-VaultServiceConfigParam.md)
{{ Fill in the Description }}

### [Get-VaultServiceStatus](Get-VaultServiceStatus.md)
{{ Fill in the Description }}

### [Get-VaultUser](Get-VaultUser.md)
{{ Fill in the Description }}

### [Get-VaultUserDetails](Get-VaultUserDetails.md)
{{ Fill in the Description }}

### [Get-VaultUserSafe](Get-VaultUserSafe.md)
{{ Fill in the Description }}

### [Get-VaultUserSSHKey](Get-VaultUserSSHKey.md)
{{ Fill in the Description }}

### [Get-VaultUserType](Get-VaultUserType.md)
{{ Fill in the Description }}

### [Grant-AccountAdministrativeAccess](Grant-AccountAdministrativeAccess.md)
{{ Fill in the Description }}

### [Import-ConnectionComponent](Import-ConnectionComponent.md)
{{ Fill in the Description }}

### [Import-Platform](Import-Platform.md)
{{ Fill in the Description }}

### [Import-Safe](Import-Safe.md)
{{ Fill in the Description }}

### [Import-SafeMember](Import-SafeMember.md)
{{ Fill in the Description }}

### [Import-StoredPlatform](Import-StoredPlatform.md)
{{ Fill in the Description }}

### [Invoke-AccountChangeBulk](Invoke-AccountChangeBulk.md)
{{ Fill in the Description }}

### [Invoke-AccountCheckIn](Invoke-AccountCheckIn.md)
{{ Fill in the Description }}

### [Invoke-AccountPasswordChange](Invoke-AccountPasswordChange.md)
{{ Fill in the Description }}

### [Invoke-AccountReconcile](Invoke-AccountReconcile.md)
{{ Fill in the Description }}

### [Invoke-AccountReconcileBulk](Invoke-AccountReconcileBulk.md)
{{ Fill in the Description }}

### [Invoke-AccountVerify](Invoke-AccountVerify.md)
{{ Fill in the Description }}

### [Invoke-AccountVerifyBulk](Invoke-AccountVerifyBulk.md)
{{ Fill in the Description }}

### [Invoke-LiveSessionAction](Invoke-LiveSessionAction.md)
{{ Fill in the Description }}

### [Invoke-RefreshIdentityUser](Invoke-RefreshIdentityUser.md)
{{ Fill in the Description }}

### [Invoke-VaultUserActivation](Invoke-VaultUserActivation.md)
{{ Fill in the Description }}

### [New-AccessRequest](New-AccessRequest.md)
{{ Fill in the Description }}

### [New-Account](New-Account.md)
{{ Fill in the Description }}

### [New-AccountPassword](New-AccountPassword.md)
{{ Fill in the Description }}

### [New-AllowedReferrer](New-AllowedReferrer.md)
{{ Fill in the Description }}

### [New-Application](New-Application.md)
{{ Fill in the Description }}

### [New-AuthenticationMethod](New-AuthenticationMethod.md)
{{ Fill in the Description }}

### [New-BulkAction](New-BulkAction.md)
{{ Fill in the Description }}

### [New-Connector](New-Connector.md)
{{ Fill in the Description }}

### [New-DiscoveryScan](New-DiscoveryScan.md)
{{ Fill in the Description }}

### [New-IdentityRole](New-IdentityRole.md)
{{ Fill in the Description }}

### [New-IdentityUser](New-IdentityUser.md)
{{ Fill in the Description }}

### [New-IdentityUsers](New-IdentityUsers.md)
{{ Fill in the Description }}

### [New-LDAPDirectory](New-LDAPDirectory.md)
{{ Fill in the Description }}

### [New-LDAPDirectoryMapping](New-LDAPDirectoryMapping.md)
{{ Fill in the Description }}

### [New-MFACachingSSHKey](New-MFACachingSSHKey.md)
{{ Fill in the Description }}

### [New-MFACachingSSHKeyForUser](New-MFACachingSSHKeyForUser.md)
{{ Fill in the Description }}

### [New-MultipleAccessRequest](New-MultipleAccessRequest.md)
{{ Fill in the Description }}

### [New-OAuthProvider](New-OAuthProvider.md)
{{ Fill in the Description }}

### [New-OIDCProvider](New-OIDCProvider.md)
{{ Fill in the Description }}

### [New-OnboardingRule](New-OnboardingRule.md)
{{ Fill in the Description }}

### [New-PersonalPrivilegedAccount](New-PersonalPrivilegedAccount.md)
{{ Fill in the Description }}

### [New-PVWAImage](New-PVWAImage.md)
{{ Fill in the Description }}

### [New-Safe](New-Safe.md)
{{ Fill in the Description }}

### [New-Session](New-Session.md)
{{ Fill in the Description }}

### [New-Task](New-Task.md)
{{ Fill in the Description }}

### [New-Theme](New-Theme.md)
{{ Fill in the Description }}

### [New-UserGroup](New-UserGroup.md)
{{ Fill in the Description }}

### [Register-FIDO2Device](Register-FIDO2Device.md)
{{ Fill in the Description }}

### [Register-OwnFIDO2Device](Register-OwnFIDO2Device.md)
{{ Fill in the Description }}

### [Remove-AccessRequest](Remove-AccessRequest.md)
{{ Fill in the Description }}

### [Remove-Account](Remove-Account.md)
{{ Fill in the Description }}

### [Remove-AccountGroupMember](Remove-AccountGroupMember.md)
{{ Fill in the Description }}

### [Remove-ActiveTheme](Remove-ActiveTheme.md)
{{ Fill in the Description }}

### [Remove-Application](Remove-Application.md)
{{ Fill in the Description }}

### [Remove-ApplicationAuthenticationMethod](Remove-ApplicationAuthenticationMethod.md)
{{ Fill in the Description }}

### [Remove-AuthenticationMethod](Remove-AuthenticationMethod.md)
{{ Fill in the Description }}

### [Remove-DependentAccount](Remove-DependentAccount.md)
{{ Fill in the Description }}

### [Remove-DependentAccountLink](Remove-DependentAccountLink.md)
{{ Fill in the Description }}

### [Remove-DependentPlatform](Remove-DependentPlatform.md)
{{ Fill in the Description }}

### [Remove-DiscoveryScan](Remove-DiscoveryScan.md)
{{ Fill in the Description }}

### [Remove-FIDO2Device](Remove-FIDO2Device.md)
{{ Fill in the Description }}

### [Remove-GroupPlatform](Remove-GroupPlatform.md)
{{ Fill in the Description }}

### [Remove-IdentityRole](Remove-IdentityRole.md)
{{ Fill in the Description }}

### [Remove-IdentityRoleFromUser](Remove-IdentityRoleFromUser.md)
{{ Fill in the Description }}

### [Remove-IdentityUser](Remove-IdentityUser.md)
{{ Fill in the Description }}

### [Remove-IdentityUsers](Remove-IdentityUsers.md)
{{ Fill in the Description }}

### [Remove-LDAPDirectory](Remove-LDAPDirectory.md)
{{ Fill in the Description }}

### [Remove-LDAPDirectoryMapping](Remove-LDAPDirectoryMapping.md)
{{ Fill in the Description }}

### [Remove-MFACachingSSHKey](Remove-MFACachingSSHKey.md)
{{ Fill in the Description }}

### [Remove-MFACachingSSHKeyForUser](Remove-MFACachingSSHKeyForUser.md)
{{ Fill in the Description }}

### [Remove-OAuthProvider](Remove-OAuthProvider.md)
{{ Fill in the Description }}

### [Remove-OIDCProvider](Remove-OIDCProvider.md)
{{ Fill in the Description }}

### [Remove-OnboardingRule](Remove-OnboardingRule.md)
{{ Fill in the Description }}

### [Remove-OPMAccountRule](Remove-OPMAccountRule.md)
{{ Fill in the Description }}

### [Remove-OPMPolicyRule](Remove-OPMPolicyRule.md)
{{ Fill in the Description }}

### [Remove-OwnFIDO2Device](Remove-OwnFIDO2Device.md)
{{ Fill in the Description }}

### [Remove-PlatformStorage](Remove-PlatformStorage.md)
{{ Fill in the Description }}

### [Remove-PVWADiscoveredAccount](Remove-PVWADiscoveredAccount.md)
{{ Fill in the Description }}

### [Remove-PVWADiscoveredAccountBulk](Remove-PVWADiscoveredAccountBulk.md)
{{ Fill in the Description }}

### [Remove-PVWADiscoveredAccounts](Remove-PVWADiscoveredAccounts.md)
{{ Fill in the Description }}

### [Remove-RotationalGroupPlatform](Remove-RotationalGroupPlatform.md)
{{ Fill in the Description }}

### [Remove-Safe](Remove-Safe.md)
{{ Fill in the Description }}

### [Remove-SafeMember](Remove-SafeMember.md)
{{ Fill in the Description }}

### [Remove-SensitiveData](Remove-SensitiveData.md)
{{ Fill in the Description }}

### [Remove-TargetPlatform](Remove-TargetPlatform.md)
{{ Fill in the Description }}

### [Remove-Theme](Remove-Theme.md)
{{ Fill in the Description }}

### [Remove-UserGroup](Remove-UserGroup.md)
{{ Fill in the Description }}

### [Remove-UserGroupMember](Remove-UserGroupMember.md)
{{ Fill in the Description }}

### [Remove-VaultUser](Remove-VaultUser.md)
{{ Fill in the Description }}

### [Remove-VaultUserAllowedAuthMethod](Remove-VaultUserAllowedAuthMethod.md)
{{ Fill in the Description }}

### [Remove-VaultUserGroup](Remove-VaultUserGroup.md)
{{ Fill in the Description }}

### [Remove-VaultUserSSHKey](Remove-VaultUserSSHKey.md)
{{ Fill in the Description }}

### [Reset-IdentityUserPassword](Reset-IdentityUserPassword.md)
{{ Fill in the Description }}

### [Reset-VaultUserPassword](Reset-VaultUserPassword.md)
{{ Fill in the Description }}

### [Restart-VaultService](Restart-VaultService.md)
{{ Fill in the Description }}

### [Resume-DependentAccount](Resume-DependentAccount.md)
{{ Fill in the Description }}

### [Resume-DependentAccountBulk](Resume-DependentAccountBulk.md)
{{ Fill in the Description }}

### [Resume-LiveSession](Resume-LiveSession.md)
{{ Fill in the Description }}

### [Revoke-AccountAdministrativeAccess](Revoke-AccountAdministrativeAccess.md)
{{ Fill in the Description }}

### [Save-PPAUserGroupMember](Save-PPAUserGroupMember.md)
{{ Fill in the Description }}

### [Send-IdentityUserInvite](Send-IdentityUserInvite.md)
{{ Fill in the Description }}

### [Send-IdentityUserSmsInvite](Send-IdentityUserSmsInvite.md)
{{ Fill in the Description }}

### [Set-Account](Set-Account.md)
{{ Fill in the Description }}

### [Set-AccountLink](Set-AccountLink.md)
{{ Fill in the Description }}

### [Set-AccountNextPassword](Set-AccountNextPassword.md)
{{ Fill in the Description }}

### [Set-AccountNextPasswordBulk](Set-AccountNextPasswordBulk.md)
{{ Fill in the Description }}

### [Set-AccountPassword](Set-AccountPassword.md)
{{ Fill in the Description }}

### [Set-AccountPasswordBulk](Set-AccountPasswordBulk.md)
{{ Fill in the Description }}

### [Set-ActiveTheme](Set-ActiveTheme.md)
{{ Fill in the Description }}

### [Set-AuthenticationMethod](Set-AuthenticationMethod.md)
{{ Fill in the Description }}

### [Set-DependentAccount](Set-DependentAccount.md)
{{ Fill in the Description }}

### [Set-EPVTimeDisplay](Set-EPVTimeDisplay.md)
{{ Fill in the Description }}

### [Set-IdentityUser](Set-IdentityUser.md)
{{ Fill in the Description }}

### [Set-IdentityUserCloudLock](Set-IdentityUserCloudLock.md)
{{ Fill in the Description }}

### [Set-IdentityUserPhonePin](Set-IdentityUserPhonePin.md)
{{ Fill in the Description }}

### [Set-IdentityUserPicture](Set-IdentityUserPicture.md)
{{ Fill in the Description }}

### [Set-IdentityUserState](Set-IdentityUserState.md)
{{ Fill in the Description }}

### [Set-LDAPDirectoryMapping](Set-LDAPDirectoryMapping.md)
{{ Fill in the Description }}

### [Set-LDAPDirectoryMappingOrder](Set-LDAPDirectoryMappingOrder.md)
{{ Fill in the Description }}

### [Set-OAuthProvider](Set-OAuthProvider.md)
{{ Fill in the Description }}

### [Set-OIDCProvider](Set-OIDCProvider.md)
{{ Fill in the Description }}

### [Set-OnboardingRule](Set-OnboardingRule.md)
{{ Fill in the Description }}

### [Set-Policy](Set-Policy.md)
{{ Fill in the Description }}

### [Set-Safe](Set-Safe.md)
{{ Fill in the Description }}

### [Set-SafeMember](Set-SafeMember.md)
{{ Fill in the Description }}

### [Set-Session](Set-Session.md)
{{ Fill in the Description }}

### [Set-TargetPlatformName](Set-TargetPlatformName.md)
{{ Fill in the Description }}

### [Set-TargetPlatformPSM](Set-TargetPlatformPSM.md)
{{ Fill in the Description }}

### [Set-Theme](Set-Theme.md)
{{ Fill in the Description }}

### [Set-ThemeDraft](Set-ThemeDraft.md)
{{ Fill in the Description }}

### [Set-UserGroup](Set-UserGroup.md)
{{ Fill in the Description }}

### [Set-VaultServiceConfig](Set-VaultServiceConfig.md)
{{ Fill in the Description }}

### [Set-VaultUser](Set-VaultUser.md)
{{ Fill in the Description }}

### [Start-FIDO2Registration](Start-FIDO2Registration.md)
{{ Fill in the Description }}

### [Start-OwnFIDO2Registration](Start-OwnFIDO2Registration.md)
{{ Fill in the Description }}

### [Start-PVWADiscoveredAccountOnboard](Start-PVWADiscoveredAccountOnboard.md)
{{ Fill in the Description }}

### [Start-PVWADiscoveredAccountOnboardBulk](Start-PVWADiscoveredAccountOnboardBulk.md)
{{ Fill in the Description }}

### [Start-VaultDRFailover](Start-VaultDRFailover.md)
{{ Fill in the Description }}

### [Start-VaultService](Start-VaultService.md)
{{ Fill in the Description }}

### [Stop-DiscoveryScan](Stop-DiscoveryScan.md)
{{ Fill in the Description }}

### [Stop-LiveSession](Stop-LiveSession.md)
{{ Fill in the Description }}

### [Stop-VaultService](Stop-VaultService.md)
{{ Fill in the Description }}

### [Suspend-LiveSession](Suspend-LiveSession.md)
{{ Fill in the Description }}

### [Sync-DependentAccount](Sync-DependentAccount.md)
{{ Fill in the Description }}

### [Sync-DependentAccountBulk](Sync-DependentAccountBulk.md)
{{ Fill in the Description }}

### [Sync-DependentAccountBulkSecret](Sync-DependentAccountBulkSecret.md)
{{ Fill in the Description }}

### [Test-IdentityUserCloudLock](Test-IdentityUserCloudLock.md)
{{ Fill in the Description }}

### [Test-RecordingValid](Test-RecordingValid.md)
{{ Fill in the Description }}

### [Unlock-Account](Unlock-Account.md)
{{ Fill in the Description }}

### [Unlock-AccountBulk](Unlock-AccountBulk.md)
{{ Fill in the Description }}

### [Update-IdentityUserSecurityQuestions](Update-IdentityUserSecurityQuestions.md)
{{ Fill in the Description }}

### [Update-TargetPlatform](Update-TargetPlatform.md)
{{ Fill in the Description }}

### [Write-LogMessage](Write-LogMessage.md)
{{ Fill in the Description }}

