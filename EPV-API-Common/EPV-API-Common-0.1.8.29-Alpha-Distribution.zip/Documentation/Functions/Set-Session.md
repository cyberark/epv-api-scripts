---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Set-Session

## SYNOPSIS
Restores a CyberArk session from a pre-existing token without re-authenticating.

## SYNTAX

### PCloudURL
```
Set-Session -Token <String> -PCloudURL <String> [-LogFile <String>] [-OutputResults] [-OutputErrors]
 [-UseResultFile] [-UseErrorFile] [-UseVerboseFile] [-IncludeCallStack] [-ProgressAction <ActionPreference>]
 [<CommonParameters>]
```

### PVWAURL
```
Set-Session -Token <String> -PVWAURL <String> [-LogFile <String>] [-OutputResults] [-OutputErrors]
 [-UseResultFile] [-UseErrorFile] [-UseVerboseFile] [-IncludeCallStack] [-ProgressAction <ActionPreference>]
 [<CommonParameters>]
```

### oauthCreds
```
Set-Session -OAuthInfo <Object> [-LogFile <String>] [-OutputResults] [-OutputErrors] [-UseResultFile]
 [-UseErrorFile] [-UseVerboseFile] [-IncludeCallStack] [-ProgressAction <ActionPreference>]
 [<CommonParameters>]
```

## DESCRIPTION
Configures module-wide default parameter values from a previously obtained token or
OAuthInfo object, allowing commands to be used without calling New-Session again.
Supports on-premises PVWA (Token + PVWAURL), Privileged Cloud (Token + PCloudURL),
and OAuth (OAuthInfo) parameter sets.

## EXAMPLES

### EXAMPLE 1
```
Set-Session -Token $token -PCloudURL 'https://tenant.privilegecloud.cyberark.cloud/PasswordVault'
```

### EXAMPLE 2
```
Set-Session -OAuthInfo (Get-OAuthInfo)
```

## PARAMETERS

### -IncludeCallStack
{{ Fill IncludeCallStack Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogFile
Path to the log file.
Defaults to '.\Log.Log' if not specified.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -OAuthInfo
The OAuthInfo hashtable returned by Get-OAuthInfo from a previous session.
Used with the oauthCreds parameter set.

```yaml
Type: Object
Parameter Sets: oauthCreds
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -OutputErrors
Enables error output logging to console.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -OutputResults
Enables success output logging to console.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -PCloudURL
The URL of the Privileged Cloud environment.
Mandatory when restoring a PCloud session.

```yaml
Type: String
Parameter Sets: PCloudURL
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the on-premises PVWA.
Mandatory when restoring an on-premises session.

```yaml
Type: String
Parameter Sets: PVWAURL
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Token
A valid Bearer or logon token obtained from a previous session.
Used with the PVWAURL or PCloudURL parameter sets.

```yaml
Type: String
Parameter Sets: PCloudURL, PVWAURL
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -UseErrorFile
Enables logging of errors to a separate error file.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -UseResultFile
Enables logging of successful operations to a separate result file.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -UseVerboseFile
{{ Fill UseVerboseFile Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Use this function to resume a session in a new script without calling New-Session.
The token must still be valid and not expired.

## RELATED LINKS
