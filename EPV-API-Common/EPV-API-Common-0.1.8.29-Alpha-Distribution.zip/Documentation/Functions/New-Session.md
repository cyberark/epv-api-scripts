---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# New-Session

## SYNOPSIS
Creates a new session for connecting to CyberArk environments.

## SYNTAX

### PCloudURL
```
New-Session [-Username <String>] [-Password <SecureString>] [-Creds <PSCredential>] -PCloudURL <String>
 [-IdentityURL <String>] [-LogFile <String>] [-OutputResults] [-OutputErrors] [-UseResultFile] [-UseErrorFile]
 [-UseVerboseFile] [-IncludeCallStack] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### PCloudSubdomain
```
New-Session [-Username <String>] [-Password <SecureString>] [-Creds <PSCredential>] -PCloudSubdomain <String>
 [-IdentityURL <String>] [-LogFile <String>] [-OutputResults] [-OutputErrors] [-UseResultFile] [-UseErrorFile]
 [-UseVerboseFile] [-IncludeCallStack] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### PVWAURL
```
New-Session [-Username <String>] [-Password <SecureString>] [-Creds <PSCredential>] -PVWAURL <String>
 [-LogFile <String>] [-OutputResults] [-OutputErrors] [-UseResultFile] [-UseErrorFile] [-UseVerboseFile]
 [-IncludeCallStack] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### OAuthCreds
```
New-Session -PCloudURL <String> [-IdentityURL <String>] -OAuthCreds <PSCredential> [-LogFile <String>]
 [-OutputResults] [-OutputErrors] [-UseResultFile] [-UseErrorFile] [-UseVerboseFile] [-IncludeCallStack]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The New-Session function establishes a new session for connecting to CyberArk environments, including PVWA and Privileged Cloud.
It supports multiple parameter sets for different connection scenarios and handles credentials securely.

For Privileged Cloud connections, the following authentication methods are supported:
- Username/Password with optional MFA (OTP, push notification, etc.)
- OAuth client credentials
- OOBAUTHPIN: if the Identity tenant requires SAML authentication, the user will be prompted
  to open a browser URL to complete SAML, then enter the PIN received via email or SMS.

## EXAMPLES

### EXAMPLE 1
```
New-Session -Username "admin" -Password (ConvertTo-SecureString "password" -AsPlainText -Force) -PVWAURL "https://pvwa.example.com"
```

### EXAMPLE 2
```
New-Session -Creds (Get-Credential) -PCloudURL "https://cloud.example.com" -IdentityURL "https://identity.example.com"
```

### EXAMPLE 3
```
New-Session -Username "admin" -Password (ConvertTo-SecureString "password" -AsPlainText -Force) -PVWAURL "https://pvwa.example.com" -OutputResults -UseResultFile
```

Creates a new session with success logging enabled, which will output successful operations to both console and a success file.

## PARAMETERS

### -Creds
Specifies the credentials stored as PSCredentials.
This parameter is used in the 'PVWAURL', 'PCloudSubdomain', and 'PCloudURL' parameter sets.

```yaml
Type: PSCredential
Parameter Sets: PCloudURL, PCloudSubdomain, PVWAURL
Aliases: PVWACreds, IdentityCreds

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IdentityURL
Specifies the URL for CyberArk Identity.
This parameter is used in the 'PCloudURL' and 'PCloudSubdomain' parameter sets.

```yaml
Type: String
Parameter Sets: PCloudURL, PCloudSubdomain, OAuthCreds
Aliases: IdentityTenantURL

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IncludeCallStack
{{ Fill IncludeCallStack Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogFile
Specifies the log file name.
The default value is ".\Log.Log".

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -OAuthCreds
Specifies the OAuth credentials stored as PSCredentials.
This parameter is used in the 'PCloudURL' and 'PCloudSubdomain' parameter sets.

```yaml
Type: PSCredential
Parameter Sets: OAuthCreds
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -OutputErrors
{{ Fill OutputErrors Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -OutputResults
Switch parameter that enables success output logging.
When specified, successful operations will be logged to the console and/or success file.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -Password
Specifies the password to connect with, stored as a SecureString.
This parameter is used in the 'PVWAURL', 'PCloudSubdomain', and 'PCloudURL' parameter sets.

```yaml
Type: SecureString
Parameter Sets: PCloudURL, PCloudSubdomain, PVWAURL
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PCloudSubdomain
Specifies the subdomain for the Privileged Cloud.
This parameter is mandatory in the 'PCloudSubdomain' parameter set.

```yaml
Type: String
Parameter Sets: PCloudSubdomain
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PCloudURL
Specifies the URL to the Privileged Cloud.
This parameter is mandatory in the 'PCloudURL' parameter set.

```yaml
Type: String
Parameter Sets: PCloudURL, OAuthCreds
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
Specifies the URL to the PVWA.
This parameter is mandatory in the 'PVWAURL' parameter set.

```yaml
Type: String
Parameter Sets: PVWAURL
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -UseErrorFile
Switch parameter that enables logging of error operations to a separate success file.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -UseResultFile
Switch parameter that enables logging of successful operations to a separate success file.
Works in conjunction with OutputResults to provide detailed success tracking.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -Username
Specifies the username to connect with as a string.
This parameter is used in the 'PVWAURL', 'PCloudSubdomain', and 'PCloudURL' parameter sets.

```yaml
Type: String
Parameter Sets: PCloudURL, PCloudSubdomain, PVWAURL
Aliases: IdentityUserName, PVWAUsername

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -UseVerboseFile
{{ Fill UseVerboseFile Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function sets default parameter values for subsequent commands in the session, including logon tokens and URLs.

## RELATED LINKS
