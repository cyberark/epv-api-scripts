---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# New-IdentityUser

## SYNOPSIS
Creates a new user in the Cloud Directory Service.

## SYNTAX

```
New-IdentityUser [-IdentityURL] <String> [[-LogonToken] <Object>] [-Name] <String> [-Mail] <String>
 [[-Password] <String>] [[-DisplayName] <String>] [[-Description] <String>] [[-MobileNumber] <String>]
 [[-OfficeNumber] <String>] [[-HomeNumber] <String>] [[-ForcePasswordChangeNext] <Boolean>]
 [[-SendEmailInvite] <Boolean>] [[-SendSmsInvite] <Boolean>] [[-InEverybodyRole] <Boolean>]
 [[-InSysAdminRole] <Boolean>] [[-ServiceUser] <Boolean>] [[-PasswordNeverExpire] <Boolean>]
 [[-ReportsTo] <String>] [[-PrimaryIdentifier] <String>] [[-OrgPath] <String>]
 [[-useAlternateMfaAccount] <Boolean>] [[-CmaRedirectedUserUuid] <String>] [-ProgressAction <ActionPreference>]
 [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The New-IdentityUser function creates a new user in the CyberArk Identity Cloud Directory Service.
Only system administrators or users with user management rights can invoke this function.

## EXAMPLES

### EXAMPLE 1
```
New-IdentityUser -IdentityURL "https://identity.example.com" -LogonToken $token -Name "jdoe" -Mail "jdoe@example.com"
```

### EXAMPLE 2
```
New-IdentityUser -IdentityURL "https://identity.example.com" -LogonToken $token -Name "jdoe" -Mail "jdoe@example.com" -DisplayName "John Doe" -InSysAdminRole
```

## PARAMETERS

### -CmaRedirectedUserUuid
Unique ID of the redirected user.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 22
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Description
Description of the user.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 7
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -DisplayName
Display name of the user.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ForcePasswordChangeNext
Force password change at first login.
Default is true.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 11
Default value: True
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -HomeNumber
User's home number.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 10
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -InEverybodyRole
Place user in Everybody role.
Default is true.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 14
Default value: True
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -InSysAdminRole
Place user in System Administrator role.
Default is false.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 15
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Mail
Email address of user.
This field is required if SendEmailInvite is true.

```yaml
Type: String
Parameter Sets: (All)
Aliases: Email

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -MobileNumber
User's mobile number.
This field is required if SendSmsInvite is true.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 8
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Name
Username of the user.
The username can be 'username@suffix' if suffix is required, else 'username'.

```yaml
Type: String
Parameter Sets: (All)
Aliases: Username, User

Required: True
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -OfficeNumber
User's office number.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 9
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -OrgPath
The organization name to which the user is added.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 20
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Password
Strong password of the user that meets the complexity requirements.
Password must be at least 8 characters long,
not be longer than 64 characters, contain at least one digit, contain at least one upper and one lower case letter.
If not provided, a randomly generated strong password will be used.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PasswordNeverExpire
User's password never expires.
Default is false.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 17
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PrimaryIdentifier
Identifier Type used while login.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 19
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ReportsTo
UUID of user this user reports to.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 18
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SendEmailInvite
Send user an email invite to login to the portal.
Default is true.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 12
Default value: True
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SendSmsInvite
Send user an SMS invite to enroll their mobile device in the portal.
Default is false.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 13
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ServiceUser
User is a service user.
Default is false.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 16
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -useAlternateMfaAccount
Does the user have an alternate MFA Account?

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 21
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Only system administrator or users with user management rights can invoke this function.
Specifying 'ServiceUser' will override the 'InEverybodyRole' property if both are provided.

## RELATED LINKS
