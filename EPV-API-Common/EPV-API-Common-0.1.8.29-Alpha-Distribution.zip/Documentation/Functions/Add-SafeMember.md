---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Add-SafeMember

## SYNOPSIS
Adds a member to a specified safe in the PVWA.

## SYNTAX

### memberName (Default)
```
Add-SafeMember [-PVWAURL <String>] [-LogonToken <Object>] -SafeName <String> -memberName <String>
 [-searchIn <String>] [-MemberType <String>] [-membershipExpirationDate <Int32>] [-useAccounts <Boolean>]
 [-retrieveAccounts <Boolean>] [-listAccounts <Boolean>] [-addAccounts <Boolean>]
 [-updateAccountContent <Boolean>] [-updateAccountProperties <Boolean>]
 [-initiateCPMAccountManagementOperations <Boolean>] [-specifyNextAccountContent <Boolean>]
 [-renameAccounts <Boolean>] [-deleteAccounts <Boolean>] [-unlockAccounts <Boolean>] [-manageSafe <Boolean>]
 [-manageSafeMembers <Boolean>] [-backupSafe <Boolean>] [-viewAuditLog <Boolean>] [-viewSafeMembers <Boolean>]
 [-accessWithoutConfirmation <Boolean>] [-createFolders <Boolean>] [-deleteFolders <Boolean>]
 [-moveAccountsAndFolders <Boolean>] [-requestsAuthorizationLevel1 <Boolean>]
 [-requestsAuthorizationLevel2 <Boolean>] [-permissions <SafePerms>] [-UpdateOnDuplicate]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### memberObject
```
Add-SafeMember [-PVWAURL <String>] [-LogonToken <Object>] -memberObject <String> [-UpdateOnDuplicate]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Add-SafeMember function adds a member to a specified safe in the PVWA with various permissions.
This function supports ShouldProcess for safety and confirmation prompts.

## EXAMPLES

### EXAMPLE 1
```
Add-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "Finance" -memberName "JohnDoe" -MemberType "User" -useAccounts $true
```

## PARAMETERS

### -accessWithoutConfirmation
Permission to access without confirmation.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -addAccounts
Permission to add accounts.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -backupSafe
Permission to backup the safe.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -createFolders
Permission to create folders.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -deleteAccounts
Permission to delete accounts.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -deleteFolders
Permission to delete folders.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -initiateCPMAccountManagementOperations
Permission to initiate CPM account management operations.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -listAccounts
Permission to list accounts.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -manageSafe
Permission to manage the safe.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -manageSafeMembers
Permission to manage safe members.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -memberName
The name of the member to be added to the safe.

```yaml
Type: String
Parameter Sets: memberName
Aliases: User

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -memberObject
{{ Fill memberObject Description }}

```yaml
Type: String
Parameter Sets: memberObject
Aliases: SafeMember

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -membershipExpirationDate
The expiration date of the membership.

```yaml
Type: Int32
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: 0
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -MemberType
The type of the member (User, Group, Role).

```yaml
Type: String
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -moveAccountsAndFolders
Permission to move accounts and folders.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -permissions
{{ Fill permissions Description }}

```yaml
Type: SafePerms
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -renameAccounts
Permission to rename accounts.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -requestsAuthorizationLevel1
Permission for requests authorization level 1.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -requestsAuthorizationLevel2
Permission for requests authorization level 2.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -retrieveAccounts
Permission to retrieve accounts.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SafeName
The name of the safe to which the member will be added.

```yaml
Type: String
Parameter Sets: memberName
Aliases: Safe

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -searchIn
The search scope for the member.

```yaml
Type: String
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -specifyNextAccountContent
Permission to specify next account content.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -unlockAccounts
Permission to unlock accounts.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -updateAccountContent
Permission to update account content.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -updateAccountProperties
Permission to update account properties.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -UpdateOnDuplicate
{{ Fill UpdateOnDuplicate Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -useAccounts
Permission to use accounts.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -viewAuditLog
Permission to view the audit log.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -viewSafeMembers
Permission to view safe members.

```yaml
Type: Boolean
Parameter Sets: memberName
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function requires the PVWA URL and a valid logon token for authentication.

## RELATED LINKS
