---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Connect-PTAUser

## SYNOPSIS
Logs on to PTA using username/password credentials.

## SYNTAX

```
Connect-PTAUser [[-CatchAll] <Object>] [-PTAURL] <String> [-Credential] <PSCredential>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Connect-PTAUser function authenticates to the CyberArk PTA REST API and returns
an authentication token.

## EXAMPLES

### EXAMPLE 1
```
$cred = Get-Credential
PS> $token = Connect-PTAUser -PTAURL "https://pta.example.com" -Credential $cred
```

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Credential
PSCredential containing the username and password.

```yaml
Type: PSCredential
Parameter Sets: (All)
Aliases:

Required: True
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PTAURL
The base URL of the PTA instance (e.g.
https://pta.example.com).

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: True
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### System.String
### Returns the authentication token string.
## NOTES

## RELATED LINKS
