---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-LiveSession

## SYNOPSIS
Retrieves live PSM sessions from the Vault.

## SYNTAX

### List (Default)
```
Get-LiveSession [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] [-Search <String>]
 [-Limit <Int32>] [-Offset <Int32>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Specific
```
Get-LiveSession [-CatchAll <Object>] [-PVWAURL <String>] [-LogonToken <Object>] -SessionID <String>
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-LiveSession function retrieves active PSM live sessions.
When called
without a SessionID it returns all live sessions with optional search
filtering.
When called with a SessionID it returns detailed information for
that specific session.

## EXAMPLES

### EXAMPLE 1
```
Get-LiveSession
```

Returns all active live sessions.

### EXAMPLE 2
```
Get-LiveSession -SessionID "abc-123"
```

Returns detailed information for session abc-123.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Limit
Maximum number of sessions to return.
Applies only when SessionID is not specified.

```yaml
Type: Int32
Parameter Sets: List
Aliases:

Required: False
Position: Named
Default value: 0
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Offset
Starting offset for pagination.
Applies only when SessionID is not specified.

```yaml
Type: Int32
Parameter Sets: List
Aliases:

Required: False
Position: Named
Default value: 0
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Search
Search text to filter the session list.
Applies only when SessionID is not specified.

```yaml
Type: String
Parameter Sets: List
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SessionID
The unique ID of the live session to retrieve.

```yaml
Type: String
Parameter Sets: Specific
Aliases: liveSessionId

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires the Auditors or Vault Admins group membership.

## RELATED LINKS
