---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-PVWAServerLogo

## SYNOPSIS
Retrieves the PVWA server logo image.

## SYNTAX

```
Get-PVWAServerLogo [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>] [[-Type] <String>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-PVWAServerLogo function retrieves the PVWA logo image.
The image type
can be either a square logo or a watermark.

## EXAMPLES

### EXAMPLE 1
```
Get-PVWAServerLogo -PVWAURL "https://pvwa.example.com" -LogonToken $token
```

Retrieves the square logo image.

### EXAMPLE 2
```
Get-PVWAServerLogo -PVWAURL "https://pvwa.example.com" -LogonToken $token -Type Watermark
```

Retrieves the watermark logo image.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA (Password Vault Web Access) API endpoint.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Type
The type of logo to retrieve.
Valid values: Square, Watermark.
Default: Square.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: Square
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function uses the legacy v1 PIMServices.svc endpoint.
Returns a binary image stream.

## RELATED LINKS
