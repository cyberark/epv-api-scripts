---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Remove-SensitiveData

## SYNOPSIS
Removes sensitive field values from a string before logging.

## SYNTAX

```
Remove-SensitiveData [-message] <String> [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
Scans a string for known sensitive field names (password, secret, token, Authorization,
Answer, access_token, etc.) and replaces their values with '****'.
Handles JSON,
escaped strings, and plain key=value formats.
Supports -WhatIf via ShouldProcess.

If the global variable $global:LogSensitiveData is set to $true, the original
string is returned unmodified to assist with debugging authentication issues.

## EXAMPLES

### EXAMPLE 1
```
Remove-SensitiveData -message '{"password":"MySecret123"}'
# Returns: '{"password":"****"}'
```

### EXAMPLE 2
```
Write-LogMessage -MSG (Remove-SensitiveData $body)
```

## PARAMETERS

### -message
The string to sanitize.
Aliases: MSG, value, string.

```yaml
Type: String
Parameter Sets: (All)
Aliases: MSG, value, string

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### String - The sanitized message with sensitive values replaced by '****'.
## NOTES
Used internally by Write-LogMessage.
Set $global:LogSensitiveData = $true to
temporarily disable scrubbing during authentication debugging.

## RELATED LINKS
