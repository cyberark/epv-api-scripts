---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# New-Connector

## SYNOPSIS
Retrieves a setup script for provisioning a new on-premise DPA connector.

## SYNTAX

```
New-Connector [[-CatchAll] <Object>] [[-SIAURL] <String>] [[-LogonToken] <Object>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
Calls the Secure Infrastructure Access (SIA) API to generate a Windows setup script
for a new on-premise connector.
The returned script can be used to install and register
the connector with the CyberArk DPA service.

## EXAMPLES

### EXAMPLE 1
```
New-Connector -SIAURL 'https://tenant.dpa.cyberark.cloud' -LogonToken $token
```

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The Bearer token or authorization header for authenticating to the SIA API.
Alias: header.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SIAURL
The base URL of the SIA (DPA) service.
Alias: url.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Requires ShouldProcess confirmation due to ConfirmImpact = High.
Use -Confirm:$false to suppress the confirmation prompt in automation.

## RELATED LINKS
