---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Remove-ApplicationAuthenticationMethod

## SYNOPSIS
Deletes a specific authentication method from a defined application.

## SYNTAX

```
Remove-ApplicationAuthenticationMethod [[-CatchAll] <Object>] [-Force] [[-PVWAURL] <String>]
 [[-LogonToken] <Object>] [-AppID] <String> [-AuthID] <Int32> [-ProgressAction <ActionPreference>] [-WhatIf]
 [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Remove-ApplicationAuthenticationMethod function deletes a specific authentication method from a defined application.
The user who runs this function requires Manage Users permissions in the Vault.

## EXAMPLES

### EXAMPLE 1
```
Remove-ApplicationAuthenticationMethod -PVWAURL "https://pvwa.example.com" -LogonToken $token -AppID "MyApp" -AuthID 1
```

Deletes authentication method with ID 1 from application "MyApp" (with confirmation prompt).

### EXAMPLE 2
```
Remove-ApplicationAuthenticationMethod -PVWAURL "https://pvwa.example.com" -LogonToken $token -AppID "MyApp" -AuthID 1 -Force
```

Deletes authentication method with ID 1 from application "MyApp" without confirmation.

### EXAMPLE 3
```
Get-ApplicationAuthenticationMethod -PVWAURL $pvwaurl -LogonToken $token -AppID "MyApp" | ForEach-Object { $_.authentication } | Where-Object { $_.AuthType -eq "machineAddress" } | Remove-ApplicationAuthenticationMethod -PVWAURL $pvwaurl -LogonToken $token -AppID "MyApp"
```

Removes all machineAddress authentication methods from "MyApp".

## PARAMETERS

### -AppID
The ID of the application from which the authentication method will be deleted.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AuthID
The unique ID of the specific authentication.
You can find the AuthID of the authentication
using the Get-ApplicationAuthenticationMethod function.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: True
Position: 5
Default value: 0
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Force
A switch to force the removal without confirmation.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA (Password Vault Web Access) API endpoint.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function uses the Invoke-Rest function to send a DELETE request to the PVWA API endpoint.
Requires Manage Users permissions in the Vault.

## RELATED LINKS
