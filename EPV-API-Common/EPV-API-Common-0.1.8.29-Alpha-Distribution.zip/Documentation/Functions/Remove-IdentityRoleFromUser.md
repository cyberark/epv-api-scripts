---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Remove-IdentityRoleFromUser

## SYNOPSIS
Removes a specified role from one or more users.

## SYNTAX

```
Remove-IdentityRoleFromUser [[-CatchAll] <Object>] [-Force] [-roleName] <String> [[-IdentityURL] <String>]
 [[-LogonToken] <Object>] [-User] <String[]> [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
The Remove-IdentityRoleFromUser function removes a specified role from one or more users in an identity management system.
It supports pipeline input and can be forced to bypass confirmation prompts.

## EXAMPLES

### EXAMPLE 1
```
Remove-IdentityRoleFromUser -roleName "Admin" -IdentityURL "https://identity.example.com" -LogonToken $token -User "user1"
```

Removes the "Admin" role from "user1".

### EXAMPLE 2
```
"user1", "user2" | Remove-IdentityRoleFromUser -roleName "Admin" -IdentityURL "https://identity.example.com" -LogonToken $token
```

Removes the "Admin" role from "user1" and "user2".

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Force
A switch to bypass confirmation prompts.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity management system.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The authentication token required to log on to the identity management system.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -roleName
The name of the role to be removed from the users.

```yaml
Type: String
Parameter Sets: (All)
Aliases: role

Required: True
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -User
An array of users from whom the role will be removed.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: Users

Required: True
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### System.String
### System.String[]
## OUTPUTS

### None
## NOTES
This function requires the Write-LogMessage and Get-IdentityRole functions to be defined in the session.

## RELATED LINKS
