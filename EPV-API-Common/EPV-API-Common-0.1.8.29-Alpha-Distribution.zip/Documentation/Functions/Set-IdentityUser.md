---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Set-IdentityUser

## SYNOPSIS
Updates an existing user in the Cloud Directory Service.

## SYNTAX

### ByID
```
Set-IdentityUser -IdentityURL <String> [-LogonToken <Object>] [-ID <String>] [-Mail <String>]
 [-DisplayName <String>] [-Description <String>] [-MobileNumber <String>] [-OfficeNumber <String>]
 [-HomeNumber <String>] [-ReportsTo <String>] [-PrimaryIdentifier <String>] [-OrgPath <String>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### ByName
```
Set-IdentityUser -IdentityURL <String> [-LogonToken <Object>] [-name <String>] [-Mail <String>]
 [-DisplayName <String>] [-Description <String>] [-MobileNumber <String>] [-OfficeNumber <String>]
 [-HomeNumber <String>] [-ReportsTo <String>] [-PrimaryIdentifier <String>] [-OrgPath <String>]
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Set-IdentityUser function updates an existing user's properties in the CyberArk Identity Cloud Directory Service.
Only system administrators or users with user management rights can invoke this function.

## EXAMPLES

### EXAMPLE 1
```
Set-IdentityUser -IdentityURL "https://identity.example.com" -LogonToken $token -ID "abc123" -DisplayName "John Doe"
```

### EXAMPLE 2
```
Set-IdentityUser -IdentityURL "https://identity.example.com" -LogonToken $token -ID "abc123" -Mail "newemail@example.com" -MobileNumber "+1234567890"
```

## PARAMETERS

### -Description
Description of the user.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -DisplayName
Display name of the user.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -HomeNumber
User's home number.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ID
The unique identifier (UUID) of the user to update.

```yaml
Type: String
Parameter Sets: ByID
Aliases: UUID, InternalName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Mail
Email address of user.

```yaml
Type: String
Parameter Sets: (All)
Aliases: Email

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -MobileNumber
User's mobile number.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -name
{{ Fill name Description }}

```yaml
Type: String
Parameter Sets: ByName
Aliases: user, username, member, UserPrincipalName, SamAccountName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -OfficeNumber
User's office number.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -OrgPath
The organisation name to which the user is added.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -PrimaryIdentifier
Identifier Type used while login.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ReportsTo
UUID of user this user reports to.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Only system administrator or users with user management rights can invoke this function.

## RELATED LINKS
