---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-OAuthInfo

## SYNOPSIS
Returns the current OAuth session information.

## SYNTAX

```
Get-OAuthInfo
```

## DESCRIPTION
Returns the OAuth info hashtable stored in the module session state.
Contains the Bearer token, OAuth credentials, Identity URL, PCloud URL,
and token expiry.
Used with Set-Session to restore an OAuth session.

## EXAMPLES

### EXAMPLE 1
```
$oauthInfo = Get-OAuthInfo
Set-Session -OAuthInfo $oauthInfo
```

## PARAMETERS

## INPUTS

## OUTPUTS

### Hashtable with keys: Bearer, OauthCreds, IdentityURL, PCloudURL, OauthExpiry.
## NOTES
Returns null if no OAuth session has been established via New-Session.

## RELATED LINKS
