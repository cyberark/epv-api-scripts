---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Add-IdentityRoleToGroup

## SYNOPSIS
Adds a specified identity role to one or more Groups.

## SYNTAX

```
Add-IdentityRoleToGroup [[-CatchAll] <Object>] [-RoleName] <String> [[-IdentityURL] <String>]
 [[-LogonToken] <Object>] [-Group] <String[]> [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
The Add-IdentityRoleToGroup function assigns a specified role to one or more Groups by making a REST API call to update the role.
It supports ShouldProcess for confirmation prompts and logs detailed messages about the operation.

## EXAMPLES

### EXAMPLE 1
```
Add-IdentityRoleToGroup -RoleName "Admin" -IdentityURL "https://identity.example.com" -LogonToken $token -Group "Group1"
```

Adds the "Admin" role to the Group "Group1".

### EXAMPLE 2
```
"Group1", "Group2" | Add-IdentityRoleToGroup -RoleName "Admin" -IdentityURL "https://identity.example.com" -LogonToken $token
```

Adds the "Admin" role to the Groups "Group1" and "Group2".

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Group
An array of Group identifiers to which the role will be added.
This parameter is mandatory and accepts pipeline input.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: Groups, Member

Required: True
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -IdentityURL
The base URL of the identity service.
This parameter is mandatory.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The authentication token required to log on to the identity service.
This parameter is mandatory.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -RoleName
The name of the role to be added to the Groups.
This parameter is mandatory and accepts pipeline input.

```yaml
Type: String
Parameter Sets: (All)
Aliases: role

Required: True
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function requires the Write-LogMessage and Invoke-Rest functions to be defined in the session.

## RELATED LINKS
