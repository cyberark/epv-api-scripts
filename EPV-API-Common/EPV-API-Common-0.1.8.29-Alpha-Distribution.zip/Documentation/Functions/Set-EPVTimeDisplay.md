---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Set-EPVTimeDisplay

## SYNOPSIS
Sets the time zone offset used when displaying timestamps in format views.

## SYNTAX

### Local (Default)
```
Set-EPVTimeDisplay [-Local] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### UTC
```
Set-EPVTimeDisplay [-UTC] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### Offset
```
Set-EPVTimeDisplay -UTCOffset <Double> [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
Controls how date/time values are displayed across EPV-API-Common format views
(Account, Safe, Comp, User).
By default, timestamps are converted to local time.
Use -UTC to display UTC, or -UTCOffset to specify any numeric offset from UTC.

Sets $global:EPVTimeOffset which is read by the module's ps1xml format files.
A value of $null displays local time, 0 displays UTC, and any numeric value
displays that offset from UTC (e.g.
-6 for UTC-6, 5.5 for UTC+5:30).

## EXAMPLES

### EXAMPLE 1
```
Set-EPVTimeDisplay
# Resets to local time (default).
```

### EXAMPLE 2
```
Set-EPVTimeDisplay -UTC
# Displays all timestamps in UTC.
```

### EXAMPLE 3
```
Set-EPVTimeDisplay -UTCOffset -6
# Displays all timestamps at UTC-6.
```

### EXAMPLE 4
```
Set-EPVTimeDisplay -UTCOffset 5.5
# Displays all timestamps at UTC+5:30.
```

## PARAMETERS

### -Local
Resets to local time display.
This is the default parameter set.

```yaml
Type: SwitchParameter
Parameter Sets: Local
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -UTC
Displays timestamps in UTC (offset 0).

```yaml
Type: SwitchParameter
Parameter Sets: UTC
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -UTCOffset
Displays timestamps at the specified offset from UTC.
Accepts values from -14 to +14 and supports fractional hours (e.g.
5.5 for UTC+5:30).

```yaml
Type: Double
Parameter Sets: Offset
Aliases:

Required: True
Position: Named
Default value: 0
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This setting persists for the duration of the PowerShell session.
To reset to local time, call Set-EPVTimeDisplay with no parameters or with -Local.

## RELATED LINKS
