---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Connect-SAMLUser

## SYNOPSIS
Logs on to the Vault using SAML authentication.

## SYNTAX

```
Connect-SAMLUser [[-CatchAll] <Object>] [-PVWAURL] <String> [-SAMLResponse] <String> [-ConcurrentSession]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Connect-SAMLUser function authenticates to the CyberArk PAM REST API using
SAML single sign-on and returns a logon token.
This is a two-step process:
first obtain the SAML response from your identity provider, then exchange it
for a Vault token using this function.

## EXAMPLES

### EXAMPLE 1
```
$token = Connect-SAMLUser -PVWAURL "https://pvwa.example.com" -SAMLResponse $samlBase64
```

Logs on using SAML authentication with a pre-obtained SAML response.

## PARAMETERS

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ConcurrentSession
When specified, allows multiple concurrent sessions for the same user.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The base URL of the PVWA instance (e.g.
https://pvwa.example.com).

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: True
Position: 2
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SAMLResponse
The base64-encoded SAML response from the identity provider.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 3
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

### System.String
### Returns the logon token string.
## NOTES
The SAML response must be obtained from the identity provider first.
The PVWA must be configured for SAML authentication.

## RELATED LINKS
