---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Test-IdentityUserCloudLock

## SYNOPSIS
Tests if an Identity user is cloud locked.

## SYNTAX

### ByID
```
Test-IdentityUserCloudLock -IdentityURL <String> [-LogonToken <Object>] [-ID <String>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### ByName
```
Test-IdentityUserCloudLock -IdentityURL <String> [-LogonToken <Object>] [-name <String>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Test-IdentityUserCloudLock function checks to see if a given user is cloud locked in the CyberArk Identity service.

## EXAMPLES

### EXAMPLE 1
```
Test-IdentityUserCloudLock -IdentityURL "https://identity.example.com" -LogonToken $token -ID "abc123"
```

## PARAMETERS

### -ID
The unique identifier (UUID) of the user.

```yaml
Type: String
Parameter Sets: ByID
Aliases: UUID, InternalName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -name
{{ Fill name Description }}

```yaml
Type: String
Parameter Sets: ByName
Aliases: user, username, member, UserPrincipalName, SamAccountName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Returns true if the user is cloud locked, false otherwise.

## RELATED LINKS
