---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Set-IdentityUserCloudLock

## SYNOPSIS
Sets or clears a cloud lock for a specified Identity user.

## SYNTAX

### ByID
```
Set-IdentityUserCloudLock -IdentityURL <String> [-LogonToken <Object>] [-ID <String>] -Locked <Boolean>
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

### ByName
```
Set-IdentityUserCloudLock -IdentityURL <String> [-LogonToken <Object>] [-name <String>] -Locked <Boolean>
 [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
The Set-IdentityUserCloudLock function applies or clears a cloud lock for a given user in the CyberArk Identity service.
Only system administrators can invoke this function.

## EXAMPLES

### EXAMPLE 1
```
Set-IdentityUserCloudLock -IdentityURL "https://identity.example.com" -LogonToken $token -ID "abc123" -Locked $true
```

### EXAMPLE 2
```
Set-IdentityUserCloudLock -IdentityURL "https://identity.example.com" -LogonToken $token -ID "abc123" -Locked $false
```

## PARAMETERS

### -ID
The unique identifier (UUID) of the user.

```yaml
Type: String
Parameter Sets: ByID
Aliases: UUID, InternalName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IdentityURL
The URL of the identity service.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Locked
Boolean value indicating whether to lock (true) or unlock (false) the user.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: True
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token for authentication.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -name
{{ Fill name Description }}

```yaml
Type: String
Parameter Sets: ByName
Aliases: user, username, member, UserPrincipalName, SamAccountName

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Only system administrators can invoke this function.

## RELATED LINKS
