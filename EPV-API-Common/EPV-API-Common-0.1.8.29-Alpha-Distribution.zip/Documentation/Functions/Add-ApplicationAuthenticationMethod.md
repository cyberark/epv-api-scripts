---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Add-ApplicationAuthenticationMethod

## SYNOPSIS
Adds a new authentication method to a specific application in the Vault.

## SYNTAX

```
Add-ApplicationAuthenticationMethod [[-CatchAll] <Object>] [[-PVWAURL] <String>] [[-LogonToken] <Object>]
 [-AppID] <String> [-AuthType] <String> [[-AuthValue] <String>] [[-IsFolder] <Boolean>]
 [[-AllowInternalScripts] <Boolean>] [[-Comment] <String>] [[-Subject] <String[]>] [[-Issuer] <String[]>]
 [[-SubjectAlternativeName] <String[]>] [-ProgressAction <ActionPreference>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
The Add-ApplicationAuthenticationMethod function adds a new authentication method to a specific application.
The user who adds this authentication method requires Manage Users permissions in the Vault.

Supported authentication types:
- path: Path authentication with optional folder and script settings
- hash: Hash authentication
- osUser: OS user authentication
- machineAddress: Address authentication (allowed machines) - supports IP subnet in CIDR IPv4 and IPv6 format
- certificateserialnumber: Certificate Serial Number authentication
- certificateattr: Certificate Attributes authentication

## EXAMPLES

### EXAMPLE 1
```
Add-ApplicationAuthenticationMethod -PVWAURL "https://pvwa.example.com" -LogonToken $token -AppID "MyApp" -AuthType "machineAddress" -AuthValue "192.168.1.100"
```

Adds a machine address authentication for IP 192.168.1.100 to the application "MyApp".

### EXAMPLE 2
```
Add-ApplicationAuthenticationMethod -PVWAURL "https://pvwa.example.com" -LogonToken $token -AppID "MyApp" -AuthType "osUser" -AuthValue "DOMAIN\user"
```

Adds an OS user authentication to the application "MyApp".

### EXAMPLE 3
```
Add-ApplicationAuthenticationMethod -PVWAURL "https://pvwa.example.com" -LogonToken $token -AppID "MyApp" -AuthType "path" -AuthValue "C:\Apps\MyApp.exe" -IsFolder $false -AllowInternalScripts $true
```

Adds a path authentication with script execution allowed.

### EXAMPLE 4
```
Add-ApplicationAuthenticationMethod -PVWAURL "https://pvwa.example.com" -LogonToken $token -AppID "MyApp" -AuthType "certificateattr" -Subject @("CN=yourcompany.com", "OU=IT") -Issuer @("CN=Thawte RSA CA 2018") -SubjectAlternativeName @("DNS Name=www.example.com")
```

Adds certificate attributes authentication.

## PARAMETERS

### -AllowInternalScripts
Relevant for Path authentication only.
Allows internal scripts to run.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 8
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AppID
The name of the application for which the user is adding a new authentication method.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AuthType
The type of authentication.
Valid values: path, hash, osUser, machineAddress, certificateserialnumber, certificateattr

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 5
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -AuthValue
The content of the authentication.
Mandatory for most authentication types.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Comment
A comment about this authentication method.
Relevant for Hash and Certificate Serial Number authentication.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 9
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -IsFolder
Relevant for Path authentication only.
Indicates if the path is a folder.

```yaml
Type: Boolean
Parameter Sets: (All)
Aliases:

Required: False
Position: 7
Default value: False
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Issuer
For Certificate Attributes authentication.
Array of issuer attributes (e.g., "CN=Thawte RSA CA 2018").

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 11
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -LogonToken
The logon token used for authentication with the PVWA API.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA (Password Vault Web Access) API endpoint.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Subject
For Certificate Attributes authentication.
Array of subject attributes (e.g., "CN=yourcompany.com", "OU=IT").

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 10
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SubjectAlternativeName
For Certificate Attributes authentication.
Array of subject alternative name attributes (e.g., "DNS Name=www.example.com", "IP Address=1.2.3.4").

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 12
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
The function uses the Invoke-Rest function to send a POST request to the PVWA API endpoint.
Requires Manage Users permissions in the Vault.

## RELATED LINKS
