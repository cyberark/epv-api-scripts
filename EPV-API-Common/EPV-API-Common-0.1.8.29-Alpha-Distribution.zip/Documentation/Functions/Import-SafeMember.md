---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Import-SafeMember

## SYNOPSIS
Imports safe member information from a CSV file.

## SYNTAX

```
Import-SafeMember [[-CSVPath] <String>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Import-SafeMember function reads safe member information from a specified CSV file and outputs SafeMember objects.

## EXAMPLES

### EXAMPLE 1
```
Import-SafeMember -CSVPath "C:\Exports\SafeMembers.csv"
```

## PARAMETERS

### -CSVPath
Specifies the path to the CSV file to import.
Defaults to ".\SafeMemberExport.csv".

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: .\SafeMemberExport.csv
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
Adjust property mapping as needed to match your SafeMember class.

## RELATED LINKS
