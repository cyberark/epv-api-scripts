---
external help file: EPV-API-Common-help.xml
Module Name: EPV-API-Common
online version:
schema: 2.0.0
---

# Get-Account

## SYNOPSIS
Retrieves account information from the PVWA API.

## SYNTAX

### Filter (Default)
```
Get-Account [-Filter <String>] [-Offset <String>] [-Limit <String>] [-DoNotPage]
 [-Sort <AllowEmptyStringAttribute>] [-PVWAURL <String>] [-LogonToken <Object>] [-CatchAll <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### AccountID
```
Get-Account [-AccountID <String>] [-AccountLink] [-AccountLinkObject] [-PVWAURL <String>]
 [-LogonToken <Object>] [-CatchAll <Object>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### AllAccounts
```
Get-Account [-AllAccounts] [-Offset <String>] [-Limit <String>] [-DoNotPage]
 [-Sort <AllowEmptyStringAttribute>] [-PVWAURL <String>] [-LogonToken <Object>] [-CatchAll <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### Search
```
Get-Account [-Search <String>] [-SearchType <String>] [-Filter <String>] [-Offset <String>] [-Limit <String>]
 [-DoNotPage] [-Sort <AllowEmptyStringAttribute>] [-PVWAURL <String>] [-LogonToken <Object>]
 [-CatchAll <Object>] [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

### savedfilter
```
Get-Account [-SavedFilter <String>] [-Offset <String>] [-Limit <String>] [-DoNotPage]
 [-Sort <AllowEmptyStringAttribute>] [-PVWAURL <String>] [-LogonToken <Object>] [-CatchAll <Object>]
 [-ProgressAction <ActionPreference>] [<CommonParameters>]
```

## DESCRIPTION
The Get-Account function retrieves account information from the PVWA API based on various parameters such as AccountID, Search, Filter, and SavedFilter.
It supports multiple parameter sets to allow for flexible querying.

## EXAMPLES

### EXAMPLE 1
```
Get-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12345"
```

### EXAMPLE 2
```
Get-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -Search "admin" -SearchType "contains"
```

## PARAMETERS

### -AccountID
The ID of the account to retrieve.

```yaml
Type: String
Parameter Sets: AccountID
Aliases: id

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -AccountLink
Switch to include account links in the response.

```yaml
Type: SwitchParameter
Parameter Sets: AccountID
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -AccountLinkObject
Switch to include account link objects in the response.

```yaml
Type: SwitchParameter
Parameter Sets: AccountID
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: True (ByPropertyName, ByValue)
Accept wildcard characters: False
```

### -AllAccounts
Switch to retrieve all accounts.

```yaml
Type: SwitchParameter
Parameter Sets: AllAccounts
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -CatchAll
{{ Fill CatchAll Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DoNotPage
Switch to disable pagination.

```yaml
Type: SwitchParameter
Parameter Sets: Filter, AllAccounts, Search, savedfilter
Aliases:

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -Filter
Filter to apply to the account query.

```yaml
Type: String
Parameter Sets: Filter
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

```yaml
Type: String
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Limit
Limit for pagination.

```yaml
Type: String
Parameter Sets: Filter, AllAccounts, Search, savedfilter
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LogonToken
The authentication token used for API requests.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: header

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Offset
Offset for pagination.

```yaml
Type: String
Parameter Sets: Filter, AllAccounts, Search, savedfilter
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ProgressAction
{{ Fill ProgressAction Description }}

```yaml
Type: ActionPreference
Parameter Sets: (All)
Aliases: proga

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PVWAURL
The URL of the PVWA instance.

```yaml
Type: String
Parameter Sets: (All)
Aliases: url, PCloudURL

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SavedFilter
Predefined filter to apply to the account query.
Valid values are:
- Regular
- Recently
- New
- Link
- Deleted
- PolicyFailures
- AccessedByUsers
- ModifiedByUsers
- ModifiedByCPM
- DisabledPasswordByUser
- DisabledPasswordByCPM
- ScheduledForChange
- ScheduledForVerify
- ScheduledForReconcile
- SuccessfullyReconciled
- FailedChange
- FailedVerify
- FailedReconcile
- LockedOrNew
- Locked

```yaml
Type: String
Parameter Sets: savedfilter
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Search
Search term to filter accounts.

```yaml
Type: String
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -SearchType
Type of search to perform.

```yaml
Type: String
Parameter Sets: Search
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: True (ByPropertyName)
Accept wildcard characters: False
```

### -Sort
Sort order for the results.
Valid values are "asc" and "desc".

```yaml
Type: AllowEmptyStringAttribute
Parameter Sets: Filter, AllAccounts, Search, savedfilter
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES
This function requires the PVWA URL and a valid logon token to authenticate API requests.

## RELATED LINKS
