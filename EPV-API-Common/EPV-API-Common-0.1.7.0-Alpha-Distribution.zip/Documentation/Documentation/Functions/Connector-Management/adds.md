# adds

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -CMURL
The URL of the CyberArk Connector Management service in the format https://<subdomain>.connectormanagement.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -PoolId
The unique identifier of the pool to add the identifier to (mandatory).

### -Type
The type of the identifier (mandatory).

### -Value
The value of the identifier (mandatory).

### -AdditionalProperties
Additional properties to include in the identifier request body (optional).

## Examples

### Example 1
```powershell
Add-ConnectorPoolIdentifier -CMURL "https://subdomain.connectormanagement.cyberark.cloud/api/pool-service" -LogonToken $token -PoolId "12345678-1234-1234-1234-123456789012" -Type "IP" -Value "192.168.1.100"
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\ConnectorManagement\Add-ConnectorPoolIdentifier.ps1*
