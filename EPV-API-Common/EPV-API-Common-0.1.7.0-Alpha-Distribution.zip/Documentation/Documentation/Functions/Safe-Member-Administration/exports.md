# exports

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -CSVPath
Specifies the path to the CSV file where the safe member information will be exported.
Defaults to ".\SafeMemberExport.csv".

### -Force
If specified, forces the overwrite of the CSV file if it already exists.

### -SafeMember
Specifies the safe member object to be exported. This parameter is mandatory and accepts input from the pipeline.

### -includeSystemSafes
If specified, includes system safes in the export. This parameter is hidden from the help documentation.

### -CPMUser
Specifies an array of CPM user names. This parameter is hidden from the help documentation.

## Examples

### Example 1
```powershell
Export-SafeMember -CSVPath "C:\Exports\SafeMembers.csv" -SafeMember $safeMember

This example exports the safe member information to "C:\Exports\SafeMembers.csv".
```

### Example 2
```powershell
$safeMembers | Export-SafeMember -CSVPath "C:\Exports\SafeMembers.csv" -Force

This example exports the safe member information from the pipeline to "C:\Exports\SafeMembers.csv",
forcing the overwrite of the file if it already exists.
```

## Notes
The function logs verbose messages about its operations and handles errors gracefully.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\SafeMember\Import-Export\Export-SafeMember.ps1*
