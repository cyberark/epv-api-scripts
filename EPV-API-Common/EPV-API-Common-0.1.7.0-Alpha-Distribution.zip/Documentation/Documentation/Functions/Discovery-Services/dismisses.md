# dismisses

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -DiscoveryURL
The URL of the CyberArk Discovery Management service in the format https://<subdomain>.discoverymgmt.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -RecommendationID
The discovery rule set recommendation ID to dismiss.

## Examples

### Example 1
```powershell
Deny-DiscoveryRuleSetRecommendation -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -RecommendationID "12345"
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Discovery\Deny-DiscoveryRuleSetRecommendation.ps1*
