# creates

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -DiscoveryURL
The URL of the CyberArk Discovery Management service in the format https://<subdomain>.discoverymgmt.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -ScanDefinitionID
The unique identifier of the scan definition to create the scan instance from (mandatory).

### -AdditionalProperties
Additional properties to include in the scan instance request body (optional).

## Examples

### Example 1
```powershell
Start-Scan -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -ScanDefinitionID "9d963737-b704-4c63-bba9-17d8236691f6"
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\DiscoveryManagement\Start-Scan.ps1*
