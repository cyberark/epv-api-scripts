<#
.SYNOPSIS
    Installs the EPV-API-Common PowerShell module to the system or user module path.

.DESCRIPTION
    This script installs the EPV-API-Common module from the distribution package.
    By default, it installs to the system-wide PowerShell module path (requires administrator privileges).
    Use the -UserScope parameter to install to the current user's module path instead.

.PARAMETER UserScope
    Install the module to the current user's module path instead of the system path.
    This does not require administrator privileges.

.PARAMETER Force
    Force the installation even if the module already exists. This will overwrite existing files.

.PARAMETER Verbose
    Show detailed installation progress.

.EXAMPLE
    .\Install-Module.ps1

    Installs the module to the system module path (requires administrator privileges).

.EXAMPLE
    .\Install-Module.ps1 -UserScope

    Installs the module to the current user's module path.

.EXAMPLE
    .\Install-Module.ps1 -UserScope -Force

    Forces installation to the user's module path, overwriting any existing version.

.NOTES
    This script should be run from the distribution directory containing the EPV-API-Common module folder.
#>

param(
    [switch]$UserScope,
    [switch]$Force,
    [switch]$Verbose
)

$ErrorActionPreference = 'Stop'

# Set verbose preference if requested
if ($Verbose) {
    $VerbosePreference = 'Continue'
}

# Module information
$ModuleName = 'EPV-API-Common'
$ScriptDirectory = Split-Path $MyInvocation.MyCommand.Path -Parent
$ModuleSourcePath = Join-Path $ScriptDirectory $ModuleName

Write-Host "EPV-API-Common Module Installation Script" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green

# Verify module source exists
if (-not (Test-Path $ModuleSourcePath)) {
    Write-Error "[ERROR] Module source directory not found: $ModuleSourcePath"
    Write-Host "Please ensure this script is run from the distribution directory containing the $ModuleName folder." -ForegroundColor Red
    exit 1
}

# Get module version from manifest
$ManifestPath = Join-Path $ModuleSourcePath "$ModuleName.psd1"
if (Test-Path $ManifestPath) {
    try {
        $ModuleInfo = Import-PowerShellDataFile $ManifestPath
        $ModuleVersion = $ModuleInfo.ModuleVersion
        $Prerelease = $ModuleInfo.PrivateData.PSData.Prerelease
        $FullVersion = if ($Prerelease) { "$ModuleVersion-$Prerelease" } else { $ModuleVersion }
        Write-Host "Module Version: $FullVersion" -ForegroundColor Cyan
    }
    catch {
        Write-Warning "[WARNING] Could not read module manifest: $($_.Exception.Message)"
        $FullVersion = "Unknown"
    }
}
else {
    Write-Warning "[WARNING] Module manifest not found at: $ManifestPath"
    $FullVersion = "Unknown"
}

# Determine installation path
if ($UserScope) {
    # Detect PowerShell version to use correct module path
    if ($PSVersionTable.PSVersion.Major -ge 6) {
        $ModulesPath = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'PowerShell\Modules'
    }
    else {
        # PowerShell 5.1 and earlier use WindowsPowerShell
        $ModulesPath = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'WindowsPowerShell\Modules'
    }
    $InstallScope = "User"
    Write-Host "Installation Scope: Current User" -ForegroundColor Cyan
}
else {
    # Detect PowerShell version to use correct module path
    if ($PSVersionTable.PSVersion.Major -ge 6) {
        $ModulesPath = Join-Path $env:ProgramFiles 'PowerShell\Modules'
    }
    else {
        # PowerShell 5.1 and earlier use WindowsPowerShell
        $ModulesPath = Join-Path $env:ProgramFiles 'WindowsPowerShell\Modules'
    }
    $InstallScope = "System"
    Write-Host "Installation Scope: System (All Users)" -ForegroundColor Cyan
}

$DestinationPath = Join-Path $ModulesPath $ModuleName
Write-Host "Installation Path: $DestinationPath" -ForegroundColor Cyan
Write-Host ""

# Check if running as administrator (for system installation)
function Test-Administrator {
    if ($PSVersionTable.PSVersion.Major -ge 6) {
        # PowerShell Core/7+
        # Check if $IsWindows variable exists (only in PS Core)
        $isWindowsOS = if (Get-Variable -Name 'IsWindows' -ErrorAction SilentlyContinue) { 
            $IsWindows 
        } else { 
            $true  # Assume Windows if variable doesn't exist
        }
        
        if ($isWindowsOS) {
            $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
            return $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        }
        else {
            # On non-Windows systems, check if running as root
            return (id -u) -eq 0
        }
    }
    else {
        # Windows PowerShell (5.1 and earlier)
        $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
        return $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
}

# Warn if system installation without admin privileges
if (-not $UserScope -and -not (Test-Administrator)) {
    Write-Warning "[WARNING] System installation typically requires administrator privileges."
    Write-Host "Consider running as administrator or use -UserScope parameter for user installation." -ForegroundColor Yellow
    Write-Host ""

    # Ask user if they want to continue
    $continue = Read-Host "Continue with system installation? (y/N)"
    if ($continue -notmatch '^[Yy]') {
        Write-Host "Installation cancelled. Use -UserScope for user installation." -ForegroundColor Yellow
        exit 0
    }
}

# Check if module already exists
if (Test-Path $DestinationPath) {
    if ($Force) {
        Write-Host "[WARNING] Existing module found. Force flag specified - will overwrite." -ForegroundColor Yellow
        try {
            Write-Verbose "Removing existing module at: $DestinationPath"
            Remove-Item $DestinationPath -Recurse -Force
            Write-Host "[SUCCESS] Removed existing module" -ForegroundColor Green
        }
        catch {
            Write-Error "[ERROR] Failed to remove existing module: $($_.Exception.Message)"
            exit 1
        }
    }
    else {
        Write-Warning "[WARNING] Module already exists at: $DestinationPath"
        Write-Host "Use -Force parameter to overwrite, or -UserScope to install to user path." -ForegroundColor Yellow

        # Check if it's the same version
        $ExistingManifest = Join-Path $DestinationPath "$ModuleName.psd1"
        if (Test-Path $ExistingManifest) {
            try {
                $ExistingInfo = Import-PowerShellDataFile $ExistingManifest
                $ExistingVersion = $ExistingInfo.ModuleVersion
                $ExistingPrerelease = $ExistingInfo.PrivateData.PSData.Prerelease
                $ExistingFullVersion = if ($ExistingPrerelease) { "$ExistingVersion-$ExistingPrerelease" } else { $ExistingVersion }
                Write-Host "Existing Version: $ExistingFullVersion" -ForegroundColor Cyan
                Write-Host "New Version: $FullVersion" -ForegroundColor Cyan
            }
            catch {
                Write-Verbose "Could not read existing module version"
            }
        }

        exit 1
    }
}

# Create destination directory if it doesn't exist
try {
    if (-not (Test-Path $ModulesPath)) {
        Write-Verbose "Creating modules directory: $ModulesPath"
        New-Item $ModulesPath -ItemType Directory -Force | Out-Null
    }

    Write-Host "Installing module..." -ForegroundColor Yellow
    Write-Verbose "Copying from: $ModuleSourcePath"
    Write-Verbose "Copying to: $DestinationPath"

    Copy-Item $ModuleSourcePath -Destination $DestinationPath -Recurse -Force
    Write-Host "[SUCCESS] Module installed successfully" -ForegroundColor Green
}
catch {
    Write-Error "[ERROR] Failed to install module: $($_.Exception.Message)"

    if (-not $UserScope -and $_.Exception.Message -match "Access.*denied|UnauthorizedAccessException") {
        Write-Host ""
        Write-Host "Suggestions:" -ForegroundColor Yellow
        Write-Host "  1. Run this script as Administrator for system installation" -ForegroundColor White
        Write-Host "  2. Use -UserScope parameter for user installation (no admin required)" -ForegroundColor White
        Write-Host "     Example: .\Install-Module.ps1 -UserScope" -ForegroundColor Gray
    }

    exit 1
}

# Verify installation
Write-Host ""
Write-Host "Verifying installation..." -ForegroundColor Yellow

try {
    # Import the module to verify it works
    Import-Module $DestinationPath -Force -PassThru | Out-Null

    # Get module information
    $InstalledModule = Get-Module $ModuleName -ListAvailable | Where-Object { $_.Path -like "$DestinationPath*" } | Select-Object -First 1

    if ($InstalledModule) {
        Write-Host "[SUCCESS] Module verified successfully" -ForegroundColor Green
        Write-Host ""
        Write-Host "Installation Summary:" -ForegroundColor Cyan
        Write-Host "  Module: $($InstalledModule.Name)" -ForegroundColor White
        Write-Host "  Version: $($InstalledModule.Version)" -ForegroundColor White
        Write-Host "  Path: $($InstalledModule.ModuleBase)" -ForegroundColor White
        Write-Host "  Scope: $InstallScope" -ForegroundColor White

        # Show available commands
        $Commands = Get-Command -Module $ModuleName | Measure-Object
        Write-Host "  Commands: $($Commands.Count)" -ForegroundColor White
    }
    else {
        Write-Warning "[WARNING] Module installed but not found in Get-Module output"
    }
}
catch {
    Write-Warning "[WARNING] Module installed but verification failed: $($_.Exception.Message)"
    Write-Host "The module files were copied successfully, but there may be an issue with the module itself." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Installation completed!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Import the module: Import-Module $ModuleName" -ForegroundColor White
Write-Host "  2. List commands: Get-Command -Module $ModuleName" -ForegroundColor White
Write-Host "  3. Get help: Get-Help <CommandName> -Detailed" -ForegroundColor White

exit 0
