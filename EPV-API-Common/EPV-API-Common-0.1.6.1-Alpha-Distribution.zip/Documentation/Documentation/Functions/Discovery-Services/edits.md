# edits

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -DiscoveryURL
The URL of the CyberArk Discovery Management service in the format https://<subdomain>.discoverymgmt.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -RuleSetID
The discovery rule set ID to edit.

### -InputObject
The discovery rule set data to update. This should be a hashtable or PSCustomObject containing the updated rule set information.

## Examples

### Example 1
```powershell
$updatedRuleSetData = @{
    name = "Updated Windows Discovery Rules"
    status = "DRAFT"
    rules = @(
        @{
            name = "Onboard Admin Accounts"
            action = @{
                type = "ONBOARD"
                parameters = @{
                    safeName = "UpdatedDiscoveredAccounts"
                    platformId = "WinDomain"
                }
            }
        }
    )
}
Set-DiscoveryRuleSet -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -RuleSetID "12345" -InputObject $updatedRuleSetData
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Discovery\Set-DiscoveryRuleSet.ps1*
