# retrieves

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -DiscoveryURL
The URL of the CyberArk Discovery Management service in the format https://<subdomain>.discoverymgmt.cyberark.cloud

### -LogonToken
The authentication token used for API requests.

### -ScanDefinitionID
The unique identifier of the scan definition to retrieve (for single scan definition mode).

### -Search
Searches in all identifiers values of the scan definition for the given string.

### -Offset
Offset of the first scan definition that is returned in the collection of results (default: 0).

### -Limit
The maximum number of scan definitions to return (default: 50).

### -Sort
Sorting parameter for the results.

### -Filter
Filter parameter for the results.

## Examples

### Example 1
```powershell
Get-ScanDefinition -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token
```

### Example 2
```powershell
Get-ScanDefinition -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -ScanDefinitionID "9d963737-b704-4c63-bba9-17d8236691f6"
```

### Example 3
```powershell
Get-ScanDefinition -DiscoveryURL "https://subdomain.discoverymgmt.cyberark.cloud" -LogonToken $token -Search "windows" -Limit 25
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\DiscoveryManagement\Get-ScanDefinition.ps1*
