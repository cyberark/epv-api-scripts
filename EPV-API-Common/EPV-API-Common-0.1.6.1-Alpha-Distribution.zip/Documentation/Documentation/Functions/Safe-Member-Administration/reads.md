# reads

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -CSVPath
Specifies the path to the CSV file to import. Defaults to ".\SafeMemberExport.csv".

## Examples

### Example 1
```powershell
Import-SafeMember -CSVPath "C:\Exports\SafeMembers.csv"
```

## Notes
Adjust property mapping as needed to match your SafeMember class.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\SafeMember\Import-Export\Import-SafeMember.ps1*
