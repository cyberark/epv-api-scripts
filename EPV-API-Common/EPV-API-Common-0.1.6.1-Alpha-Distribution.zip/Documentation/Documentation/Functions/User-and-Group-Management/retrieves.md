# retrieves

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -IdentityURL
The URL of the identity service.

### -LogonToken
The logon token used for authentication.

### -roleName
The name of the role to retrieve. This parameter is mandatory when using the "RoleName" parameter set.

### -IDOnly
A switch to indicate if only the role ID should be returned.

### -AllRoles
A switch to indicate if all roles should be retrieved. This parameter is mandatory when using the "AllRoles" parameter set.

## Examples

### Example 1
```powershell
Get-IdentityRole -IdentityURL "https://identity.example.com" -LogonToken $token -roleName "Admin"
Retrieves the role information for the role named "Admin".
```

### Example 2
```powershell
Get-IdentityRole -IdentityURL "https://identity.example.com" -LogonToken $token -AllRoles
Retrieves all roles from the identity service.
```

## Notes
The function uses REST API calls to interact with the identity service.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Identity\Role\Get-IdentityRole.ps1*
