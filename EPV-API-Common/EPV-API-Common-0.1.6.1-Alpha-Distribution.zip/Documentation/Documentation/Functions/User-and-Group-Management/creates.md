# creates

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -IdentityURL
The URL of the identity service where the role will be created.

### -LogonToken
The logon token used for authentication.

### -roleName
The name of the role to be created.

### -Description
A description of the role.

### -RoleType
The type of the role. Valid values are 'PrincipalList', 'Script', and 'Everybody'. Default is 'PrincipalList'.

### -Users
An array of users to be added to the role.

### -Roles
An array of roles to be added to the role.

### -Groups
An array of groups to be added to the role.

## Examples

### Example 1
```powershell
PS> New-IdentityRole -IdentityURL "https://identity.example.com" -LogonToken $token -roleName "Admin" -Description "Administrator role" -RoleType "PrincipalList" -Users "user1", "user2"

Creates a new role named "Admin" with the specified users.
```

## Notes
The function supports ShouldProcess for safety and confirmation prompts.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Identity\Role\New-IdentityRole.ps1*
