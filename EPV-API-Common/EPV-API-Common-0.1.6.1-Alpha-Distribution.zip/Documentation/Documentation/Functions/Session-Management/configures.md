# configures

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -Token
The authentication token to use for API requests. This parameter is mandatory.

### -PVWAURL
The URL of the PVWA instance. Used in the 'PVWAURL' parameter set.

### -PCloudURL
The URL of the Privileged Cloud instance. Used in the 'PCloudURL' parameter set.

### -LogFile
The path to the log file. If not specified, a default log file will be created.

### -OutputResults
Switch to enable output of results to console.

### -OutputErrors
Switch to enable output of errors to console.

### -UseResultFile
Switch to enable writing results to a separate result file.

### -UseErrorFile
Switch to enable writing errors to a separate error file.

### -UseVerboseFile
Switch to enable writing verbose messages to a separate verbose file. This parameter is hidden from help.

### -IncludeCallStack
Switch to include call stack information in logs. This parameter is hidden from help.

## Examples

### Example 1
```powershell
Set-Session -Token $authToken -PVWAURL "https://pvwa.example.com" -LogFile "C:\Logs\session.log"

Sets up a session for PVWA with the specified token and log file.
```

### Example 2
```powershell
Set-Session -Token $authToken -PCloudURL "https://mycompany.privilegecloud.cyberark.com" -OutputResults -OutputErrors

Sets up a session for Privileged Cloud with console output enabled.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Shared\Set-Session.ps1*
