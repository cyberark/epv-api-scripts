# links

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The authentication token for the PVWA.

### -AccountID
The ID of the account to link.

### -extraPass
The type of extra password to link (Logon, Enable, Reconcile).

### -extraPassIndex
The index of the extra password to link.

### -extraPassSafe
The safe where the extra password is stored.

### -extraPassObject
The name of the extra password object.

### -extraPassFolder
The folder where the extra password object is stored. Defaults to "Root".

## Examples

### Example 1
```powershell
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12345" -extraPass Logon -extraPassSafe "Safe1" -extraPassObject "Object1"
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Account\Linking\Set-AccountLink.ps1*
