# updates

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The logon token used for authentication with the PVWA API.

### -AccountID
The unique ID of the account to update.

### -Name
The new name for the account.

### -Address
The new address/hostname of the target system.

### -UserName
The new username for the account.

### -PlatformId
The new platform ID that defines the account's platform settings.

### -PlatformAccountProperties
Additional platform-specific properties for the account. Note: Any extra parameters not explicitly defined in this function will automatically be added to platformAccountProperties.

### -AutomaticManagementEnabled
Whether automatic management is enabled for the account.

### -ManualManagementReason
The reason for manual management if automatic management is disabled.

### -RemoteMachines
Semicolon-separated list of remote machines that can access this account.

### -AccessRestrictedToRemoteMachines
Whether access is restricted to the specified remote machines.

### -ExtraParameters
Additional parameters that will be automatically added to platformAccountProperties. This parameter captures any undefined parameters passed to the function using ValueFromRemainingArguments.

## Examples

### Example 1
```powershell
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_345" -Name "srv01-admin-updated" -Address "srv01-new.domain.com"

Updates an account's name and address.
```

### Example 2
```powershell
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_345" -AutomaticManagementEnabled $false -ManualManagementReason "Service account requires manual password changes"

Updates an account's management settings.
```

### Example 3
```powershell
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_345" -Port 1521 -SID "ORCL" -ServiceName "MYSERVICE"

Updates an Oracle database account with platform-specific properties (Port, SID, ServiceName) automatically added to platformAccountProperties.
```

### Example 4
```powershell
Set-Account -PVWAURL "https://pvwa.example.com" -LogonToken $token -AccountID "12_345" -RemoteMachines "srv01.domain.com;srv02.domain.com" -AccessRestrictedToRemoteMachines $true

Updates an account's remote machine access settings.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Account\Core\Set-Account.ps1*
