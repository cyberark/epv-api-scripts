# appends

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -URL
[ref] The URL to which the query parameters will be added.

### -sort
(Optional) The sort parameter to be appended to the URL.

### -offset
(Optional) The offset parameter to be appended to the URL.

### -limit
(Optional) The limit parameter to be appended to the URL.

### -DoNotPage
(Optional) If specified, indicates that paging is disabled.

### -useCache
(Optional) If specified, indicates that session cache should be used for results.

## Examples

### Example 1
```powershell
$URL = [ref] "http://example.com/api/resource"
Add-BaseQueryParameter -URL $URL -sort "name" -offset 10 -limit 50 -useCache

This example adds the sort, offset, limit, and useCache parameters to the given URL.
```

## Notes
This function requires the Write-LogMessage function to be defined for logging purposes.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Shared\Add-BaseQueryParameter.ps1*
