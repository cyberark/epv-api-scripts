# retrieves

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The logon token for authenticating with the PVWA API.

### -SafeName
The name of the safe to retrieve members from.

### -memberName
The name of the member to retrieve information for. This parameter is mandatory when using the 'memberName' parameter set.

### -useCache
A switch to indicate whether to use cached data. This parameter is only valid with the 'memberName' parameter set.

### -Search
A search string to filter members by name. This parameter is only valid with the 'Search' parameter set.

### -memberType
The type of member to filter by. Valid values are "User" and "Group". This parameter is only valid with the 'Search' parameter set.

### -membershipExpired
A filter to include only members with expired memberships. Valid values are "True" and "False". This parameter is only valid with the 'Search' parameter set.

### -includePredefinedUsers
A filter to include predefined users. Valid values are "True" and "False". This parameter is only valid with the 'Search' parameter set.

### -offset
The offset for pagination. This parameter is only valid with the 'Search' parameter set.

### -limit
The limit for pagination. This parameter is only valid with the 'Search' parameter set.

### -DoNotPage
A switch to disable pagination. This parameter is only valid with the 'Search' parameter set.

### -sort
The sort order for the results. Valid values are "asc" and "desc". This parameter is only valid with the 'Search' parameter set.

### -permissions
A switch to include permissions in the output.

## Examples

### Example 1
```powershell
Get-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "Finance"

    Retrieves all members of the "Finance" safe.
```

### Example 2
```powershell
Get-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "Finance" -memberName "JohnDoe"

    Retrieves information about the member "JohnDoe" in the "Finance" safe.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\SafeMember\Core\Get-SafeMember.ps1*
