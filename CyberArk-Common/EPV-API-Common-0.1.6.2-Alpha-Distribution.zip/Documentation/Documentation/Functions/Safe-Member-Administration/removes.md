# removes

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The logon token used for authentication.

### -SafeName
The name of the safe from which the member will be removed.

### -memberName
The name of the member to be removed from the safe.

## Examples

### Example 1
```powershell
Remove-SafeMember -PVWAURL "https://pvwa.example.com" -LogonToken $token -SafeName "FinanceSafe" -memberName "JohnDoe"

This command removes the member "JohnDoe" from the safe "FinanceSafe" in the specified PVWA instance.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\SafeMember\Core\Remove-SafeMember.ps1*
