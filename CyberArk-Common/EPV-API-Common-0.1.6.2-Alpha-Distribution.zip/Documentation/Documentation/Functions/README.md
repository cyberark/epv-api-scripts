# EPV-API-Common Function Reference

This directory contains comprehensive documentation for all functions in the EPV-API-Common PowerShell module.

## Overview

The EPV-API-Common module contains **97 functions** organized into the following categories:
- [Account Operations](./Account-Operations/README.md) - 21 functions
- [Connector Management](./Connector-Management/README.md) - 13 functions
- [Directory Services](./Directory-Services/README.md) - 1 functions
- [Discovery Services](./Discovery-Services/README.md) - 23 functions
- [Safe Management](./Safe-Management/README.md) - 4 functions
- [Safe Member Administration](./Safe-Member-Administration/README.md) - 6 functions
- [Session Management](./Session-Management/README.md) - 2 functions
- [System Administration](./System-Administration/README.md) - 6 functions
- [User and Group Management](./User-and-Group-Management/README.md) - 16 functions
- [Utility Functions](./Utility-Functions/README.md) - 5 functions

## All Functions (Alphabetical)
- [#](./System-Administration/#.md) - No documentation available
- [#](./System-Administration/#.md) - No documentation available
- [#](./System-Administration/#.md) - No documentation available
- [adds](./Safe-Member-Administration/adds.md) - No synopsis available
- [adds](./Connector-Management/adds.md) - No synopsis available
- [adds](./Discovery-Services/adds.md) - No synopsis available
- [adds](./User-and-Group-Management/adds.md) - No synopsis available
- [adds](./Discovery-Services/adds.md) - No synopsis available
- [appends](./Utility-Functions/appends.md) - No synopsis available
- [assigns](./User-and-Group-Management/assigns.md) - No synopsis available
- [assigns](./User-and-Group-Management/assigns.md) - No synopsis available
- [checks](./Discovery-Services/checks.md) - No synopsis available
- [cleans](./Utility-Functions/cleans.md) - No synopsis available
- [configures](./Session-Management/configures.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./System-Administration/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [connects](./Account-Operations/connects.md) - No synopsis available
- [cr](./Safe-Management/cr.md) - No synopsis available
- [creates](./Discovery-Services/creates.md) - No synopsis available
- [creates](./User-and-Group-Management/creates.md) - No synopsis available
- [creates](./Connector-Management/creates.md) - No synopsis available
- [creates](./Discovery-Services/creates.md) - No synopsis available
- [creates](./Connector-Management/creates.md) - No synopsis available
- [creates](./User-and-Group-Management/creates.md) - No synopsis available
- [creates](./Connector-Management/creates.md) - No synopsis available
- [deletes](./Discovery-Services/deletes.md) - No synopsis available
- [deletes](./Connector-Management/deletes.md) - No synopsis available
- [deletes](./Connector-Management/deletes.md) - No synopsis available
- [deletes](./Discovery-Services/deletes.md) - No synopsis available
- [deletes](./Discovery-Services/deletes.md) - No synopsis available
- [deletes](./Discovery-Services/deletes.md) - No synopsis available
- [dismisses](./Discovery-Services/dismisses.md) - No synopsis available
- [edits](./Discovery-Services/edits.md) - No synopsis available
- [establishes](./Session-Management/establishes.md) - No synopsis available
- [exports](./Safe-Member-Administration/exports.md) - No synopsis available
- [exports](./Safe-Management/exports.md) - No synopsis available
- [Get-DirectoryService](./Directory-Services/Get-DirectoryService.md) - Get Identity Directories
- [Invoke-RefreshIdentityUser](./User-and-Group-Management/Invoke-RefreshIdentityUser.md) - No documentation available
- [links](./Account-Operations/links.md) - No synopsis available
- [logs](./Utility-Functions/logs.md) - No synopsis available
- [modifies](./Safe-Member-Administration/modifies.md) - No synopsis available
- [onboards](./Discovery-Services/onboards.md) - No synopsis available
- [onboards](./Discovery-Services/onboards.md) - No synopsis available
- [queries](./System-Administration/queries.md) - No synopsis available
- [queries](./Utility-Functions/queries.md) - No synopsis available
- [queries](./Utility-Functions/queries.md) - No synopsis available
- [reads](./Safe-Member-Administration/reads.md) - No synopsis available
- [removes](./User-and-Group-Management/removes.md) - No synopsis available
- [removes](./Connector-Management/removes.md) - No synopsis available
- [removes](./User-and-Group-Management/removes.md) - No synopsis available
- [removes](./User-and-Group-Management/removes.md) - No synopsis available
- [removes](./User-and-Group-Management/removes.md) - No synopsis available
- [removes](./Safe-Member-Administration/removes.md) - No synopsis available
- [requires](./Connector-Management/requires.md) - No synopsis available
- [retrieves](./Safe-Management/retrieves.md) - No synopsis available
- [retrieves](./Safe-Member-Administration/retrieves.md) - No synopsis available
- [retrieves](./User-and-Group-Management/retrieves.md) - No synopsis available
- [retrieves](./User-and-Group-Management/retrieves.md) - No synopsis available
- [retrieves](./User-and-Group-Management/retrieves.md) - No synopsis available
- [retrieves](./User-and-Group-Management/retrieves.md) - No synopsis available
- [retrieves](./Account-Operations/retrieves.md) - No synopsis available
- [retrieves](./Discovery-Services/retrieves.md) - No synopsis available
- [retrieves](./Discovery-Services/retrieves.md) - No synopsis available
- [retrieves](./Discovery-Services/retrieves.md) - No synopsis available
- [retrieves](./Discovery-Services/retrieves.md) - No synopsis available
- [retrieves](./Discovery-Services/retrieves.md) - No synopsis available
- [retrieves](./Discovery-Services/retrieves.md) - No synopsis available
- [retrieves](./Discovery-Services/retrieves.md) - No synopsis available
- [retrieves](./Discovery-Services/retrieves.md) - No synopsis available
- [retrieves](./Connector-Management/retrieves.md) - No synopsis available
- [retrieves](./Connector-Management/retrieves.md) - No synopsis available
- [retrieves](./Connector-Management/retrieves.md) - No synopsis available
- [retrieves](./Account-Operations/retrieves.md) - No synopsis available
- [retrieves](./System-Administration/retrieves.md) - No synopsis available
- [sends](./User-and-Group-Management/sends.md) - No synopsis available
- [sends](./User-and-Group-Management/sends.md) - No synopsis available
- [updates](./Safe-Management/updates.md) - No synopsis available
- [updates](./Discovery-Services/updates.md) - No synopsis available
- [updates](./Account-Operations/updates.md) - No synopsis available
- [updates](./Connector-Management/updates.md) - No synopsis available
- [updates](./Connector-Management/updates.md) - No synopsis available
- [updates](./Discovery-Services/updates.md) - No synopsis available

## Function Categories

### Account Operations- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [connects](./Account-Operations/connects.md)
- [links](./Account-Operations/links.md)
- [retrieves](./Account-Operations/retrieves.md)
- [retrieves](./Account-Operations/retrieves.md)
- [updates](./Account-Operations/updates.md)

### Connector Management- [adds](./Connector-Management/adds.md)
- [creates](./Connector-Management/creates.md)
- [creates](./Connector-Management/creates.md)
- [creates](./Connector-Management/creates.md)
- [deletes](./Connector-Management/deletes.md)
- [deletes](./Connector-Management/deletes.md)
- [removes](./Connector-Management/removes.md)
- [requires](./Connector-Management/requires.md)
- [retrieves](./Connector-Management/retrieves.md)
- [retrieves](./Connector-Management/retrieves.md)
- [retrieves](./Connector-Management/retrieves.md)
- [updates](./Connector-Management/updates.md)
- [updates](./Connector-Management/updates.md)

### Directory Services- [Get-DirectoryService](./Directory-Services/Get-DirectoryService.md)

### Discovery Services- [adds](./Discovery-Services/adds.md)
- [adds](./Discovery-Services/adds.md)
- [checks](./Discovery-Services/checks.md)
- [creates](./Discovery-Services/creates.md)
- [creates](./Discovery-Services/creates.md)
- [deletes](./Discovery-Services/deletes.md)
- [deletes](./Discovery-Services/deletes.md)
- [deletes](./Discovery-Services/deletes.md)
- [deletes](./Discovery-Services/deletes.md)
- [dismisses](./Discovery-Services/dismisses.md)
- [edits](./Discovery-Services/edits.md)
- [onboards](./Discovery-Services/onboards.md)
- [onboards](./Discovery-Services/onboards.md)
- [retrieves](./Discovery-Services/retrieves.md)
- [retrieves](./Discovery-Services/retrieves.md)
- [retrieves](./Discovery-Services/retrieves.md)
- [retrieves](./Discovery-Services/retrieves.md)
- [retrieves](./Discovery-Services/retrieves.md)
- [retrieves](./Discovery-Services/retrieves.md)
- [retrieves](./Discovery-Services/retrieves.md)
- [retrieves](./Discovery-Services/retrieves.md)
- [updates](./Discovery-Services/updates.md)
- [updates](./Discovery-Services/updates.md)

### Safe Management- [cr](./Safe-Management/cr.md)
- [exports](./Safe-Management/exports.md)
- [retrieves](./Safe-Management/retrieves.md)
- [updates](./Safe-Management/updates.md)

### Safe Member Administration- [adds](./Safe-Member-Administration/adds.md)
- [exports](./Safe-Member-Administration/exports.md)
- [modifies](./Safe-Member-Administration/modifies.md)
- [reads](./Safe-Member-Administration/reads.md)
- [removes](./Safe-Member-Administration/removes.md)
- [retrieves](./Safe-Member-Administration/retrieves.md)

### Session Management- [configures](./Session-Management/configures.md)
- [establishes](./Session-Management/establishes.md)

### System Administration- [#](./System-Administration/#.md)
- [#](./System-Administration/#.md)
- [#](./System-Administration/#.md)
- [connects](./System-Administration/connects.md)
- [queries](./System-Administration/queries.md)
- [retrieves](./System-Administration/retrieves.md)

### User and Group Management- [adds](./User-and-Group-Management/adds.md)
- [assigns](./User-and-Group-Management/assigns.md)
- [assigns](./User-and-Group-Management/assigns.md)
- [creates](./User-and-Group-Management/creates.md)
- [creates](./User-and-Group-Management/creates.md)
- [Invoke-RefreshIdentityUser](./User-and-Group-Management/Invoke-RefreshIdentityUser.md)
- [removes](./User-and-Group-Management/removes.md)
- [removes](./User-and-Group-Management/removes.md)
- [removes](./User-and-Group-Management/removes.md)
- [removes](./User-and-Group-Management/removes.md)
- [retrieves](./User-and-Group-Management/retrieves.md)
- [retrieves](./User-and-Group-Management/retrieves.md)
- [retrieves](./User-and-Group-Management/retrieves.md)
- [retrieves](./User-and-Group-Management/retrieves.md)
- [sends](./User-and-Group-Management/sends.md)
- [sends](./User-and-Group-Management/sends.md)

### Utility Functions- [appends](./Utility-Functions/appends.md)
- [cleans](./Utility-Functions/cleans.md)
- [logs](./Utility-Functions/logs.md)
- [queries](./Utility-Functions/queries.md)
- [queries](./Utility-Functions/queries.md)

## Documentation Structure

Each function's documentation includes:

- **Synopsis**: Brief description of what the function does
- **Description**: Detailed explanation of the function's purpose and behavior
- **Parameters**: Complete parameter reference with descriptions
- **Examples**: Practical usage examples
- **Notes**: Additional information, requirements, and best practices

## Usage

To get help for any function directly in PowerShell:

```powershell
Get-Help FunctionName -Detailed
Get-Help FunctionName -Full
Get-Help FunctionName -Examples
```

## Contributing

When adding new functions or updating existing ones:

1. Include comprehensive comment-based help in the function
2. Regenerate documentation using the Generate-Documentation.ps1 script
3. Update examples and ensure they are tested and accurate
4. Follow the established documentation patterns and style

---
*Documentation generated on 2025-09-20 21:16:51*
