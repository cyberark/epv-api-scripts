# logs

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -MSG
The message to log. This parameter is mandatory and accepts pipeline input.

### -Header
Adds a header line before the message. This parameter is optional.

### -SubHeader
Adds a subheader line before the message. This parameter is optional.

### -Footer
Adds a footer line after the message. This parameter is optional.

### -WriteLog
Indicates whether to write the output to a log file. The default value is $true.

### -type
The type of the message to log. Valid values are 'Info', 'Important', 'Warning', 'Error', 'Debug', 'Verbose', 'Success',
    'LogOnly', and 'ErrorThrow'. The default value is 'Info'.

### -LogFile
The log file to write to. if not provided and WriteLog is $true, a temporary log file named 'Log.Log' will be created.

### -pad
The padding width for verbose messages when formatting message arrays. The default value is 20.

### -maskAnswer
Internal switch parameter used for masking sensitive information. This parameter is hidden from help display.

## Examples

### Example 1
```powershell
Write-LogMessage -MSG "This is an info message" -type Info

    Logs an info message to the console and the default log file.
```

### Example 2
```powershell
"This is a warning message" | Write-LogMessage -type Warning

    Logs a warning message to the console and the default log file using pipeline input.
```

### Example 3
```powershell
Write-LogMessage -MSG "This is an error message" -type Error -LogFile "C:\Logs\error.log"

    Logs an error message to the console and to the specified log file.
```

### Example 4
```powershell
Write-LogMessage -MSG "Critical system alert" -type Important

    Logs an important message with special formatting (highlighted background/foreground colors).
```

### Example 5
```powershell
Write-LogMessage -MSG "Operation:	Details about the operation" -type Verbose -pad 25

    Logs a verbose message with custom padding of 25 characters for better formatting.
```

## Notes
The function masks sensitive information like passwords in the messages to prevent accidental exposure.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Shared\Write-LogMessage.ps1*
