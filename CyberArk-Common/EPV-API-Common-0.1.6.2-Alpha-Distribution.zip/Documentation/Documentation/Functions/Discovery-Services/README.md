# Discovery Services Functions

This section contains 23 functions related to Discovery Services.

## Functions in this Category
- [adds](./adds.md) - No synopsis available
- [adds](./adds.md) - No synopsis available
- [checks](./checks.md) - No synopsis available
- [creates](./creates.md) - No synopsis available
- [creates](./creates.md) - No synopsis available
- [deletes](./deletes.md) - No synopsis available
- [deletes](./deletes.md) - No synopsis available
- [deletes](./deletes.md) - No synopsis available
- [deletes](./deletes.md) - No synopsis available
- [dismisses](./dismisses.md) - No synopsis available
- [edits](./edits.md) - No synopsis available
- [onboards](./onboards.md) - No synopsis available
- [onboards](./onboards.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [retrieves](./retrieves.md) - No synopsis available
- [updates](./updates.md) - No synopsis available
- [updates](./updates.md) - No synopsis available

## Quick Reference

| Function | Synopsis |
|----------|----------|| [adds](./adds.md) | No synopsis available |
| [adds](./adds.md) | No synopsis available |
| [checks](./checks.md) | No synopsis available |
| [creates](./creates.md) | No synopsis available |
| [creates](./creates.md) | No synopsis available |
| [deletes](./deletes.md) | No synopsis available |
| [deletes](./deletes.md) | No synopsis available |
| [deletes](./deletes.md) | No synopsis available |
| [deletes](./deletes.md) | No synopsis available |
| [dismisses](./dismisses.md) | No synopsis available |
| [edits](./edits.md) | No synopsis available |
| [onboards](./onboards.md) | No synopsis available |
| [onboards](./onboards.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [retrieves](./retrieves.md) | No synopsis available |
| [updates](./updates.md) | No synopsis available |
| [updates](./updates.md) | No synopsis available |

