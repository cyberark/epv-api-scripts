# Get-DirectoryService

## Synopsis
Get Identity Directories

## Description
Get Identity Directories

## Examples

### Example 1
```powershell
Example of how to use this cmdlet
```

### Example 2
```powershell
Another example of how to use this cmdlet
```

## Notes
General notes

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Identity\Directory\Get-DirectoryService.ps1*
