# cr

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -PVWAURL
The URL of the PVWA instance.

### -LogonToken
The logon token for authentication.

### -safeName
The name of the safe to be created.

### -description
The description of the safe.

### -location
The location of the safe.

### -olacEnabled
Switch to enable or disable OLAC (Object Level Access Control).

### -managingCPM
The name of the managing CPM (Central Policy Manager).

### -numberOfVersionsRetention
The number of versions to retain.

### -numberOfDaysRetention
The number of days to retain versions.

### -AutoPurgeEnabled
Switch to enable or disable automatic purging.

## Examples

### Example 1
```powershell
PS> New-Safe -PVWAURL "https://pvwa.example.com" -LogonToken $token -safeName "NewSafe" -description "This is a new safe" -location "Root" -olacEnabled -managingCPM "CPM1" -numberOfVersionsRetention "5" -numberOfDaysRetention "30" -AutoPurgeEnabled

This command creates a new safe named "NewSafe" in the specified PVWA instance with the given parameters.
```

## Notes
This function requires the 'Invoke-Rest' and 'Write-LogMessage' functions to be defined in the session.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Safe\Core\New-Safe.ps1*
