# exports

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -CSVPath
The path to the CSV file where the safe information will be exported. Default is ".\SafeExport.csv".

### -Force
If specified, forces the overwrite of the existing CSV file.

### -Safe
The safe object to be exported. This parameter is mandatory and accepts input from the pipeline.

### -IncludeAccounts
If specified, includes account details in the export.

### -IncludeDetails
If specified, includes additional details about the safe in the export.

### -includeSystemSafes
If specified, includes system safes in the export. This parameter is hidden from the user.

### -CPMUser
An array of CPM user names. This parameter is hidden from the user.

## Examples

### Example 1
```powershell
Export-Safe -CSVPath "C:\Exports\SafeExport.csv" -Force -Safe $safe -IncludeAccounts -IncludeDetails

This example exports the details of the specified safe to "C:\Exports\SafeExport.csv", including account details and additional safe details, and forces the overwrite of the existing file.
```

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\Safe\Import-Export\Export-Safe.ps1*
