# assigns

## Synopsis
No synopsis available

## Description
No description available

## Parameters

### -RoleName
The name of the role to be added to the users. This parameter is mandatory and accepts pipeline input.

### -IdentityURL
The base URL of the identity service. This parameter is mandatory.

### -LogonToken
The authentication token required to log on to the identity service. This parameter is mandatory.

### -User
An array of user identifiers to which the role will be added. This parameter is mandatory and accepts pipeline input.

## Examples

### Example 1
```powershell
PS> Add-IdentityRoleToUser -RoleName "Admin" -IdentityURL "https://identity.example.com" -LogonToken $token -User "user1"

Adds the "Admin" role to the user "user1".
```

### Example 2
```powershell
PS> "user1", "user2" | Add-IdentityRoleToUser -RoleName "Admin" -IdentityURL "https://identity.example.com" -LogonToken $token

Adds the "Admin" role to the users "user1" and "user2".
```

## Notes
This function requires the Write-LogMessage and Invoke-Rest functions to be defined in the session.

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\Identity\Role\Add-IdentityRoleToUser.ps1*
