# retrieves

## Synopsis
No synopsis available

## Description
No description available

## Related Functions
See [Function Reference Index](../README.md#function-categories) for related functions.

---
*Generated from: \Source\Public\PAS\CPM\Get-CPMUser.ps1*
