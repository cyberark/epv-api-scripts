# Session Management Functions

This section contains 2 functions related to Session Management.

## Functions in this Category
- [configures](./configures.md) - No synopsis available
- [establishes](./establishes.md) - No synopsis available

## Quick Reference

| Function | Synopsis |
|----------|----------|| [configures](./configures.md) | No synopsis available |
| [establishes](./establishes.md) | No synopsis available |

